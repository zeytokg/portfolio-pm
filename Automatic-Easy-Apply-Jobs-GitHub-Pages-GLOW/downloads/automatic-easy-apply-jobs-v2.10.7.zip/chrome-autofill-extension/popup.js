function setStatus(text) {
  const statusEl = document.getElementById("status");
  statusEl.textContent = text;
  statusEl.classList.toggle("show", !!text);
}

async function activeTabMessage(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return null;
  return chrome.tabs.sendMessage(tab.id, message);
}

async function fillActiveTab() {
  return activeTabMessage({ type: "FILL_NOW" });
}

function renderUnansweredList(items = []) {
  const list = document.getElementById("missingList");
  const count = document.getElementById("missingCount");
  if (!list || !count) return;
  count.textContent = String(items.length);
  list.textContent = "";
  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "missing-empty";
    empty.textContent = "✓ No visible unanswered fields found.";
    list.appendChild(empty);
    return;
  }

  items.forEach((item) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "missing-item";
    const label = document.createElement("span");
    label.className = "missing-label";
    label.textContent = item.label || "Unanswered field";
    const meta = document.createElement("span");
    meta.className = "missing-meta";
    meta.textContent = `${item.required ? "Required · " : ""}${item.reason || "Not filled"} · click to open`;
    btn.append(label, meta);
    btn.addEventListener("click", async () => {
      try {
        await activeTabMessage({ type: "FOCUS_FIELD", fieldId: item.id });
      } catch (_err) {}
    });
    list.appendChild(btn);
  });
}

async function refreshUnansweredList() {
  try {
    const response = await activeTabMessage({ type: "GET_UNANSWERED" });
    if (response?.unanswered) renderUnansweredList(response.unanswered);
  } catch (_err) {
    const list = document.getElementById("missingList");
    const count = document.getElementById("missingCount");
    if (count) count.textContent = "–";
    if (list) list.innerHTML = '<div class="missing-empty">Reload the application page to enable field scanning.</div>';
  }
}

document.getElementById("fillBtn").addEventListener("click", async () => {
  setStatus("Filling...");

  try {
    const response = await fillActiveTab();
    if (!response) {
      setStatus("No response from this page. Try reloading it.");
    } else if (response.error === "no-profile") {
      setStatus('Set up your profile first ("Edit Profile").');
    } else if (response.error === "crashed") {
      setStatus("Something went wrong filling this page: " + response.message);
    } else {
      renderUnansweredList(response.result.unanswered || []);
      setStatus(
        `${response.result.filled} fields filled, ` +
        `${(response.result.unanswered || []).length} still unanswered, ` +
        `${response.result.fileHelpers} upload helper(s).`
      );
    }
  } catch (e) {
    setStatus("Couldn't run on this page: " + e.message);
  }
});

document.getElementById("openOnPageBtn")?.addEventListener("click", async () => {
  try {
    const response = await activeTabMessage({ type: "OPEN_PANEL" });
    if (!response?.ok) {
      setStatus("Could not open the on-page assistant. Reload the application page once and try again.");
      return;
    }
    // The on-page panel is now visible; close the toolbar popup so the page
    // regains focus immediately.
    window.close();
  } catch (err) {
    setStatus(`Could not open the on-page assistant: ${err.message}`);
  }
});

document.getElementById("optionsBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById("manageLearnedAnswersBtn")?.addEventListener("click", async () => {
  const url = chrome.runtime.getURL("options.html#saved-answers");
  await chrome.tabs.create({ url });
  window.close();
});

// Same setting as "Automation" → "Automatically fill the form..." in Edit
// Profile — kept in sync both ways so it's editable from either place.
const autoFillToggle = document.getElementById("autoFillToggle");
const learnAnswersToggle = document.getElementById("learnAnswersToggle");

chrome.storage.local.get("profile", ({ profile }) => {
  const data = normalizeProfile(profile);
  autoFillToggle.checked = data.autoFillOnDetect !== false;
  learnAnswersToggle.checked = data.learnNewAnswers !== false;
  // Persist the one-time demographic migration for existing installs.
  if (profile && Number(profile.demographicProfileVersion || 0) < DEMOGRAPHIC_PROFILE_VERSION) {
    chrome.storage.local.set({ profile: data });
  }
});

autoFillToggle.addEventListener("change", () => {
  chrome.storage.local.get("profile", ({ profile }) => {
    const updated = normalizeProfile(profile);
    updated.autoFillOnDetect = autoFillToggle.checked;
    chrome.storage.local.set({ profile: updated });
  });
});

learnAnswersToggle.addEventListener("change", () => {
  chrome.storage.local.get("profile", ({ profile }) => {
    const updated = normalizeProfile(profile);
    updated.learnNewAnswers = learnAnswersToggle.checked;
    chrome.storage.local.set({ profile: updated });
  });
});

function refreshLearnedCountPopup() {
  chrome.storage.local.get("learnedAnswers", ({ learnedAnswers }) => {
    const count = Object.keys(learnedAnswers?.records || {}).length;
    const el = document.getElementById("learnedAnswerPopupDesc");
    if (el) el.textContent = `Save safe manual answers locally — credentials and ID numbers are never stored · ${count} learned`;
  });
}

// --- Stable document manager (CV / Cover Letter / Portfolio) ---
// Native file choosers opened inside a toolbar popup can be interrupted when
// Chrome closes the popup on focus loss. Instead, each button opens a normal
// extension tab. That page keeps the chooser alive, stores the real bytes,
// and sends the file straight back to the application tab.
const QUICK_FILE_KEYS = ["cv", "coverLetter", "portfolio"];

function updateQuickFileStatus(key, fileName) {
  const el = document.getElementById(`${key}QuickFileStatus`);
  if (!el) return;
  el.textContent = fileName ? `✓ ${fileName}` : "Not selected";
  el.classList.toggle("empty", !fileName);
}

function loadQuickFiles() {
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    QUICK_FILE_KEYS.forEach((key) => {
      updateQuickFileStatus(key, data[`${key}FileDataUrl`] ? data[`${key}FileName`] : "");
    });
  });
}

async function openDocumentManager(key, { profileImport = false } = {}) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const targetTab = tab?.id || "";
  const params = new URLSearchParams({ key, targetTab: String(targetTab) });
  if (profileImport) params.set("profileImport", "1");
  const url = chrome.runtime.getURL(`documents.html?${params.toString()}`);
  await chrome.tabs.create({ url });
}

document.getElementById("importProfileCvBtn")?.addEventListener("click", async () => {
  try {
    await openDocumentManager("cv", { profileImport: true });
  } catch (err) {
    setStatus(`Couldn't open CV profile import: ${err.message}`);
  }
});

document.querySelectorAll(".quick-file-pick[data-key]").forEach((button) => {
  button.addEventListener("click", async () => {
    try {
      await openDocumentManager(button.dataset.key);
    } catch (err) {
      setStatus(`Couldn't open the document picker: ${err.message}`);
    }
  });
});

QUICK_FILE_KEYS.forEach((key) => {
  const clearBtn = document.querySelector(`.quick-file-clear[data-key="${key}"]`);
  clearBtn?.addEventListener("click", () => {
    chrome.storage.local.get("profile", ({ profile }) => {
      const data = normalizeProfile(profile);
      data[`${key}FileDataUrl`] = "";
      data[`${key}FileName`] = "";
      chrome.storage.local.set({ profile: data }, () => {
        updateQuickFileStatus(key, "");
        setStatus("Stored document removed.");
      });
    });
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.learnedAnswers) refreshLearnedCountPopup();
});

loadQuickFiles();
refreshLearnedCountPopup();
refreshUnansweredList();
setInterval(refreshUnansweredList, 1400);
