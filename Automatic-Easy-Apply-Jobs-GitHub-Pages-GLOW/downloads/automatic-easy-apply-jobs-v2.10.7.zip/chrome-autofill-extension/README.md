# Automatic Easy Apply Jobs — Blank / Shareable Build

Created by **zeytokg**. JiraCop branding is intentionally retained in this shareable build.

This package contains **no preloaded applicant profile, resume, cover letter, learned answers, salary values, demographic answers, contact details, file paths, or personal links**. Each person who installs it starts with an empty profile.

## Install

1. Unzip the package.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select the extension folder.
5. Open **Settings** or use **Import profile from CV** to create your own local profile.

## Main features

- Fill common job-application fields from a locally saved profile.
- Import readable contact/career details from a CV into the profile.
- Save a CV, cover letter, and portfolio locally and attach them to matching upload/dropzone fields.
- Remember new manual answers locally and reuse them on similar questions; review, search, and delete saved answers individually from Settings.
- Handle native selects plus many custom React/ARIA dropdowns, radio groups, pills, and checkbox groups.
- Highlight unanswered fields in red and let the in-page assistant jump to them.
- Draggable in-page assistant that remembers its position.
- Work-authorization, consent, demographic, compensation, and other personal answers have **no preset values** in this build.
- The extension never submits an application automatically.

## Privacy

Profile values, learned answers, and selected documents are stored in Chrome local extension storage on the device. The extension does not include a server or upload profile data anywhere by itself. Files are only attached to job-application pages when the user asks the extension to fill/attach them.

## CV import

CV parsing is local and best-effort. It can extract conventional contact/career fields such as name, email, phone, links, job title, company, years of experience, address/postal information when readable. It does not infer sensitive demographic identity, legal/work authorization, consent, non-compete, or salary answers from CV text.

## Sensitive-data safety

The learned-answer feature intentionally excludes passwords, passcodes/PINs, OTP/verification/security codes, passport and government-ID numbers, SSNs/tax IDs, banking/card credentials, recovery codes, API keys/tokens, and similar secrets. These fields are left for manual entry and are not reused across sites. Updating from an older build also purges matching sensitive learned-answer records while keeping ordinary learned job-application answers.
