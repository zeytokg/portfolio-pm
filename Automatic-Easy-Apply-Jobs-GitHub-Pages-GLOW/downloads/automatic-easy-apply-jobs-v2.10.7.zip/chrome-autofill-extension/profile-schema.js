// Shared profile schema for the shareable/blank build.
// No applicant information is preloaded. Each installation starts with an
// empty profile and can be populated manually or by importing a CV locally.

const DEMOGRAPHIC_PROFILE_VERSION = 1;
const DEMOGRAPHIC_DEFAULTS = {
  demographicProfileVersion: DEMOGRAPHIC_PROFILE_VERSION,
  age: "",
  ageRange: "",
  nationality: "",
  ethnicity: "",
  race: "",
  hispanicLatino: "",
  disabilityStatus: "",
  lgbtqiaStatus: "",
  transgenderStatus: "",
  sexualOrientation: "",
  communitySelections: "",
  veteranStatus: "",
  revealGender: false,
  genderValue: "",
};

const CONTACT_PROFILE_VERSION = 2;
const CONTACT_DEFAULTS = {
  contactProfileVersion: CONTACT_PROFILE_VERSION,
  phone: "",
  phoneExtension: "",
  phoneCountry: "",
  country: "",
};

const DEFAULT_PROFILE = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  phoneExtension: "",
  phoneCountry: "",
  linkedin: "",
  portfolio: "",
  github: "",
  yearsOfExperience: "",
  currentJobTitle: "",
  currentCompany: "",
  headline: "",
  pronouns: "",
  nonCompete: "",

  cvFileName: "",
  cvFilePath: "",
  cvFileDataUrl: "",
  coverLetterFileName: "",
  coverLetterFilePath: "",
  coverLetterFileDataUrl: "",
  portfolioFileName: "",
  portfolioFilePath: "",
  portfolioFileDataUrl: "",

  address: "",
  city: "",
  region: "",
  postalCode: "",
  country: "",
  locationDisplay: "",
  cadastral: "",

  hourlyRate: "",
  hourlyRateCurrency: "",
  dayRate: "",
  monthlySalary: "",
  annualSalary: "",
  salaryExpectation: "",
  workAuthorizationWithoutSponsorship: "",
  workEligibility: "",
  availability: "",
  ...DEMOGRAPHIC_DEFAULTS,

  coverLetterSummary: "",
  coverLetterFull: "",
  rightToWorkNote: "",

  languageEnglish: "",
  languageTurkish: "",
  languageItalian: "",
  languageGerman: "",
  languageFrench: "",
  languageOtherDefault: "",

  contactProfileVersion: CONTACT_PROFILE_VERSION,
  autoFillOnDetect: true,
  learnNewAnswers: true,
  importProfileFromCvOnSelect: true,
};

function normalizeProfile(profile) {
  const data = { ...DEFAULT_PROFILE, ...(profile || {}) };
  const version = Number(profile?.demographicProfileVersion || 0);
  if (version < DEMOGRAPHIC_PROFILE_VERSION) Object.assign(data, DEMOGRAPHIC_DEFAULTS);
  const contactVersion = Number(profile?.contactProfileVersion || 0);
  if (contactVersion < 1) Object.assign(data, CONTACT_DEFAULTS);
  if (contactVersion < 2) {
    // v2.10.4's lightweight PDF parser could occasionally save page drawing
    // coordinates as a phone number (for example "179.25 675.41998 2").
    // Only clear that unmistakable corruption pattern; keep real/manual phones.
    const legacyPhone = String(data.phone || "").trim();
    const decimalFragments = (legacyPhone.match(/\d+\.\d+/g) || []).length;
    if (!legacyPhone.startsWith("+") && decimalFragments >= 1) data.phone = "";
    data.contactProfileVersion = CONTACT_PROFILE_VERSION;
  }
  return data;
}

const LANGUAGE_LEVELS = [
  "",
  "No Relevant Proficiency (A1, A2)",
  "Limited Working Proficiency (B1)",
  "Professional Working Proficiency (B2)",
  "Full Professional Proficiency (C1)",
  "Native / Bilingual Proficiency (C2)",
];

const PROFILE_FORM_FIELDS = [
  { id: "firstName", label: "First Name" },
  { id: "lastName", label: "Last Name" },
  { id: "email", label: "Email" },
  { id: "phone", label: "Phone" },
  { id: "phoneExtension", label: "Phone Extension (blank if none)" },
  { id: "phoneCountry", label: "Phone Country" },
  { id: "linkedin", label: "LinkedIn URL" },
  { id: "portfolio", label: "Portfolio / Website URL" },
  { id: "github", label: "GitHub URL" },
  { id: "yearsOfExperience", label: "Years of Experience" },
  { id: "currentJobTitle", label: "Current Job Title" },
  { id: "currentCompany", label: "Current Company" },
  { id: "headline", label: "Professional Headline" },
  { id: "pronouns", label: "Pronouns" },
  { id: "nonCompete", label: "Non-compete in place", type: "select", options: ["", "Yes", "No"] },
  { id: "address", label: "Address" },
  { id: "city", label: "City" },
  { id: "region", label: "Region / Province" },
  { id: "postalCode", label: "Postal Code" },
  { id: "country", label: "Country" },
  { id: "locationDisplay", label: "Location / City autocomplete" },
  { id: "cadastral", label: "Cadastral Info" },
  { id: "hourlyRate", label: "Hourly Rate (without VAT)" },
  { id: "hourlyRateCurrency", label: "Hourly Rate Currency" },
  { id: "dayRate", label: "Day Rate" },
  { id: "monthlySalary", label: "Monthly Salary" },
  { id: "annualSalary", label: "Annual Salary" },
  { id: "salaryExpectation", label: "Salary Expectation" },
  { id: "workAuthorizationWithoutSponsorship", label: "Authorized to work without sponsorship", type: "select", options: ["", "Yes", "No"] },
  { id: "workEligibility", label: "Legally eligible / right to work", type: "select", options: ["", "Yes", "No"] },
  { id: "availability", label: "Notice Period / Availability" },
  { id: "age", label: "Age" },
  { id: "ageRange", label: "Age Range" },
  { id: "nationality", label: "Nationality" },
  { id: "race", label: "Race" },
  { id: "ethnicity", label: "Ethnicity" },
  { id: "hispanicLatino", label: "Hispanic / Latino" },
  { id: "disabilityStatus", label: "Disability Status" },
  { id: "lgbtqiaStatus", label: "LGBTQIA+" },
  { id: "transgenderStatus", label: "Transgender" },
  { id: "sexualOrientation", label: "Sexual Orientation (comma-separated if multiple)" },
  { id: "communitySelections", label: "Communities (comma-separated if multiple)" },
  { id: "veteranStatus", label: "Veteran Status" },
  { id: "coverLetterSummary", label: "Cover Letter (short)", type: "textarea" },
  { id: "coverLetterFull", label: "Cover Letter (full)", type: "textarea" },
  { id: "rightToWorkNote", label: "Right to Work Note", type: "textarea" },
  { id: "languageEnglish", label: "English", type: "select", options: LANGUAGE_LEVELS },
  { id: "languageTurkish", label: "Turkish", type: "select", options: LANGUAGE_LEVELS },
  { id: "languageItalian", label: "Italian", type: "select", options: LANGUAGE_LEVELS },
  { id: "languageGerman", label: "German", type: "select", options: LANGUAGE_LEVELS },
  { id: "languageFrench", label: "French", type: "select", options: LANGUAGE_LEVELS },
  { id: "languageOtherDefault", label: "Other languages (default)", type: "select", options: LANGUAGE_LEVELS },
  { id: "learnNewAnswers", label: "Remember new manual answers", type: "checkbox" },
  { id: "revealGender", label: "Answer gender question automatically", type: "checkbox" },
  { id: "genderValue", label: "Gender value" },
];
