// DEFAULT_PROFILE comes from profile-schema.js (loaded before this file in
// options.html) — the same schema content.js's in-page panel uses, so both
// stay in sync automatically.
const FIELD_IDS = Object.keys(DEFAULT_PROFILE);

const CV_FIELD_LABELS = {
  firstName: "First Name",
  lastName: "Last Name",
  email: "Email",
  phone: "Phone",
  phoneCountry: "Phone Country",
  linkedin: "LinkedIn",
  portfolio: "Portfolio / Website",
  github: "GitHub",
  yearsOfExperience: "Total Experience",
  currentJobTitle: "Current Job Title",
  currentCompany: "Current Company",
  headline: "Professional Headline",
  address: "Address",
  postalCode: "Postal Code",
  city: "City",
  region: "Region",
  country: "Country",
  locationDisplay: "Location",
};

function setQuickCvImportStatus(text, kind = "") {
  const el = document.getElementById("cvQuickImportStatus");
  if (!el) return;
  el.textContent = text;
  el.classList.remove("ok", "warn");
  if (kind) el.classList.add(kind);
}

function showQuickImportedFields(fields = []) {
  const el = document.getElementById("cvQuickImportFields");
  if (!el) return;
  if (!fields.length) {
    el.textContent = "";
    return;
  }
  el.textContent = `Fields extracted from CV: ${fields.map((key) => CV_FIELD_LABELS[key] || key).join(", ")}`;
}

function getStoredProfileAsync() {
  return new Promise((resolve) => chrome.storage.local.get("profile", ({ profile }) => resolve(normalizeProfile(profile))));
}

function setStoredProfileAsync(profile) {
  return new Promise((resolve) => chrome.storage.local.set({ profile }, resolve));
}

async function storeCvAndImportProfile(file, { forceImport = true } = {}) {
  if (!file) throw new Error("Choose a CV first.");
  if (!/\.(pdf|doc|docx|txt)$/i.test(file.name)) throw new Error("Please choose a PDF, DOC, DOCX, or TXT CV.");

  setQuickCvImportStatus(`Reading CV: ${file.name}…`);
  showQuickImportedFields([]);
  const dataUrl = await fileToDataUrl(file);
  const profile = await getStoredProfileAsync();
  profile.cvFileDataUrl = dataUrl;
  profile.cvFileName = file.name;

  let result = null;
  let changed = [];
  if (forceImport || profile.importProfileFromCvOnSelect) {
    result = await extractProfileFromCvFile(file);
    changed = applyCvProfilePatch(profile, result.profilePatch);
  }

  await setStoredProfileAsync(profile);
  refreshFileStatus("cv", file.name);
  loadProfile();
  if (result) {
    showQuickImportedFields(result.extractedFields || changed);
    const extractedCount = result.extractedFields?.length || 0;
    const changedText = changed.length
      ? `${changed.length} profile field${changed.length === 1 ? "" : "s"} updated and saved.`
      : extractedCount
        ? `${extractedCount} profile field${extractedCount === 1 ? " was" : "s were"} read successfully; your saved values already matched.`
        : "The CV file was saved, but no reliable profile fields could be read from it.";
    const warning = result.warning ? ` ${result.warning}` : "";
    setQuickCvImportStatus(`✓ ${changedText}${warning}`, changed.length ? "ok" : "warn");
    setCvImportStatus(`CV parsed locally (${result.format}). ${changedText}${warning}`, changed.length ? "ok" : "warn");
  } else {
    setQuickCvImportStatus(`✓ ${file.name} was saved as your CV. Automatic profile import is off.`, "ok");
  }
  return { profile, result, changed };
}

const NEVER_SHOW_SAVED_RE = /password|passcode|\bpin\b|\botp\b|verification code|security code|two[- ]?factor|2fa|mfa|passport|social security|\bssn\b|national id|government id|tax id|fiscal code|iban|bank account|routing number|swift|credit card|debit card|\bcvv\b|\bcvc\b|recovery code|api key|access token|secret key/i;
let learnedAnswerFilter = "";

function safeLearnedRecords(learnedAnswers) {
  const records = learnedAnswers?.records || {};
  return Object.entries(records).filter(([, record]) => {
    const text = `${record?.question || ""} ${record?.questionNorm || ""}`;
    return record && record.answer && !NEVER_SHOW_SAVED_RE.test(text);
  });
}

function formatLearnedDate(ts) {
  if (!ts) return "";
  try {
    return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(ts));
  } catch (_err) { return ""; }
}

function deleteLearnedAnswer(key) {
  chrome.storage.local.get("learnedAnswers", ({ learnedAnswers }) => {
    const store = learnedAnswers && typeof learnedAnswers === "object" ? learnedAnswers : { version: 2, records: {} };
    const records = { ...(store.records || {}) };
    if (!(key in records)) return;
    delete records[key];
    chrome.storage.local.set({ learnedAnswers: { version: Math.max(2, Number(store.version || 0)), records } }, refreshLearnedAnswers);
  });
}

function renderLearnedAnswers(learnedAnswers) {
  const allEntries = safeLearnedRecords(learnedAnswers);
  const countEl = document.getElementById("learnedAnswerCount");
  if (countEl) countEl.textContent = `${allEntries.length} learned answer${allEntries.length === 1 ? "" : "s"}`;

  const list = document.getElementById("learnedAnswerList");
  if (!list) return;
  list.textContent = "";
  const q = learnedAnswerFilter.trim().toLowerCase();
  const entries = allEntries
    .filter(([, record]) => !q || `${record.question || ""} ${record.answer || ""} ${record.scope || ""}`.toLowerCase().includes(q))
    .sort((a, b) => (b[1]?.updatedAt || 0) - (a[1]?.updatedAt || 0));

  if (!entries.length) {
    const empty = document.createElement("div");
    empty.className = "learned-empty";
    empty.textContent = allEntries.length ? "No saved answers match your search." : "No learned answers yet. Manual answers you choose on job forms will appear here when Remember new answers is enabled.";
    list.appendChild(empty);
    return;
  }

  entries.forEach(([key, record]) => {
    const item = document.createElement("div");
    item.className = "learned-item";

    const question = document.createElement("div");
    question.className = "learned-question";
    question.textContent = record.question || record.questionNorm || "Saved question";

    const answer = document.createElement("div");
    answer.className = "learned-answer";
    answer.textContent = record.answer;

    const meta = document.createElement("div");
    meta.className = "learned-meta";
    const scope = document.createElement("span");
    scope.textContent = record.legal ? `Site-specific · ${record.scope || "this application site"}` : "Reusable globally";
    meta.appendChild(scope);
    const dateText = formatLearnedDate(record.updatedAt);
    if (dateText) {
      const date = document.createElement("span");
      date.textContent = `Updated ${dateText}`;
      meta.appendChild(date);
    }
    const del = document.createElement("button");
    del.type = "button";
    del.className = "learned-delete";
    del.textContent = "Delete";
    del.title = "Delete this saved answer";
    del.addEventListener("click", () => deleteLearnedAnswer(key));
    meta.appendChild(del);

    item.append(question, answer, meta);
    list.appendChild(item);
  });
}

function refreshLearnedAnswers() {
  chrome.storage.local.get("learnedAnswers", ({ learnedAnswers }) => renderLearnedAnswers(learnedAnswers));
}

function refreshLearnedAnswerCount() {
  refreshLearnedAnswers();
}

function loadProfile() {
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    FIELD_IDS.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (el.type === "checkbox") el.checked = !!data[id];
      else el.value = data[id] ?? "";
    });
  });
}

function saveProfile() {
  chrome.storage.local.get("profile", ({ profile }) => {
    // Start from defaults + whatever is already stored, so fields with no
    // form control on this page (e.g. "ethnicity") aren't wiped on save.
    const data = normalizeProfile(profile);
    FIELD_IDS.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      data[id] = el.type === "checkbox" ? el.checked : el.value;
    });
    chrome.storage.local.set({ profile: data }, () => {
      const saved = document.getElementById("saved");
      saved.textContent = "Saved ✓";
      setTimeout(() => (saved.textContent = ""), 2000);
    });
  });
}

// --- Document pickers for CV / Cover Letter / Portfolio ---
// Reads the chosen document as a data URL and stores it directly in
// chrome.storage.local (independent of the Save button below), so
// content.js can attach it to file-upload fields with no manual step.
const FILE_KEYS = ["cv", "coverLetter", "portfolio"];

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function refreshFileStatus(key, name) {
  const el = document.getElementById(`${key}FileStatusText`);
  if (!el) return;
  if (name) {
    el.textContent = `✓ ${name}`;
    el.classList.remove("empty");
  } else {
    el.textContent = "No file selected";
    el.classList.add("empty");
  }
}

function setCvImportStatus(text, kind = "") {
  const el = document.getElementById("cvImportStatus");
  if (!el) return;
  el.textContent = text;
  el.classList.remove("ok", "warn");
  if (kind) el.classList.add(kind);
}

async function importProfileFromCvFile(file) {
  setCvImportStatus("Reading CV locally…");
  try {
    const result = await extractProfileFromCvFile(file);
    return result;
  } catch (err) {
    setCvImportStatus(`CV saved, but profile extraction could not read enough text: ${err.message}`, "warn");
    return null;
  }
}

function loadFileStatuses() {
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    FILE_KEYS.forEach((key) => {
      refreshFileStatus(key, data[`${key}FileDataUrl`] ? data[`${key}FileName`] : null);
    });
  });
}

FILE_KEYS.forEach((key) => {
  const input = document.getElementById(`${key}FilePicker`);
  const clearBtn = document.querySelector(`.clear-file-btn[data-key="${key}"]`);

  if (input) {
    input.addEventListener("change", async () => {
      const file = input.files && input.files[0];
      if (!file) return;
      if (!/\.(pdf|doc|docx)$/i.test(file.name)) {
        alert("Please choose a PDF, DOC, or DOCX file.");
        input.value = "";
        return;
      }
      try {
        if (key === "cv") {
          const profile = await getStoredProfileAsync();
          await storeCvAndImportProfile(file, { forceImport: !!profile.importProfileFromCvOnSelect });
          if (!profile.importProfileFromCvOnSelect) {
            setCvImportStatus(`CV saved locally: ${file.name}. Profile auto-import is off; click “Fill profile from saved CV now” when you want to update the profile from it.`, "ok");
          }
        } else {
          const dataUrl = await fileToDataUrl(file);
          const data = await getStoredProfileAsync();
          data[`${key}FileDataUrl`] = dataUrl;
          data[`${key}FileName`] = file.name;
          await setStoredProfileAsync(data);
          refreshFileStatus(key, file.name);
        }
      } catch (err) {
        if (key === "cv") {
          // Even if parsing fails, preserve the selected CV for job-site upload.
          try {
            const data = await getStoredProfileAsync();
            data.cvFileDataUrl = await fileToDataUrl(file);
            data.cvFileName = file.name;
            await setStoredProfileAsync(data);
            refreshFileStatus("cv", file.name);
          } catch (_saveErr) {}
          setQuickCvImportStatus(`The CV was saved, but profile details could not be extracted: ${err.message}`, "warn");
          setCvImportStatus(`CV saved, but profile extraction failed: ${err.message}`, "warn");
        } else {
          alert(`Could not save the document: ${err.message}`);
        }
      }
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      chrome.storage.local.get("profile", ({ profile }) => {
        const data = normalizeProfile(profile);
        data[`${key}FileDataUrl`] = "";
        data[`${key}FileName`] = "";
        chrome.storage.local.set({ profile: data }, () => {
          refreshFileStatus(key, null);
          if (input) input.value = "";
          if (key === "cv") setCvImportStatus("Choose a CV first. If automatic CV profile import is enabled, selecting it updates the profile immediately; otherwise click “Fill profile from saved CV now”.");
        });
      });
    });
  }
});

function dataUrlToFileForImport(dataUrl, fileName) {
  const [header, payload] = String(dataUrl || "").split(",");
  if (!header || !payload) throw new Error("No readable saved CV data found.");
  const mime = header.match(/^data:([^;]+)/)?.[1] || "application/octet-stream";
  const binary = atob(payload);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new File([bytes], fileName || "cv.pdf", { type: mime });
}

async function importSavedCvIntoProfile() {
  setCvImportStatus("Reading your saved CV locally…");
  chrome.storage.local.get("profile", async ({ profile }) => {
    try {
      const data = normalizeProfile(profile);
      if (!data.cvFileDataUrl || !data.cvFileName) throw new Error("Choose a CV first.");
      const file = dataUrlToFileForImport(data.cvFileDataUrl, data.cvFileName);
      const result = await extractProfileFromCvFile(file);
      const changed = applyCvProfilePatch(data, result.profilePatch);
      chrome.storage.local.set({ profile: data }, () => {
        loadProfile();
        const readable = changed.length ? changed.join(", ") : "no new profile fields";
        const warning = result.warning ? ` ${result.warning}` : "";
        showQuickImportedFields(result.extractedFields || changed);
        setQuickCvImportStatus(`✓ ${changed.length} profile field${changed.length === 1 ? "" : "s"} updated and saved from the stored CV.${warning}`, changed.length ? "ok" : "warn");
        setCvImportStatus(`CV parsed locally (${result.format}). Imported/updated: ${readable}. Review before applying.${warning}`, changed.length ? "ok" : "warn");
      });
    } catch (err) {
      setQuickCvImportStatus(`Could not fill the profile from the CV: ${err.message}`, "warn");
      setCvImportStatus(`CV import failed: ${err.message}`, "warn");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadProfile();
  loadFileStatuses();
  refreshLearnedAnswerCount();

  const quickPicker = document.getElementById("cvProfileImportPicker");
  document.getElementById("chooseCvAndFillBtn")?.addEventListener("click", () => quickPicker?.click());
  quickPicker?.addEventListener("change", async () => {
    const file = quickPicker.files?.[0];
    if (!file) return;
    try {
      await storeCvAndImportProfile(file, { forceImport: true });
    } catch (err) {
      setQuickCvImportStatus(`Could not fill the profile from the CV: ${err.message}`, "warn");
    } finally {
      quickPicker.value = "";
    }
  });
  document.getElementById("fillFromSavedCvBtn")?.addEventListener("click", importSavedCvIntoProfile);
  document.getElementById("importCvProfileBtn")?.addEventListener("click", importSavedCvIntoProfile);
  document.getElementById("clearLearnedAnswers")?.addEventListener("click", () => {
    if (!confirm("Delete all learned answers? Your normal profile settings and uploaded documents will not be affected.")) return;
    chrome.storage.local.set({ learnedAnswers: { version: 2, records: {} } }, refreshLearnedAnswers);
  });
  document.getElementById("refreshLearnedAnswers")?.addEventListener("click", refreshLearnedAnswers);
  document.getElementById("learnedAnswerSearch")?.addEventListener("input", (event) => {
    learnedAnswerFilter = event.target.value || "";
    refreshLearnedAnswers();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.learnedAnswers) refreshLearnedAnswers();
  });
  if (location.hash === "#saved-answers") {
    setTimeout(() => document.getElementById("saved-answers")?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  }
});
document.getElementById("saveBtn").addEventListener("click", saveProfile);
