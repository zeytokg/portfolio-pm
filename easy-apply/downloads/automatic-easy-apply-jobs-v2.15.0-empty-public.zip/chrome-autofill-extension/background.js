// Sensitive credentials/identifiers must never persist in learned-answer storage.
const SENSITIVE_NEVER_STORE_RE = /\b(?:password|passcode|passphrase|pin(?:\s*(?:code|number))?|one[-\s]?time(?:\s*(?:password|passcode|code))?|otp|verification\s*code|security\s*code|authentication\s*code|auth\s*code|2fa|mfa|recovery\s*code|backup\s*code|passport(?:\s*(?:number|no\.?|id))?|national\s*(?:id|identity)(?:\s*(?:number|no\.?))?|government\s*(?:id|identity)(?:\s*(?:number|no\.?))?|identity\s*(?:document|number|no\.?)|social\s*security(?:\s*(?:number|no\.?))?|ssn|tax(?:payer)?\s*(?:id|identification|number|no\.?)|fiscal\s*code|codice\s*fiscale|driver'?s?\s*licen[cs]e(?:\s*(?:number|no\.?))?|residence\s*permit(?:\s*(?:number|no\.?))?|bank\s*account(?:\s*(?:number|no\.?))?|iban|routing\s*(?:number|no\.?)|sort\s*code|swift|bic|credit\s*card|debit\s*card|card\s*(?:number|no\.?)|cvv|cvc|card\s*security\s*code|api\s*key|secret\s*key|access\s*token|security\s*(?:answer|question))\b/i;

function purgeSensitiveLearnedAnswers() {
  chrome.storage.local.get("learnedAnswers", ({ learnedAnswers }) => {
    if (!learnedAnswers?.records) return;
    let changed = learnedAnswers.version !== 2;
    const records = {};
    Object.entries(learnedAnswers.records).forEach(([key, record]) => {
      const text = `${record?.question || ""} ${record?.questionNorm || ""}`;
      if (SENSITIVE_NEVER_STORE_RE.test(text)) { changed = true; return; }
      records[key] = record;
    });
    if (changed) chrome.storage.local.set({ learnedAnswers: { version: 2, records } });
  });
}

async function readBundledJson(name, fallback) {
  try {
    const response = await fetch(chrome.runtime.getURL(name));
    if (!response.ok) return fallback;
    return await response.json();
  } catch (_err) {
    return fallback;
  }
}

async function seedBundledPresets() {
  const [presetProfile, presetAnswers] = await Promise.all([
    readBundledJson("preset-profile.json", {}),
    readBundledJson("preset-learned-answers.json", { version: 2, records: {} }),
  ]);
  chrome.storage.local.get(["profile", "learnedAnswers"], ({ profile, learnedAnswers }) => {
    const changes = {};
    // Personalized builds may ship a starter profile. Public builds keep this
    // file empty, so no profile object is created until the user sets one up.
    // On an update, only backfill missing/blank values from the preset; never
    // overwrite a value the applicant already edited in local storage.
    if (presetProfile && Object.keys(presetProfile).length) {
      if (!profile) {
        changes.profile = presetProfile;
      } else {
        const merged = { ...profile };
        let changed = false;
        Object.entries(presetProfile).forEach(([key, value]) => {
          const current = merged[key];
          const isBlank = current === undefined || current === null || current === "";
          if (isBlank && value !== undefined && value !== null && value !== "") {
            merged[key] = value;
            changed = true;
          }
        });
        if (changed) changes.profile = merged;
      }
    }

    const incoming = presetAnswers?.records || {};
    if (Object.keys(incoming).length) {
      const current = learnedAnswers?.records || {};
      changes.learnedAnswers = { version: 2, records: { ...incoming, ...current } };
    }
    if (Object.keys(changes).length) chrome.storage.local.set(changes, purgeSensitiveLearnedAnswers);
    else purgeSensitiveLearnedAnswers();
  });
}

chrome.runtime.onInstalled.addListener(seedBundledPresets);
chrome.runtime.onStartup.addListener(purgeSensitiveLearnedAnswers);
seedBundledPresets();

// Opens extension-owned pages on behalf of content scripts.
// Content scripts cannot use chrome.tabs directly, so the draggable on-page
// assistant routes stable document-picking requests through this worker.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "OPEN_DOCUMENT_MANAGER") return;

  const key = ["cv", "coverLetter", "portfolio"].includes(msg.key) ? msg.key : "cv";
  const targetTab = sender.tab?.id || "";
  const params = new URLSearchParams({ key, targetTab: String(targetTab) });
  if (msg.profileImport) params.set("profileImport", "1");
  const url = chrome.runtime.getURL(`documents.html?${params.toString()}`);

  chrome.tabs.query({}, (tabs) => {
    const prefix = chrome.runtime.getURL("documents.html");
    const existing = (tabs || []).find((tab) => String(tab.url || "").startsWith(prefix));
    if (existing?.id) {
      chrome.tabs.update(existing.id, { url, active: true }, (tab) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse({ ok: true, tabId: tab?.id || existing.id });
      });
      return;
    }
    chrome.tabs.create({ url }, (tab) => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      sendResponse({ ok: true, tabId: tab?.id || null });
    });
  });
  return true;
});
