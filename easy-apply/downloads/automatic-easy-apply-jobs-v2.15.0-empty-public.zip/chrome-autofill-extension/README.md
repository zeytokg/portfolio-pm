# Automatic Easy Apply Jobs — v2.15.0 Public / Blank Build

This is the **blank, shareable** Chrome extension build. It contains no preloaded applicant profile, learned answers, CV, cover letter, portfolio file, or other personal application data.

## What v2.15.0 adds

- **One automatic document attempt per page** for CV, cover letter, and portfolio. The extension no longer fans one file out to multiple hidden inputs, dropzones, or iframe copies.
- If the one automatic attempt does not stick, it stops retrying and leaves the normal site picker / manual helper available.
- **Common application fields**: highest education, school/university, field of study, technical/professional certifications, government security clearance, and references.
- **Richer CV import** for professional headline, highest education, field of study, institution, and explicit certification sections when readable text is available.
- Existing local-only learned answers, form-scoped learning, salary fields, language proficiency, work-authorization safeguards, and demographic controls remain available.

## Install locally

1. Unzip the package.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select the `chrome-autofill-extension` folder.
5. Open **Settings** and add your profile/documents, or import a CV locally.

## Privacy

Everything stays in Chrome local extension storage on the device. The extension does not automatically submit applications.
