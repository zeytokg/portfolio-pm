// Local CV/resume parser used by Settings and the popup.
// It never uploads the document anywhere. Parsing happens entirely inside
// Chrome and only extracts conventional profile/contact fields — never legal,
// demographic, salary, consent, or self-identification answers.

function cvUtf8(bytes) {
  try { return new TextDecoder("utf-8", { fatal: false }).decode(bytes); }
  catch (_e) { return ""; }
}

function cvLatin1(bytes) {
  try { return new TextDecoder("latin1", { fatal: false }).decode(bytes); }
  catch (_e) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) out += String.fromCharCode(bytes[i]);
    return out;
  }
}

function cvDecodeEntities(text) {
  return String(text || "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_m, n) => String.fromCodePoint(parseInt(n, 16)));
}

function cvCleanText(text) {
  return String(text || "")
    .replace(/\u0000/g, "")
    .replace(/\r/g, "\n")
    .replace(/[\t\f\v]+/g, " ")
    .replace(/[ ]{2,}/g, " ")
    .replace(/\n[ ]+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function cvDecompress(bytes, format) {
  if (typeof DecompressionStream === "undefined") throw new Error("This Chrome version cannot decompress this CV format.");
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream(format));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function cvU16(view, offset) { return view.getUint16(offset, true); }
function cvU32(view, offset) { return view.getUint32(offset, true); }

async function cvExtractDocxText(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eocd = -1;
  const min = Math.max(0, bytes.length - 22 - 65535);
  for (let i = bytes.length - 22; i >= min; i--) {
    if (i + 4 <= bytes.length && cvU32(view, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("DOCX ZIP directory was not found.");

  const entries = cvU16(view, eocd + 10);
  let cursor = cvU32(view, eocd + 16);
  const wanted = [];
  for (let n = 0; n < entries && cursor + 46 <= bytes.length; n++) {
    if (cvU32(view, cursor) !== 0x02014b50) break;
    const method = cvU16(view, cursor + 10);
    const compSize = cvU32(view, cursor + 20);
    const nameLen = cvU16(view, cursor + 28);
    const extraLen = cvU16(view, cursor + 30);
    const commentLen = cvU16(view, cursor + 32);
    const localOffset = cvU32(view, cursor + 42);
    const name = cvUtf8(bytes.slice(cursor + 46, cursor + 46 + nameLen));
    if (/^word\/(document|header\d*|footer\d*)\.xml$/i.test(name)) {
      wanted.push({ name, method, compSize, localOffset });
    }
    cursor += 46 + nameLen + extraLen + commentLen;
  }
  if (!wanted.length) throw new Error("No readable Word document text was found.");

  const chunks = [];
  for (const entry of wanted) {
    const p = entry.localOffset;
    if (p + 30 > bytes.length || cvU32(view, p) !== 0x04034b50) continue;
    const nameLen = cvU16(view, p + 26);
    const extraLen = cvU16(view, p + 28);
    const dataStart = p + 30 + nameLen + extraLen;
    const compressed = bytes.slice(dataStart, dataStart + entry.compSize);
    let xmlBytes;
    if (entry.method === 0) xmlBytes = compressed;
    else if (entry.method === 8) xmlBytes = await cvDecompress(compressed, "deflate-raw");
    else continue;
    let xml = cvUtf8(xmlBytes);
    xml = xml
      .replace(/<w:tab\b[^>]*\/>/gi, "\t")
      .replace(/<w:(?:br|cr)\b[^>]*\/>/gi, "\n")
      .replace(/<\/w:p>/gi, "\n")
      .replace(/<\/w:tr>/gi, "\n")
      .replace(/<\/w:tc>/gi, "\t")
      .replace(/<[^>]+>/g, "");
    chunks.push(cvDecodeEntities(xml));
  }
  return cvCleanText(chunks.join("\n"));
}

function cvExtractOldDocText(bytes) {
  // Legacy .doc files are binary OLE documents. Without a full Word parser we
  // recover long printable ASCII and UTF-16LE runs; this is intentionally
  // best-effort and is often enough for contact details/title/company.
  const ascii = cvLatin1(bytes);
  const asciiRuns = ascii.match(/[\x20-\x7E\x80-\xFF]{5,}/g) || [];
  let utf16 = "";
  for (let i = 0; i + 1 < bytes.length; i += 2) {
    const code = bytes[i] | (bytes[i + 1] << 8);
    utf16 += code >= 32 && code !== 0xffff ? String.fromCharCode(code) : "\n";
  }
  const utfRuns = utf16.match(/[^\x00-\x1F]{5,}/g) || [];
  return cvCleanText([...asciiRuns, ...utfRuns].join("\n"));
}

function cvPdfBytesFromLiteral(source) {
  const out = [];
  let i = source[0] === "(" ? 1 : 0;
  const limit = source[source.length - 1] === ")" ? source.length - 1 : source.length;
  let depth = 1;
  for (; i < limit && depth > 0; i++) {
    const ch = source[i];
    if (ch === "\\") {
      const next = source[++i];
      if (next == null) break;
      if (next === "n") out.push(10);
      else if (next === "r") out.push(13);
      else if (next === "t") out.push(9);
      else if (next === "b") out.push(8);
      else if (next === "f") out.push(12);
      else if (/[0-7]/.test(next)) {
        let oct = next;
        for (let k = 0; k < 2 && /[0-7]/.test(source[i + 1] || ""); k++) oct += source[++i];
        out.push(parseInt(oct, 8) & 255);
      } else if (next === "\n" || next === "\r") {
        if (next === "\r" && source[i + 1] === "\n") i++;
      } else out.push(next.charCodeAt(0) & 255);
    } else if (ch === "(") { depth++; out.push(ch.charCodeAt(0)); }
    else if (ch === ")") { depth--; if (depth > 0) out.push(ch.charCodeAt(0)); }
    else out.push(ch.charCodeAt(0) & 255);
  }
  return new Uint8Array(out);
}

function cvPdfBytesFromHex(source) {
  let hex = String(source || "").replace(/^</, "").replace(/>$/, "").replace(/\s+/g, "");
  if (hex.length % 2) hex += "0";
  const out = new Uint8Array(Math.floor(hex.length / 2));
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16) || 0;
  return out;
}

function cvPdfObjects(bytes) {
  const raw = cvLatin1(bytes);
  const objects = new Map();
  const re = /(\d+)\s+(\d+)\s+obj\b/g;
  let m;
  while ((m = re.exec(raw))) {
    const number = Number(m[1]);
    const bodyStart = re.lastIndex;
    const endObj = raw.indexOf("endobj", bodyStart);
    if (endObj < 0) break;
    const body = raw.slice(bodyStart, endObj);
    const streamAt = body.indexOf("stream");
    let dict = body;
    let streamBytes = null;
    if (streamAt >= 0) {
      dict = body.slice(0, streamAt);
      let absStart = bodyStart + streamAt + 6;
      if (raw[absStart] === "\r" && raw[absStart + 1] === "\n") absStart += 2;
      else if (raw[absStart] === "\r" || raw[absStart] === "\n") absStart += 1;
      let absEnd = raw.indexOf("endstream", absStart);
      if (absEnd > absStart) {
        while (absEnd > absStart && (raw[absEnd - 1] === "\r" || raw[absEnd - 1] === "\n")) absEnd--;
        streamBytes = bytes.slice(absStart, absEnd);
      }
    }
    objects.set(number, { number, body, dict, streamBytes });
    re.lastIndex = endObj + 6;
  }
  return objects;
}

function cvPdfAscii85Decode(bytes) {
  let text = cvLatin1(bytes).replace(/\s+/g, "");
  text = text.replace(/^<~/, "").replace(/~>.*$/, "");
  const out = [];
  let group = [];
  const flush = (partial = false) => {
    if (!group.length) return;
    const original = group.length;
    while (group.length < 5) group.push(84); // 'u' padding
    let value = 0;
    for (const d of group) value = value * 85 + d;
    const b = [(value >>> 24) & 255, (value >>> 16) & 255, (value >>> 8) & 255, value & 255];
    const count = partial ? Math.max(0, original - 1) : 4;
    out.push(...b.slice(0, count));
    group = [];
  };
  for (const ch of text) {
    if (ch === "z" && group.length === 0) { out.push(0, 0, 0, 0); continue; }
    const code = ch.charCodeAt(0);
    if (code < 33 || code > 117) continue;
    group.push(code - 33);
    if (group.length === 5) flush(false);
  }
  if (group.length) flush(true);
  return new Uint8Array(out);
}

function cvPdfAsciiHexDecode(bytes) {
  let hex = cvLatin1(bytes).replace(/\s+/g, "").replace(/>.*/, "");
  if (hex.length % 2) hex += "0";
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16) || 0;
  return out;
}

async function cvPdfDecodeObjectStream(obj) {
  if (!obj?.streamBytes) return null;
  const filterPart = obj.dict.match(/\/Filter\s*(\[[^\]]*\]|\/[A-Za-z0-9]+)/)?.[1] || "";
  const filters = [...filterPart.matchAll(/\/([A-Za-z0-9]+)/g)].map((m) => m[1]);
  let data = obj.streamBytes;
  for (const filter of filters) {
    if (/ASCII85Decode|A85/i.test(filter)) data = cvPdfAscii85Decode(data);
    else if (/ASCIIHexDecode|AHx/i.test(filter)) data = cvPdfAsciiHexDecode(data);
    else if (/FlateDecode|Fl/i.test(filter)) {
      try { data = await cvDecompress(data, "deflate"); }
      catch (_e) {
        try { data = await cvDecompress(data, "deflate-raw"); }
        catch (_e2) { return null; }
      }
    } else if (/^Crypt$/i.test(filter)) continue;
    else return null;
  }
  return data;
}

async function cvPdfExpandObjectStreams(objects) {
  const initial = [...objects.values()];
  for (const obj of initial) {
    if (!/\/Type\s*\/ObjStm\b/.test(obj.dict) || !obj.streamBytes) continue;
    const n = Number(obj.dict.match(/\/N\s+(\d+)/)?.[1] || 0);
    const first = Number(obj.dict.match(/\/First\s+(\d+)/)?.[1] || 0);
    if (!n || !first) continue;
    const decoded = await cvPdfDecodeObjectStream(obj);
    if (!decoded) continue;
    const text = cvLatin1(decoded);
    const head = text.slice(0, first).trim().split(/\s+/).map(Number);
    const pairs = [];
    for (let i = 0; i + 1 < head.length && pairs.length < n; i += 2) {
      if (Number.isFinite(head[i]) && Number.isFinite(head[i + 1])) pairs.push([head[i], head[i + 1]]);
    }
    for (let i = 0; i < pairs.length; i++) {
      const [number, offset] = pairs[i];
      const nextOffset = i + 1 < pairs.length ? pairs[i + 1][1] : text.length - first;
      const body = text.slice(first + offset, first + nextOffset).trim();
      if (number && body && !objects.has(number)) objects.set(number, { number, body, dict: body, streamBytes: null, virtual: true });
    }
  }
}

function cvPdfUnicodeFromHex(hex) {
  hex = String(hex || "").replace(/\s+/g, "");
  if (!hex) return "";
  if (hex.length % 2) hex += "0";
  const bytes = cvPdfBytesFromHex(`<${hex}>`);
  let start = 0;
  if (bytes[0] === 0xfe && bytes[1] === 0xff) start = 2;
  // ToUnicode destinations are normally UTF-16BE, including surrogate pairs.
  if ((bytes.length - start) % 2 === 0) {
    const units = [];
    for (let i = start; i + 1 < bytes.length; i += 2) units.push((bytes[i] << 8) | bytes[i + 1]);
    if (units.some((u) => u > 0)) {
      try { return String.fromCharCode(...units); } catch (_e) {}
    }
  }
  return cvLatin1(bytes.slice(start));
}

function cvPdfParseCMap(text) {
  const map = new Map();
  const codeLengths = new Set();
  text = String(text || "");
  for (const block of text.matchAll(/begincodespacerange([\s\S]*?)endcodespacerange/g)) {
    for (const m of block[1].matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/g)) codeLengths.add(Math.max(1, m[1].length / 2));
  }
  for (const block of text.matchAll(/beginbfchar([\s\S]*?)endbfchar/g)) {
    for (const m of block[1].matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/g)) {
      map.set(m[1].toUpperCase(), cvPdfUnicodeFromHex(m[2]));
      codeLengths.add(Math.max(1, m[1].length / 2));
    }
  }
  for (const block of text.matchAll(/beginbfrange([\s\S]*?)endbfrange/g)) {
    const body = block[1];
    for (const m of body.matchAll(/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(?:<([0-9A-Fa-f]+)>|\[([^\]]+)\])/g)) {
      const srcStart = parseInt(m[1], 16), srcEnd = parseInt(m[2], 16);
      const srcWidth = m[1].length;
      codeLengths.add(Math.max(1, srcWidth / 2));
      const count = Math.min(4096, Math.max(0, srcEnd - srcStart + 1));
      if (m[3]) {
        const dstWidth = m[3].length;
        const dstStart = BigInt(`0x${m[3]}`);
        for (let i = 0; i < count; i++) {
          const src = (srcStart + i).toString(16).toUpperCase().padStart(srcWidth, "0");
          const dst = (dstStart + BigInt(i)).toString(16).toUpperCase().padStart(dstWidth, "0");
          map.set(src, cvPdfUnicodeFromHex(dst));
        }
      } else {
        const vals = [...String(m[4] || "").matchAll(/<([0-9A-Fa-f]+)>/g)].map((x) => x[1]);
        for (let i = 0; i < Math.min(count, vals.length); i++) {
          const src = (srcStart + i).toString(16).toUpperCase().padStart(srcWidth, "0");
          map.set(src, cvPdfUnicodeFromHex(vals[i]));
        }
      }
    }
  }
  if (!codeLengths.size) codeLengths.add(1);
  return { map, codeLengths: [...codeLengths].sort((a, b) => b - a) };
}

function cvPdfDecodeBytes(bytes, fontInfo) {
  if (!bytes?.length) return "";
  if (fontInfo?.map?.size) {
    let out = "";
    for (let i = 0; i < bytes.length;) {
      let hit = false;
      for (const len of fontInfo.codeLengths || [2, 1]) {
        if (i + len > bytes.length) continue;
        let key = "";
        for (let j = 0; j < len; j++) key += bytes[i + j].toString(16).toUpperCase().padStart(2, "0");
        if (fontInfo.map.has(key)) {
          out += fontInfo.map.get(key);
          i += len;
          hit = true;
          break;
        }
      }
      if (!hit) {
        const b = bytes[i++];
        if (b >= 32 && b <= 126) out += String.fromCharCode(b);
      }
    }
    if (out) return out;
  }
  if (bytes.length >= 2 && bytes.length % 2 === 0) {
    let zeros = 0;
    for (let i = 0; i < bytes.length; i += 2) if (bytes[i] === 0) zeros++;
    if (zeros >= Math.max(1, bytes.length / 6)) {
      let s = "";
      for (let i = 0; i + 1 < bytes.length; i += 2) s += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
      return s;
    }
  }
  return cvLatin1(bytes);
}

function cvPdfTokenize(text) {
  const tokens = [];
  let i = 0;
  const ws = /\s/;
  const delim = /[\s\[\]()<>\/%]/;
  function skip() {
    while (i < text.length) {
      if (ws.test(text[i])) { i++; continue; }
      if (text[i] === "%") { while (i < text.length && text[i] !== "\n" && text[i] !== "\r") i++; continue; }
      break;
    }
  }
  function parseLiteral() {
    const start = i;
    i++;
    let depth = 1;
    while (i < text.length && depth > 0) {
      if (text[i] === "\\") { i += 2; continue; }
      if (text[i] === "(") depth++;
      else if (text[i] === ")") depth--;
      i++;
    }
    return { type: "string", bytes: cvPdfBytesFromLiteral(text.slice(start, i)) };
  }
  function parseHex() {
    const start = i++;
    while (i < text.length && text[i] !== ">") i++;
    if (i < text.length) i++;
    return { type: "string", bytes: cvPdfBytesFromHex(text.slice(start, i)) };
  }
  function parseArray() {
    i++;
    const items = [];
    while (i < text.length) {
      skip();
      if (text[i] === "]") { i++; break; }
      if (text[i] === "(") items.push(parseLiteral());
      else if (text[i] === "<" && text[i + 1] !== "<") items.push(parseHex());
      else {
        const start = i;
        while (i < text.length && !/[\s\[\]()<>]/.test(text[i])) i++;
        const word = text.slice(start, i);
        if (/^[-+]?(?:\d+\.?\d*|\.\d+)$/.test(word)) items.push({ type: "number", value: Number(word) });
        else if (word) items.push({ type: "word", value: word });
        else i++;
      }
    }
    return { type: "array", items };
  }
  while (i < text.length) {
    skip();
    if (i >= text.length) break;
    if (text[i] === "(") { tokens.push(parseLiteral()); continue; }
    if (text[i] === "<" && text[i + 1] !== "<") { tokens.push(parseHex()); continue; }
    if (text[i] === "[") { tokens.push(parseArray()); continue; }
    if (text[i] === "/") {
      i++;
      const start = i;
      while (i < text.length && !delim.test(text[i])) i++;
      tokens.push({ type: "name", value: text.slice(start, i) });
      continue;
    }
    if ((text[i] === "<" && text[i + 1] === "<") || (text[i] === ">" && text[i + 1] === ">")) {
      tokens.push({ type: "word", value: text.slice(i, i + 2) }); i += 2; continue;
    }
    const start = i;
    while (i < text.length && !delim.test(text[i])) i++;
    const word = text.slice(start, i);
    if (!word) { i++; continue; }
    if (/^[-+]?(?:\d+\.?\d*|\.\d+)$/.test(word)) tokens.push({ type: "number", value: Number(word) });
    else tokens.push({ type: "word", value: word });
  }
  return tokens;
}

function cvPdfReadableScore(text) {
  text = String(text || "");
  if (!text) return -1;
  const good = (text.match(/[A-Za-zÀ-ž0-9@+.,:/\- ]/g) || []).length;
  const bad = (text.match(/[\u0000-\u0008\u000E-\u001F\uFFFD]/g) || []).length;
  return good / text.length - bad * 0.2;
}

function cvPdfBestDecode(bytes, fontChoices) {
  const candidates = [];
  for (const info of fontChoices || []) candidates.push(cvPdfDecodeBytes(bytes, info));
  candidates.push(cvPdfDecodeBytes(bytes, null));
  candidates.sort((a, b) => cvPdfReadableScore(b) - cvPdfReadableScore(a));
  return candidates[0] || "";
}

function cvPdfExtractTextOperators(text, aliasFonts) {
  const tokens = cvPdfTokenize(text);
  let currentFont = "";
  let stack = [];
  let out = "";
  const add = (s) => {
    s = String(s || "").replace(/[\u0000-\u0008\u000E-\u001F]/g, "");
    if (!s) return;
    // PDF generators commonly emit one Tj per glyph and use Td only to move
    // the text cursor horizontally. The decoded string already contains real
    // space glyphs where the source text has spaces, so inserting an extra
    // space between every Tj corrupts names/emails/phones ("Z e y n e p").
    out += s;
  };
  const newline = () => { if (out && !out.endsWith("\n")) out += "\n"; };
  const fontChoices = () => aliasFonts.get(currentFont) || [];
  const opSet = new Set(["Tf","Tj","TJ","'","\"","Td","TD","Tm","T*","ET","BT","Do","cm","q","Q","re","m","l","c","h","S","s","f","F","f*","B","B*","b","b*","n","w","J","j","M","d","ri","i","gs","Tc","Tw","Tz","TL","Tr","Ts"]);
  for (const tok of tokens) {
    if (tok.type !== "word" || !opSet.has(tok.value)) { stack.push(tok); continue; }
    const op = tok.value;
    if (op === "Tf") {
      const name = [...stack].reverse().find((x) => x.type === "name");
      if (name) currentFont = name.value;
    } else if (op === "Tj" || op === "'") {
      if (op === "'") newline();
      const s = [...stack].reverse().find((x) => x.type === "string");
      if (s) add(cvPdfBestDecode(s.bytes, fontChoices()));
    } else if (op === "\"") {
      newline();
      const s = [...stack].reverse().find((x) => x.type === "string");
      if (s) add(cvPdfBestDecode(s.bytes, fontChoices()));
    } else if (op === "TJ") {
      const arr = [...stack].reverse().find((x) => x.type === "array");
      if (arr) {
        let piece = "";
        for (const item of arr.items) {
          if (item.type === "string") piece += cvPdfBestDecode(item.bytes, fontChoices());
          else if (item.type === "number" && item.value < -120 && piece && !piece.endsWith(" ")) piece += " ";
        }
        add(piece);
      }
    } else if (op === "Td" || op === "TD") {
      // Td/TD is frequently used for *horizontal glyph positioning* inside a
      // single visual line (many CV generators emit one Tj per character).
      // Treating every Td as a line break turns names, emails and phone numbers
      // into one-character-per-line text and makes profile extraction fail.
      const nums = stack.filter((x) => x.type === "number").map((x) => x.value);
      const ty = nums.length ? Number(nums[nums.length - 1]) : 0;
      if (Number.isFinite(ty) && Math.abs(ty) > 0.5) newline();
    } else if (op === "T*" || op === "ET") newline();
    stack = [];
  }
  return cvCleanText(out);
}

async function cvExtractPdfText(bytes) {
  const raw = cvLatin1(bytes);
  const objects = cvPdfObjects(bytes);
  await cvPdfExpandObjectStreams(objects);

  const fontByObject = new Map();
  for (const obj of objects.values()) {
    const cmapRef = obj.dict.match(/\/ToUnicode\s+(\d+)\s+\d+\s+R/)?.[1];
    if (!cmapRef) continue;
    const cmapObj = objects.get(Number(cmapRef));
    const cmapBytes = await cvPdfDecodeObjectStream(cmapObj);
    if (!cmapBytes) continue;
    const parsed = cvPdfParseCMap(cvLatin1(cmapBytes));
    if (parsed.map.size) fontByObject.set(obj.number, parsed);
  }

  const aliasFonts = new Map();
  const addAlias = (alias, fontObjNum) => {
    const info = fontByObject.get(Number(fontObjNum));
    if (!info) return;
    if (!aliasFonts.has(alias)) aliasFonts.set(alias, []);
    if (!aliasFonts.get(alias).includes(info)) aliasFonts.get(alias).push(info);
  };
  for (const obj of objects.values()) {
    const ownName = obj.body.match(/\/Name\s*\/([^\s/<>()\[\]]+)/)?.[1];
    if (ownName) addAlias(ownName, obj.number);
    const fontDicts = [...obj.body.matchAll(/\/Font\s*<<([\s\S]*?)>>/g)];
    for (const fd of fontDicts) {
      for (const m of fd[1].matchAll(/\/([^\s/<>()\[\]]+)\s+(\d+)\s+\d+\s+R/g)) addAlias(m[1], m[2]);
    }
    for (const ref of obj.body.matchAll(/\/Font\s+(\d+)\s+\d+\s+R/g)) {
      const fontDictObj = objects.get(Number(ref[1]));
      if (!fontDictObj) continue;
      for (const m of fontDictObj.body.matchAll(/\/([^\s/<>()\[\]]+)\s+(\d+)\s+\d+\s+R/g)) addAlias(m[1], m[2]);
    }
  }

  const chunks = [];
  for (const obj of objects.values()) {
    if (!obj.streamBytes || /\/Subtype\s*\/Image\b/.test(obj.dict) || /\/Type\s*\/ObjStm\b/.test(obj.dict)) continue;
    if ([...fontByObject.keys()].some((fontId) => objects.get(fontId)?.dict.match(/\/ToUnicode\s+(\d+)/)?.[1] == obj.number)) continue;
    const decoded = await cvPdfDecodeObjectStream(obj);
    if (!decoded || decoded.length > 5_000_000) continue;
    const text = cvLatin1(decoded);
    if (!/\bBT\b[\s\S]*\bET\b/.test(text) || !/(?:\bTj\b|\bTJ\b)/.test(text)) continue;
    const extracted = cvPdfExtractTextOperators(text, aliasFonts);
    if (extracted) chunks.push(extracted);
  }

  // Some simple PDFs use uncompressed page content or no ToUnicode map. Parse
  // any BT/ET sections in the raw file as a conservative fallback.
  if (!chunks.length && /\bBT\b[\s\S]*\bET\b/.test(raw)) {
    const extracted = cvPdfExtractTextOperators(raw, aliasFonts);
    if (extracted) chunks.push(extracted);
  }

  // Link annotations often contain cleaner contact URLs than the visible text.
  const rawContact = raw.match(/(?:https?:\\?\/\\?\/|mailto:)[^\s<>()\[\]{}]{4,}|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
  chunks.push(...rawContact.map((s) => s.replace(/^mailto:/i, "").replace(/\\\//g, "/")));
  return cvCleanText(chunks.join("\n"));
}

function cvNormalizeUrl(url) {
  return String(url || "").replace(/[),.;:]+$/g, "").replace(/\\\//g, "/");
}

function cvUniqueLines(text) {
  const seen = new Set();
  const lines = [];
  String(text || "").split(/\n+/).forEach((line) => {
    const clean = line.replace(/\s+/g, " ").trim();
    if (clean.length < 2 || clean.length > 180) return;
    const key = clean.toLowerCase();
    if (!seen.has(key)) { seen.add(key); lines.push(clean); }
  });
  return lines;
}

function cvLabelValue(lines, labelRe) {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let m = line.match(new RegExp(`^\\s*(?:${labelRe.source})\\s*[:|\\-–—]\\s*(.+)$`, labelRe.flags.replace("g", "")));
    if (m && m[1]?.trim()) return m[1].trim();
    if (new RegExp(`^\\s*(?:${labelRe.source})\\s*$`, labelRe.flags.replace("g", "")).test(line) && lines[i + 1]) return lines[i + 1].trim();
  }
  return "";
}

function cvCleanPhone(value) {
  value = String(value || "").trim();
  if (!value) return "";
  const hasPlus = /^\s*\+/.test(value);
  const digits = value.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) return "";
  // PDF drawing coordinates often look like 179.25 675.41998 2. Reject
  // decimal-like numeric fragments unless the number is explicitly +prefixed.
  const decimalChunks = (value.match(/\d+\.\d+/g) || []).length;
  if (!hasPlus && decimalChunks >= 1) return "";
  if (/^(?:19|20)\d{8,}$/.test(digits)) return "";
  return hasPlus ? `+${digits}` : digits;
}

function cvInferPhoneCountry(phone) {
  const p = String(phone || "").replace(/\s+/g, "");
  const prefixes = [
    ["+90", "Turkey"], ["+39", "Italy"], ["+33", "France"], ["+44", "United Kingdom"],
    ["+49", "Germany"], ["+34", "Spain"], ["+31", "Netherlands"], ["+32", "Belgium"],
    ["+41", "Switzerland"], ["+43", "Austria"], ["+351", "Portugal"], ["+353", "Ireland"],
    ["+46", "Sweden"], ["+47", "Norway"], ["+45", "Denmark"], ["+358", "Finland"],
    ["+48", "Poland"], ["+420", "Czech Republic"], ["+1", "United States"],
  ].sort((a, b) => b[0].length - a[0].length);
  return prefixes.find(([prefix]) => p.startsWith(prefix))?.[1] || "";
}

function cvLooksLikeName(line) {
  line = String(line || "").replace(/[|•·]/g, " ").replace(/\s+/g, " ").trim();
  if (!line || line.length > 60 || /@|https?:|linkedin|github|\d{3,}|\b(?:resume|résumé|curriculum|vitae|experience|education|skills|summary|profile|contact|projects?|certifications?|languages?|product manager|engineer|developer|designer)\b/i.test(line)) return false;
  const words = line.split(/\s+/).filter(Boolean);
  if (words.length < 2 || words.length > 5) return false;
  return words.every((w) => /^[A-Za-zÀ-žİıĞğŞşÇçÖöÜü'’.-]{2,}$/.test(w));
}

function cvTitleCaseWords(value) {
  let clean = String(value || "").trim().replace(/\s+/g, " ");
  const letters = clean.replace(/[^A-Za-zÀ-ž]/g, "");
  if (letters && letters === letters.toUpperCase()) clean = clean.toLowerCase();
  clean = clean.replace(/(^|[\s-])([A-Za-zÀ-ž])/g, (_m, p, c) => p + c.toUpperCase());
  return clean.replace(/\bAi\b/g, "AI").replace(/\bUi\b/g, "UI").replace(/\bUx\b/g, "UX").replace(/\bQa\b/g, "QA").replace(/\bCto\b/g, "CTO").replace(/\bCpo\b/g, "CPO");
}

function cvSmartCompanyCase(value) {
  const clean = String(value || "").trim().replace(/\s+/g, " ");
  const letters = clean.replace(/[^A-Za-zÀ-ž]/g, "");
  if (!letters || letters !== letters.toUpperCase()) return clean;
  return clean.toLowerCase().replace(/(^|[\s&/-])([A-Za-zÀ-ž])/g, (_m, p, c) => p + c.toUpperCase())
    .replace(/\bAi\b/g, "AI").replace(/\bUs\b/g, "US").replace(/\bUk\b/g, "UK");
}

function cvExtractProfileFromText(text) {
  text = cvCleanText(text);
  const lines = cvUniqueLines(text);
  const patch = {};

  const emailLabel = cvLabelValue(lines, /(?:e-?mail|email address)/i);
  const email = emailLabel.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] || text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0];
  if (email) patch.email = email;

  const urls = (text.match(/https?:\/\/[^\s<>()\[\]{}"']+/gi) || []).map(cvNormalizeUrl);
  const linkedIn = urls.find((u) => /linkedin\.com\/in\//i.test(u));
  const github = urls.find((u) => /github\.com\//i.test(u) && !/github\.io/i.test(u));
  const portfolio = urls.find((u) => /portfolio|github\.io|behance\.net|dribbble\.com|notion\.(?:site|so)/i.test(u)) ||
    urls.find((u) => !/linkedin\.com|github\.com|facebook\.com|instagram\.com|x\.com|twitter\.com/i.test(u));
  if (linkedIn) patch.linkedin = linkedIn;
  if (github) patch.github = github;
  if (portfolio) patch.portfolio = portfolio;

  // Phone: prefer an explicitly labelled value. Otherwise only accept a
  // +country-code number. This prevents PDF coordinates from becoming phones.
  const labelledPhone = cvLabelValue(lines, /(?:phone(?: number)?|mobile|telephone|tel\.?|cell(?: phone)?|whatsapp)/i);
  let phone = cvCleanPhone(labelledPhone);
  if (!phone) {
    const plusCandidates = lines.flatMap((line) => line.match(/\+\s*\d{1,3}(?:[ \t().-]*\d){7,14}/g) || []);
    phone = plusCandidates.map(cvCleanPhone).find(Boolean) || "";
  }
  if (phone) {
    patch.phone = phone;
    const phoneCountry = cvInferPhoneCountry(phone);
    if (phoneCountry) patch.phoneCountry = phoneCountry;
  }

  const years = text.match(/\b(\d{1,2})\+?\s*(?:years?|yrs?)\s+(?:of\s+)?(?:professional\s+)?experience\b/i)?.[1];
  if (years) patch.yearsOfExperience = years;

  const summaryHeadingIndex = lines.findIndex((line) => /^(?:professional\s+)?summary$|^profile$|^about\s+me$/i.test(line.trim()));
  if (summaryHeadingIndex >= 0) {
    const sectionHeadRe = /^(?:experience|work experience|employment|education|skills|projects?|certifications?|languages?|contact|awards?|publications?)$/i;
    const summaryLines = [];
    for (const line of lines.slice(summaryHeadingIndex + 1, summaryHeadingIndex + 7)) {
      if (sectionHeadRe.test(line.trim())) break;
      if (line.length >= 20) summaryLines.push(line.trim());
      if (summaryLines.join(" ").length >= 700) break;
    }
    const summary = summaryLines.join(" ").replace(/\s+/g, " ").trim().slice(0, 900);
    if (summary) patch.professionalSummary = summary;
  }
  // Many designed CVs do not print a literal "Summary" heading. In that case,
  // use the introductory paragraph near the top of the document. Wrapped PDF
  // lines are joined until a section/metric line is reached.
  if (!patch.professionalSummary) {
    const topLines = lines.slice(0, 45);
    const stopAt = (line) => /^(?:skills|experience|work experience|employment|education|projects?)$/i.test(line.trim()) ||
      /\b(?:sprint throughput|downloads?|app store titles?|impressions?)\b/i.test(line);
    const start = topLines.findIndex((line) =>
      line.length >= 55 &&
      /\b(?:experience|product|engineer|developer|designer|manager|leader|speciali[sz]|professional)\b/i.test(line) &&
      !/@|https?:\/\//i.test(line)
    );
    if (start >= 0) {
      const parts = [];
      for (let i = start; i < topLines.length && parts.join(" ").length < 900; i++) {
        const line = topLines[i].trim();
        if (i > start && stopAt(line)) break;
        if (line.length < 12 && i > start) break;
        parts.push(line);
        if (/[.!?]$/.test(line) && parts.join(" ").length >= 120 && i + 1 < topLines.length && stopAt(topLines[i + 1])) break;
      }
      const intro = parts.join(" ").replace(/\s+/g, " ").trim().slice(0, 900);
      if (intro.length >= 70) patch.professionalSummary = intro;
    }
  }

  // Prefer a dedicated top-of-CV professional header when present (for
  // example “Senior Product Manager | Agile Delivery | Digital Products & AI”)
  // instead of reducing the headline to only the current job title.
  const headlineLine = lines.slice(0, 28).find((line) => {
    const clean = String(line || "").trim();
    return clean.length >= 12 && clean.length <= 180 &&
      /[|·•]/.test(clean) &&
      /\b(manager|owner|engineer|developer|designer|marketing|sales|finance|operations|analyst|consultant|specialist|director|lead|head|product|project|program)\b/i.test(clean) &&
      !/@|https?:\/\//i.test(clean);
  });
  if (headlineLine) patch.headline = cvTitleCaseWords(headlineLine);

  const explicitTitle = cvLabelValue(lines, /(?:current\s+)?(?:job\s+)?title|current role|position/i);
  const titlePatterns = [
    /\b(?:senior|lead|principal|staff|group|associate|junior|chief)?\s*product\s+manager\b/i,
    /\bhead of product\b/i, /\b(?:senior|lead|principal|staff|associate|junior)?\s*product owner\b/i, /\b(?:senior|lead|principal|staff|associate|junior)?\s*program manager\b/i, /\b(?:senior|lead|principal|staff|associate|junior)?\s*project manager\b/i,
    /\b(?:senior|lead|principal|staff|junior)?\s*(?:software|data|machine learning|ai)\s+engineer\b/i,
    /\b(?:senior|lead|principal|staff|junior)?\s*(?:ux|ui|product)\s+designer\b/i,
  ];
  const setTitleFromLine = (line) => {
    const titleMatch = titlePatterns.map((re) => String(line || "").match(re)).find(Boolean);
    if (!titleMatch) return false;
    patch.currentJobTitle = cvTitleCaseWords(titleMatch[0]);
    if (!patch.headline) patch.headline = patch.currentJobTitle;
    return true;
  };
  if (explicitTitle && explicitTitle.length <= 100) {
    patch.currentJobTitle = explicitTitle;
    if (!patch.headline) patch.headline = explicitTitle;
  } else {
    // Prefer the first role after an Experience/Employment heading over a
    // marketing headline at the top of the CV.
    const experienceIndex = lines.findIndex((line) => /^(?:experience|work experience|employment|professional experience)$/i.test(line.trim()));
    if (experienceIndex >= 0) {
      for (const line of lines.slice(experienceIndex + 1, experienceIndex + 18)) {
        if (setTitleFromLine(line)) break;
      }
    }
    if (!patch.currentJobTitle) {
      for (const line of lines.slice(0, 100)) {
        if (setTitleFromLine(line)) break;
      }
    }
  }
  if (!patch.currentJobTitle) {
    const titleMatch = titlePatterns.map((re) => text.slice(0, 1600).match(re)).find(Boolean);
    if (titleMatch) {
      patch.currentJobTitle = cvTitleCaseWords(titleMatch[0]);
      if (!patch.headline) patch.headline = patch.currentJobTitle;
    }
  }

  const explicitCompany = cvLabelValue(lines, /(?:current\s+)?company|employer|organization|organisation/i);
  if (explicitCompany && explicitCompany.length <= 100) patch.currentCompany = explicitCompany;
  const experienceHeadingIndex = lines.findIndex((line) => /^(?:experience|work experience|employment|professional experience)$/i.test(line.trim()));
  let titleLineIndex = -1;
  if (patch.currentJobTitle) {
    const startAt = experienceHeadingIndex >= 0 ? experienceHeadingIndex + 1 : 0;
    const relative = lines.slice(startAt).findIndex((line) => line.toLowerCase().includes(patch.currentJobTitle.toLowerCase()));
    titleLineIndex = relative >= 0 ? startAt + relative : lines.findIndex((line) => line.toLowerCase().includes(patch.currentJobTitle.toLowerCase()));
  }
  if (!patch.currentCompany && titleLineIndex >= 0) {
    const titleLine = lines[titleLineIndex];
    const atMatch = titleLine.match(/\bat\s+([^|•·–—]{2,60})/i);
    if (atMatch) patch.currentCompany = atMatch[1].trim();
  }
  if (!patch.currentCompany && titleLineIndex >= 0) {
    const titleLine = lines[titleLineIndex];
    // Common CV format: "SENIOR PRODUCT OWNER — COMPANY JUL 2025 — PRESENT".
    const escapedTitle = String(patch.currentJobTitle || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const sepMatch = escapedTitle ? titleLine.match(new RegExp(`${escapedTitle}\\s*[—–|-]\\s*([^—–|]{2,80}?)(?=\\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|20\\d{2}|19\\d{2})\\b|\\s*[—–|]|$)`, "i")) : null;
    if (sepMatch) patch.currentCompany = sepMatch[1].trim();
  }
  if (!patch.currentCompany && titleLineIndex >= 0) {
    const nearby = lines.slice(titleLineIndex + 1, titleLineIndex + 7).find((line) => {
      const clean = line.replace(/^[•·–—|\-\s]+|[•·–—|\-\s]+$/g, "").trim();
      return clean.length >= 2 && clean.length <= 80 &&
        !/^(experience|education|skills|summary|profile|projects|certifications?|languages?)$/i.test(clean) &&
        !/^present$/i.test(clean) &&
        !/^(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(clean) &&
        !/\b(20\d{2}|19\d{2})\b|@|https?:|\b(?:senior|lead|principal|staff|junior)?\s*(?:product\s+manager|product owner|program manager|project manager)\b/i.test(clean);
    });
    if (nearby) patch.currentCompany = nearby.replace(/^[•·–—|\-\s]+|[•·–—|\-\s]+$/g, "").trim();
  }
  if (!patch.currentCompany && patch.currentJobTitle) {
    const flatCompany = text.slice(0, 1600).match(/\bat\s+(.{2,80}?)(?=\s+\d{1,2}\+?\s*(?:years?|yrs?)\s+(?:of\s+)?experience|\s+[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|\s+https?:\/\/|$)/i)?.[1];
    if (flatCompany) patch.currentCompany = flatCompany.replace(/[|•·–—]+$/g, "").trim();
  }
  if (patch.currentCompany) patch.currentCompany = cvSmartCompanyCase(patch.currentCompany);

  const explicitName = cvLabelValue(lines, /(?:full\s+)?name/i);
  const nameLine = (explicitName && cvLooksLikeName(explicitName) ? explicitName : "") || lines.slice(0, 16).find(cvLooksLikeName);
  if (nameLine) {
    const parts = nameLine.replace(/[|•·]/g, " ").split(/\s+/).filter(Boolean);
    patch.firstName = parts.slice(0, -1).join(" ");
    patch.lastName = parts[parts.length - 1];
  }
  // Designed PDFs sometimes place first and last name in separate text boxes.
  // Recombine two adjacent, name-like single-word lines near the top.
  if (!patch.firstName || !patch.lastName) {
    const top = lines.slice(0, 10);
    for (let i = 0; i < top.length - 1; i++) {
      const a = top[i].trim(), b = top[i + 1].trim();
      if (/^[A-Za-zÀ-žİıĞğŞşÇçÖöÜü'’.-]{2,30}$/.test(a) && /^[A-Za-zÀ-žİıĞğŞşÇçÖöÜü'’.-]{2,30}$/.test(b)) {
        const candidate = `${a} ${b}`;
        if (cvLooksLikeName(candidate)) {
          patch.firstName = a;
          patch.lastName = b;
          break;
        }
      }
    }
  }
  if ((!patch.firstName || !patch.lastName) && patch.currentJobTitle) {
    const idx = text.toLowerCase().indexOf(patch.currentJobTitle.toLowerCase());
    if (idx > 0 && idx < 200) {
      const before = text.slice(0, idx).replace(/\s+/g, " ").trim();
      const words = before.split(/\s+/).filter(Boolean).slice(-5);
      for (let n = Math.min(4, words.length); n >= 2; n--) {
        const candidate = words.slice(-n).join(" ");
        if (cvLooksLikeName(candidate)) {
          const parts = candidate.split(/\s+/);
          patch.firstName = parts.slice(0, -1).join(" ");
          patch.lastName = parts[parts.length - 1];
          break;
        }
      }
    }
  }

  const addressLabel = cvLabelValue(lines, /(?:street\s+)?address|home address/i);
  const addressLine = addressLabel || lines.find((line) => /\b(?:street|st\.?|road|rd\.?|avenue|ave\.?|boulevard|blvd\.?|lane|ln\.?|drive|dr\.?|via|viale|piazza|corso)\b/i.test(line) && /\d/.test(line) && line.length <= 120);
  if (addressLine) patch.address = addressLine.replace(/\s+/g, " ").trim();

  const postalLabel = cvLabelValue(lines, /(?:postal|zip)\s*code|postcode/i);
  const postal = postalLabel.match(/\b[A-Z0-9][A-Z0-9 -]{2,9}\b/i)?.[0] || "";
  if (postal) patch.postalCode = postal.trim();
  else {
    // Only infer an unlabeled numeric postal code from a line that also looks
    // like a location/address, never from arbitrary PDF numeric content.
    const postalLine = lines.find((line) => /\b\d{4,6}\b/.test(line) && /,|\b(?:street|road|avenue|via|city|italy|france|germany|spain|turkey|türkiye|united kingdom|usa|united states)\b/i.test(line));
    const p = postalLine?.match(/\b\d{4,6}\b/)?.[0];
    if (p) patch.postalCode = p;
  }

  const city = cvLabelValue(lines, /city/i);
  const region = cvLabelValue(lines, /(?:state|province|region)/i);
  const country = cvLabelValue(lines, /country/i);
  const location = cvLabelValue(lines, /location/i);
  if (city && city.length <= 80) patch.city = city;
  if (region && region.length <= 80) patch.region = region;
  if (country && country.length <= 80) patch.country = country;
  if (location && location.length <= 140) patch.locationDisplay = location;
  else if (city && country) patch.locationDisplay = `${city}, ${country}`;
  if (!patch.locationDisplay || !patch.city || !patch.country) {
    const countryNames = "Italy|France|Germany|Spain|Portugal|Netherlands|Belgium|Switzerland|Austria|Ireland|Sweden|Norway|Denmark|Finland|Poland|Turkey|Türkiye|United Kingdom|United States|USA|Canada|Australia|New Zealand";
    const lm = text.match(new RegExp(`\\b([A-ZÀ-ÖØ-Þİ][A-Za-zÀ-žİıĞğŞşÇçÖöÜü .'-]{1,45}),\\s*(${countryNames})\\b`, "i"));
    if (lm) {
      if (!patch.city) patch.city = lm[1].trim();
      if (!patch.country) patch.country = lm[2].trim();
      if (!patch.locationDisplay) patch.locationDisplay = `${lm[1].trim()}, ${lm[2].trim()}`;
    }
  }

  // General education fields used by many ATSs. Choose the highest degree we
  // can identify and pair it with the nearest institution / field of study.
  const degreeDefs = [
    { level: "Doctorate / PhD", re: /\b(?:ph\.?d\.?|doctorate|doctoral degree)\b/i },
    { level: "Master's Degree", re: /\b(?:m\.?sc\.?|m\.?a\.?|m\.?eng\.?|mba|master'?s?(?: degree)?)\b/i },
    { level: "Bachelor's Degree", re: /\b(?:b\.?sc\.?|b\.?a\.?|b\.?eng\.?|bachelor'?s?(?: degree)?)\b/i },
    { level: "Associate Degree", re: /\bassociate(?:'s)? degree\b/i },
    { level: "High School", re: /\bhigh school|secondary school\b/i },
  ];
  let degreeHit = null;
  for (const def of degreeDefs) {
    const idx = lines.findIndex((line) => def.re.test(line));
    if (idx >= 0) { degreeHit = { ...def, idx, line: lines[idx] }; break; }
  }
  if (degreeHit) {
    patch.highestEducation = degreeHit.level;
    const fieldMatch = degreeHit.line.match(/\b(?:in|of)\s+(.{3,100})$/i);
    if (fieldMatch) {
      const field = fieldMatch[1].replace(/[|•·]/g, " ").replace(/\s+/g, " ").trim();
      if (field && !/university|college|school/i.test(field)) patch.fieldOfStudy = cvTitleCaseWords(field);
    }
    const nearby = lines.slice(degreeHit.idx + 1, degreeHit.idx + 7);
    const school = nearby.find((line) =>
      /(?:university|universit[aà]|college|institute|school|academy|polytechnic)/i.test(line) &&
      line.length <= 140 && !/scholarship|coursework/i.test(line)
    );
    if (school) patch.schoolUniversity = school.replace(/[|•·]+$/g, "").trim();
  }

  // Certification lists are safe career data to import when the CV explicitly
  // contains a Certifications/Licenses section. Absence of such a section is
  // not treated as “No” because a CV may simply omit it.
  const certHeading = lines.findIndex((line) => /^(?:certifications?|licenses?(?:\s*&\s*certifications?)?)$/i.test(line.trim()));
  if (certHeading >= 0) {
    const sectionStop = /^(?:experience|work experience|employment|education|skills|projects?|languages?|contact|awards?|publications?|references?)$/i;
    const certLines = [];
    for (const line of lines.slice(certHeading + 1, certHeading + 9)) {
      const clean = line.replace(/^[•·–—|\-\s]+/, "").trim();
      if (!clean || sectionStop.test(clean)) break;
      if (clean.length >= 3 && clean.length <= 180) certLines.push(clean);
    }
    if (certLines.length) {
      patch.certifications = certLines.join("; ").slice(0, 900);
      patch.hasTechnicalCertifications = "Yes";
    }
  }

  return patch;
}

async function extractProfileFromCvFile(file) {
  if (!file) throw new Error("No CV selected.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  const name = String(file.name || "").toLowerCase();
  let text = "";
  let format = "unknown";
  if (name.endsWith(".pdf") || file.type === "application/pdf") {
    format = "PDF";
    text = await cvExtractPdfText(bytes);
  } else if (name.endsWith(".docx") || /officedocument\.wordprocessingml/.test(file.type || "")) {
    format = "DOCX";
    text = await cvExtractDocxText(bytes);
  } else if (name.endsWith(".doc") || file.type === "application/msword") {
    format = "DOC";
    text = cvExtractOldDocText(bytes);
  } else if (name.endsWith(".txt") || /^text\//.test(file.type || "")) {
    format = "text";
    text = cvUtf8(bytes);
  } else {
    throw new Error("CV parser supports PDF, DOCX, DOC, and TXT.");
  }

  const profilePatch = cvExtractProfileFromText(text);
  const extractedFields = Object.keys(profilePatch);
  let warning = "";
  if (!extractedFields.length) warning = "No reliable contact/career fields were detected. If this is an image-only/scanned PDF, use a text-based PDF or DOCX.";
  else if (text.length < 80) warning = "Only a small amount of readable text could be extracted; review the imported fields.";
  return { format, text, profilePatch, extractedFields, warning };
}

function applyCvProfilePatch(profile, patch) {
  const allowed = new Set([
    "firstName", "lastName", "email", "phone", "phoneCountry", "linkedin", "portfolio", "github",
    "yearsOfExperience", "currentJobTitle", "currentCompany", "headline", "professionalSummary",
    "highestEducation", "schoolUniversity", "fieldOfStudy", "hasTechnicalCertifications", "certifications",
    "address", "postalCode", "city", "region", "country", "locationDisplay",
  ]);
  const changed = [];
  Object.entries(patch || {}).forEach(([key, value]) => {
    if (!allowed.has(key) || !String(value || "").trim()) return;
    const next = String(value).trim();
    if (profile[key] !== next) { profile[key] = next; changed.push(key); }
  });
  return changed;
}
