(() => {
  const TR = {
    "Fill this application in one click": "Bu başvuruyu tek tıkla doldur",
    "Edit Profile": "Profili Düzenle",
    "✨ Fill this page": "✨ Bu sayfayı doldur",
    "↗ Open on-page assistant": "↗ Sayfa içi asistanı aç",
    "📄 Import profile from CV": "📄 Profili CV'den içe aktar",
    "Auto-fill on detect": "Form algılanınca otomatik doldur",
    "Fill forms as soon as they're found — no click needed": "Form bulunur bulunmaz doldur — tıklama gerekmez",
    "⏸️ Pause auto-fill any time using the toggle above.": "⏸️ Yukarıdaki düğmeyle otomatik doldurmayı istediğin zaman duraklat.",
    "Remember new answers": "Yeni cevapları hatırla",
    "Save safe manual answers locally — credentials and ID numbers are never stored": "Güvenli manuel cevapları yerelde kaydet — şifreler ve kimlik numaraları asla saklanmaz",
    "View / delete saved answers": "Kayıtlı cevapları gör / sil",
    "📎 Documents from your PC": "📎 Bilgisayarındaki dosyalar",
    "Choose from your PC in a stable extension page; it is then uploaded to the matching application field automatically.": "Dosyayı sabit uzantı sayfasından bilgisayarından seç; ardından uygun başvuru alanına otomatik yüklenir.",
    "CV / Resume": "CV / Özgeçmiş",
    "Cover Letter": "Ön Yazı",
    "Portfolio": "Portföy",
    "Choose from PC": "Bilgisayardan seç",
    "Not selected": "Seçilmedi",
    "🔴 Unanswered fields": "🔴 Cevaplanmamış alanlar",
    "Scanning this application…": "Başvuru taranıyor…",
    "Green": "Yeşil",
    "Blue": "Mavi",
    "Orange": "Turuncu",
    "Red": "Kırmızı",
    " — filled": " — dolduruldu",
    " — estimated value, double-check": " — tahmini değer, kontrol et",
    " — manual/legal review": " — manuel/hukuki kontrol",
    " — still unanswered; click it in the list above": " — hâlâ boş; yukarıdaki listeden tıkla",
    " — still unanswered": " — hâlâ boş",
    "— filled": "— dolduruldu",
    "— estimated value, double-check": "— tahmini değer, kontrol et",
    "— manual/legal review": "— manuel/hukuki kontrol",
    "— still unanswered; click it in the list above": "— hâlâ boş; yukarıdaki listeden tıkla",
    "— still unanswered": "— hâlâ boş",
    "Drag the on-page helper anywhere you like. Its panel moves together with the icon and the position is remembered.": "Sayfa içi asistanı istediğin yere sürükle. Panel ikonla birlikte hareket eder ve konumu hatırlanır.",
    "Automatic Easy Apply Jobs — Settings": "Automatic Easy Apply Jobs — Ayarlar",
    "Stored only in this browser, on this device. Nothing is sent to any server. Everyone using this extension edits their own info here — nothing below is shared between installs.": "Yalnızca bu tarayıcıda ve bu cihazda saklanır. Hiçbir sunucuya gönderilmez. Uzantıyı kullanan herkes kendi bilgilerini burada düzenler; aşağıdaki veriler kurulumlar arasında paylaşılmaz.",
    "Automation": "Otomasyon",
    "Automatically fill the form as soon as one is detected (no click needed)": "Form algılanır algılanmaz otomatik doldur (tıklama gerekmez)",
    "You can still click \"Fill this page\" any time to re-run it (e.g. after fields load later).": "Daha sonra yüklenen alanlar için istediğin zaman \"Bu sayfayı doldur\" düğmesine tekrar basabilirsin.",
    "Remember new answers I enter manually and reuse them later": "Manuel girdiğim yeni cevapları hatırla ve sonra tekrar kullan",
    "Only manual answers are learned. The extension’s own auto-filled values are ignored. Learned answers stay on this device. Passwords, PIN/OTP/security codes, passport/government ID numbers, and bank/card credentials are never learned or auto-filled.": "Yalnızca manuel cevaplar öğrenilir. Uzantının kendi otomatik doldurduğu değerler yok sayılır. Öğrenilen cevaplar bu cihazda kalır. Şifreler, PIN/OTP/güvenlik kodları, pasaport/resmî kimlik numaraları ve banka/kart bilgileri asla öğrenilmez veya otomatik doldurulmaz.",
    "When I choose a CV, automatically fill and save my profile from the CV": "CV seçtiğimde profilimi CV'den otomatik doldur ve kaydet",
    "Extracts only normal contact/career details such as name, email, phone, links, title, company and location. It never infers diversity, consent, salary or legal-work answers from a CV.": "Yalnızca ad, e-posta, telefon, bağlantılar, unvan, şirket ve konum gibi normal iletişim/kariyer bilgilerini çıkarır. Diversity, consent, maaş veya çalışma hakkı cevaplarını CV'den tahmin etmez.",
    "0 learned answers": "0 öğrenilmiş cevap",
    "Clear all learned answers": "Tüm öğrenilmiş cevapları sil",
    "Saved / Learned Answers": "Kayıtlı / Öğrenilmiş Cevaplar",
    "Review answers learned from your manual form entries. Delete any answer you do not want reused. Sensitive credentials and government/financial identifiers are never stored.": "Manuel form girişlerinden öğrenilen cevapları incele. Tekrar kullanılmasını istemediğin cevapları sil. Hassas giriş bilgileri ile resmî/finansal kimlik numaraları asla saklanmaz.",
    "Search saved questions or answers": "Kayıtlı soru veya cevaplarda ara",
    "Search saved answers": "Kayıtlı cevaplarda ara",
    "Refresh": "Yenile",
    "Personal Info": "Kişisel Bilgiler",
    "Fill my profile automatically from a CV": "Profilimi CV'den otomatik doldur",
    "Choose your CV from your computer. The extension reads it locally, fills the profile fields below, and saves them. The same CV is also stored for Resume/CV upload fields on job applications.": "CV'ni bilgisayarından seç. Uzantı dosyayı yerel olarak okur, aşağıdaki profil alanlarını doldurur ve kaydeder. Aynı CV iş başvurularındaki Resume/CV yükleme alanları için de saklanır.",
    "Choose CV → Fill My Profile": "CV Seç → Profilimi Doldur",
    "Fill Again from Saved CV": "Kayıtlı CV'den Tekrar Doldur",
    "No CV profile import has been run yet.": "Henüz CV profil içe aktarma işlemi yapılmadı.",
    "First Name": "Ad",
    "Last Name": "Soyad",
    "Email": "E-posta",
    "Phone": "Telefon",
    "Phone Extension": "Telefon Dahili",
    "Phone Extension / Prefix": "Telefon Dahili / Ön Ek",
    "Phone Country": "Telefon Ülkesi",
    "LinkedIn URL": "LinkedIn URL",
    "Portfolio / Website URL": "Portföy / Web Sitesi URL",
    "GitHub URL": "GitHub URL",
    "Total Experience (years)": "Toplam Deneyim (yıl)",
    "Current Role / Header": "Mevcut Rol / Başlık",
    "Current Job Title": "Mevcut İş Unvanı",
    "Current Company": "Mevcut Şirket",
    "Professional Headline": "Profesyonel Başlık",
    "Pronouns": "Hitap / Pronouns",
    "Date of Birth": "Doğum Tarihi",
    "Birth Day": "Doğum Günü",
    "Birth Month": "Doğum Ayı",
    "Birth Year": "Doğum Yılı",
    "Files (CV / Cover Letter / Portfolio)": "Dosyalar (CV / Ön Yazı / Portföy)",
    "No file selected": "Dosya seçilmedi",
    "Fill profile from saved CV now": "Profili kayıtlı CV'den şimdi doldur",
    "If automatic CV profile import is enabled, choosing a CV updates the profile immediately. Use this button to re-run the import from the saved CV.": "Otomatik CV profil içe aktarma açıksa CV seçmek profili hemen günceller. Kayıtlı CV'den tekrar içe aktarmak için bu düğmeyi kullan.",
    "Portfolio / Work Sample": "Portföy / İş Örneği",
    "Address": "Adres",
    "City": "Şehir",
    "Region": "İl / Bölge",
    "Postal Code": "Posta Kodu",
    "Country": "Ülke",
    "Location autocomplete value": "Konum otomatik tamamlama değeri",
    "Used for “Set Your Location” / Google Places-style fields; city/country fields still use the separate values above.": "“Set Your Location” / Google Places tarzı alanlarda kullanılır; şehir/ülke alanları yukarıdaki ayrı değerleri kullanmaya devam eder.",
    "Compensation & Availability": "Ücret & Uygunluk",
    "Hourly Rate (without VAT)": "Saatlik Ücret (KDV hariç)",
    "Hourly Rate Currency": "Saatlik Ücret Para Birimi",
    "Day Rate": "Günlük Ücret",
    "Monthly Salary": "Aylık Maaş",
    "Annual Salary": "Yıllık Maaş",
    "Salary Expectation (generic field, no period specified)": "Maaş Beklentisi (genel alan, dönem belirtilmemiş)",
    "Salary Currency": "Maaş Para Birimi",
    "Salary Basis": "Maaş Türü",
    "Salary Period": "Maaş Dönemi",
    "Gross": "Brüt",
    "Net": "Net",
    "Annual": "Yıllık",
    "Monthly": "Aylık",
    "Daily": "Günlük",
    "Hourly": "Saatlik",
    "These are your stated targets — check they still fit before submitting each application.": "Bunlar belirttiğin hedeflerdir — her başvuruyu göndermeden önce hâlâ uygun olduklarını kontrol et.",
    "Notice Period / Availability": "İhbar Süresi / Uygunluk",
    "If an application uses a real date field for start date, the extension enters today's local date automatically.": "Başlangıç tarihi gerçek bir tarih alanıysa uzantı cihazındaki bugünün tarihini otomatik girer.",
    "Cover Letter (short version — for small \"why this role\" boxes)": "Ön Yazı (kısa sürüm — küçük \"neden bu rol\" alanları için)",
    "Cover Letter (full text — for large \"cover letter\" boxes)": "Ön Yazı (tam metin — büyük ön yazı alanları için)",
    "Right to Work": "Çalışma Hakkı",
    "Authorized to work in the role country without employer sponsorship (optional default)": "İşveren sponsorluğu olmadan rolün ülkesinde çalışma yetkisi (isteğe bağlı varsayılan)",
    "Legally eligible / right to work in the role country (optional default)": "Rolün ülkesinde yasal çalışma hakkı (isteğe bağlı varsayılan)",
    "Do you have a non-compete that prevents you from working for the employer?": "İşveren için çalışmanı engelleyen bir rekabet yasağın var mı?",
    "Not set — learn/review per application": "Ayarlanmadı — başvuru bazında öğren/kontrol et",
    "Not set — review/learn per application": "Ayarlanmadı — başvuru bazında kontrol et/öğren",
    "Not set": "Ayarlanmadı",
    "Yes": "Evet",
    "No": "Hayır",
    "Consent/attestation questions are never accepted automatically, even when other self-identification answers are filled.": "Diğer kişisel beyan cevapları doldurulsa bile consent/attestation soruları asla otomatik kabul edilmez.",
    "Right to Work Note (for free-text fields)": "Çalışma Hakkı Notu (serbest metin alanları için)",
    "On-site / Office Location Questions": "Ofis / Yerinde Çalışma Soruları",
    "Language Proficiency": "Dil Yeterliliği",
    "Used for \"Language Proficiency in ...\" dropdowns/pill-choices on application forms.": "Başvuru formlarındaki \"Language Proficiency in ...\" dropdown/pill seçeneklerinde kullanılır.",
    "English": "İngilizce",
    "Turkish": "Türkçe",
    "Italian": "İtalyanca",
    "German": "Almanca",
    "French": "Fransızca",
    "Any other language (default answer)": "Diğer diller (varsayılan cevap)",
    "Voluntary Demographic Questions": "İsteğe Bağlı Demografik Sorular",
    "Used only to fill your own voluntary survey answers. If age is set, it is mapped to the matching range offered by each form. Sensitive identity fields left blank are not inferred; set them explicitly or let Remember new answers store your manual selection locally.": "Yalnızca kendi isteğe bağlı anket cevaplarını doldurmak için kullanılır. Yaş girilmişse formdaki uygun yaş aralığına eşlenir. Boş bırakılan hassas kimlik alanları tahmin edilmez; açıkça ayarla veya Yeni cevapları hatırla özelliğinin manuel seçimini yerelde kaydetmesine izin ver.",
    "Age": "Yaş",
    "Age Range": "Yaş Aralığı",
    "Nationality / Ethnic origin when asked": "Uyruk / sorulduğunda etnik köken",
    "Race": "Irk",
    "Ethnicity fallback": "Etnisite yedek cevabı",
    "Hispanic / Latino": "Hispanik / Latin",
    "Disability Status": "Engellilik Durumu",
    "LGBTQIA+ self-identification": "LGBTQIA+ öz tanımlama",
    "Transgender identity": "Transgender kimliği",
    "Sexual Orientation": "Cinsel Yönelim",
    "Communities (multi-select)": "Topluluklar (çoklu seçim)",
    "Veteran Status": "Veteran Durumu",
    "Answer gender with my actual value": "Cinsiyet sorusunu gerçek değerimle cevapla",
    "Gender value": "Cinsiyet değeri",
    "Save": "Kaydet",
    "Choose document from your PC": "Bilgisayarından belge seç",
    "After you choose the file, the extension stores its bytes locally and immediately tries to attach it to the matching field in the application tab.": "Dosyayı seçtikten sonra uzantı dosya içeriğini yerelde saklar ve başvuru sekmesindeki uygun alana hemen eklemeyi dener.",
    "Choose a PDF, DOC, or DOCX file.": "PDF, DOC veya DOCX dosyası seç.",
    "Upload saved file again": "Kayıtlı dosyayı tekrar yükle",
    "Fill profile from saved CV again": "Profili kayıtlı CV'den tekrar doldur",
    "Edit saved profile": "Kayıtlı profili düzenle",
    "Return to application": "Başvuruya dön",
    "If automatic CV profile import is enabled in Settings, choosing a CV here updates the saved profile immediately. The button above can re-run the import. Only readable contact/career fields such as name, email, phone, LinkedIn, portfolio, title, company, experience and location are extracted; demographic, salary, consent, disability, LGBTQIA+, non-compete and work-authorization answers are never inferred from the CV.": "Ayarlar'da otomatik CV profil içe aktarma açıksa burada CV seçmek kayıtlı profili hemen günceller. Yukarıdaki düğme içe aktarmayı tekrar çalıştırabilir. Yalnızca ad, e-posta, telefon, LinkedIn, portföy, unvan, şirket, deneyim ve konum gibi okunabilir iletişim/kariyer alanları çıkarılır; demografik, maaş, consent, engellilik, LGBTQIA+, rekabet yasağı ve çalışma yetkisi cevapları CV'den asla tahmin edilmez.",
    "Choose your CV from your PC": "CV'ni bilgisayarından seç",
    "Choose your Cover Letter from your PC": "Ön yazını bilgisayarından seç",
    "Choose your Portfolio file from your PC": "Portföy dosyanı bilgisayarından seç",
    "CV → Saved Profile": "CV → Kayıtlı Profil",
    "Import your profile from a CV": "Profilini CV'den içe aktar",
    "Ready — form detected": "Hazır — form algılandı",
    "Profile setup needed": "Profil kurulumu gerekli",
    "Auto-fill paused": "Otomatik doldurma duraklatıldı",
    "Waiting for a form": "Form bekleniyor",
    "Application form detected — click to open, drag to move": "Başvuru formu algılandı — açmak için tıkla, taşımak için sürükle",
    "No application form detected yet — drag to move": "Henüz başvuru formu algılanmadı — taşımak için sürükle",
    "Profile setup needed — click to open Settings, drag to move": "Profil kurulumu gerekli — Ayarlar'ı açmak için tıkla, taşımak için sürükle",
    "Auto-fill paused — click to open, drag to move": "Otomatik doldurma duraklatıldı — açmak için tıkla, taşımak için sürükle",
    "Choose or replace a saved file here; it will be attached to matching application fields automatically.": "Buradan kayıtlı bir dosya seç veya değiştir; uygun başvuru alanlarına otomatik eklenir.",
    "✓ No visible unanswered fields found.": "✓ Görünür cevaplanmamış alan bulunamadı.",
    "Unanswered field": "Cevaplanmamış alan",
    "Required · ": "Zorunlu · ",
    "Not filled": "Doldurulmadı",
    " · click to open": " · açmak için tıkla",
    " · click to focus": " · odaklanmak için tıkla",
    "See all profile fields": "Tüm profil alanlarını gör",
    "Hide profile fields": "Profil alanlarını gizle",
    "Saved ✓": "Kaydedildi ✓",
    "Filling...": "Dolduruluyor...",
    "Delete": "Sil",
    "Reusable globally": "Genel olarak tekrar kullanılabilir",
    "this application site": "bu başvuru sitesi",
    "Interface language": "Arayüz dili",
    "Remove stored CV": "Kayıtlı CV'yi kaldır",
    "Remove stored cover letter": "Kayıtlı ön yazıyı kaldır",
    "Remove stored portfolio": "Kayıtlı portföyü kaldır",
    "Reload the application page to enable field scanning.": "Alan taramasını etkinleştirmek için başvuru sayfasını yenile.",
    "No saved answers match your search.": "Aramanla eşleşen kayıtlı cevap yok.",
    "No learned answers yet. Manual answers you choose on job forms will appear here when Remember new answers is enabled.": "Henüz öğrenilmiş cevap yok. Yeni cevapları hatırla açıkken iş formlarında manuel seçtiğin cevaplar burada görünür.",
    "Saved question": "Kayıtlı soru",
    "Delete this saved answer": "Bu kayıtlı cevabı sil",
    "Delete all learned answers? Your normal profile settings and uploaded documents will not be affected.": "Tüm öğrenilmiş cevaplar silinsin mi? Normal profil ayarların ve yüklediğin dosyalar etkilenmez.",
    "Please choose a PDF, DOC, or DOCX file.": "Lütfen PDF, DOC veya DOCX dosyası seç.",
    "Stored document removed.": "Kayıtlı belge kaldırıldı.",
    "No response from this page. Try reloading it.": "Bu sayfadan yanıt alınamadı. Sayfayı yenilemeyi dene.",
    'Set up your profile first ("Edit Profile").': 'Önce profilini ayarla ("Profili Düzenle").',
    "Something went wrong filling this page: ": "Bu sayfa doldurulurken bir sorun oluştu: ",
    "Couldn't run on this page: ": "Bu sayfada çalıştırılamadı: ",
    "Could not open the on-page assistant. Reload the application page once and try again.": "Sayfa içi asistan açılamadı. Başvuru sayfasını bir kez yenileyip tekrar dene.",
    "Phone Extension (blank if none)": "Telefon Dahili / Ön Ek (yoksa boş bırak)",
    "Years of Experience": "Deneyim Yılı",
    "Non-compete in place": "Rekabet yasağı var",
    "Region / Province": "İl / Bölge",
    "Location / City autocomplete": "Konum / Şehir otomatik tamamlama",
    "Cadastral Info": "Kadastro Bilgisi",
    "Salary Expectation": "Maaş Beklentisi",
    "Authorized to work without sponsorship": "Sponsor olmadan çalışma yetkisi",
    "Legally eligible / right to work": "Yasal çalışma hakkı",
    "Nationality": "Uyruk",
    "Ethnicity": "Etnisite",
    "LGBTQIA+": "LGBTQIA+",
    "Transgender": "Transgender",
    "Sexual Orientation (comma-separated if multiple)": "Cinsel Yönelim (birden fazlaysa virgülle ayır)",
    "Communities (comma-separated if multiple)": "Topluluklar (birden fazlaysa virgülle ayır)",
    "Cover Letter (short)": "Ön Yazı (kısa)",
    "Cover Letter (full)": "Ön Yazı (tam)",
    "Right to Work Note": "Çalışma Hakkı Notu",
    "Other languages (default)": "Diğer diller (varsayılan)",
    "Remember new manual answers": "Yeni manuel cevapları hatırla",
    "Answer gender question automatically": "Cinsiyet sorusunu otomatik cevapla",
    "No Relevant Proficiency (A1, A2)": "Temel Seviye (A1, A2)",
    "Limited Working Proficiency (B1)": "Sınırlı Çalışma Yeterliliği (B1)",
    "Professional Working Proficiency (B2)": "Profesyonel Çalışma Yeterliliği (B2)",
    "Full Professional Proficiency (C1)": "Tam Profesyonel Yeterlilik (C1)",
    "Native / Bilingual Proficiency (C2)": "Ana Dil / İki Dilli Yeterlilik (C2)"
  };

  let currentLang = "en";
  const textOriginal = new WeakMap();
  const attrOriginal = new WeakMap();

  function dynamicTR(text) {
    let m;
    if ((m = text.match(/^(\d+) learned answer(?:s)?$/))) return `${m[1]} öğrenilmiş cevap`;
    if ((m = text.match(/^Save safe manual answers locally — credentials and ID numbers are never stored · (\d+) learned$/))) return `Güvenli manuel cevapları yerelde kaydet — şifreler ve kimlik numaraları asla saklanmaz · ${m[1]} öğrenilmiş`;
    if ((m = text.match(/^Updated (.+)$/))) return `Güncellendi ${m[1]}`;
    if ((m = text.match(/^Site-specific · (.+)$/))) return `Siteye özel · ${m[1]}`;
    if ((m = text.match(/^(\d+) fields filled, (\d+) still unanswered, (\d+) upload helper\(s\)\.$/))) return `${m[1]} alan dolduruldu, ${m[2]} alan hâlâ boş, ${m[3]} yükleme yardımcısı.`;
    if ((m = text.match(/^✓ Uploaded to (\d+) matching (.+) field(?:s)?\.$/))) return `✓ ${m[1]} eşleşen ${m[2]} alanına yüklendi.`;
    if ((m = text.match(/^✓ Sent (.+) to (\d+) matching dropzone(?:s)?\. Check the application field for the filename\.$/))) return `✓ ${m[1]} ${m[2]} eşleşen dropzone'a gönderildi. Dosya adını başvuru alanında kontrol et.`;
    if ((m = text.match(/^Profile updated from CV: (.+)\.$/))) return `Profil CV'den güncellendi: ${m[1]}.`;
    if ((m = text.match(/^Fields extracted from CV: (.+)$/))) return `CV'den çıkarılan alanlar: ${m[1]}`;
    if ((m = text.match(/^✓ (.+)$/))) return `✓ ${m[1]}`;
    return text;
  }

  function t(text) {
    if (currentLang !== "tr" || typeof text !== "string") return text;
    if (TR[text] != null) return TR[text];
    const normalized = text.replace(/\s+/g, " ").trim();
    if (TR[normalized] != null) return TR[normalized];
    return dynamicTR(text);
  }

  function translateTextNode(node) {
    if (!textOriginal.has(node)) textOriginal.set(node, node.nodeValue);
    const original = textOriginal.get(node);
    if (!original || !original.trim()) return;
    const lead = original.match(/^\s*/)?.[0] || "";
    const tail = original.match(/\s*$/)?.[0] || "";
    const core = original.trim();
    node.nodeValue = `${lead}${currentLang === "tr" ? t(core) : core}${tail}`;
  }

  function translateAttrs(el) {
    const attrs = ["title", "aria-label", "placeholder"];
    let cache = attrOriginal.get(el);
    if (!cache) { cache = {}; attrOriginal.set(el, cache); }
    attrs.forEach((name) => {
      if (!el.hasAttribute?.(name)) return;
      if (!(name in cache)) cache[name] = el.getAttribute(name);
      const original = cache[name] || "";
      el.setAttribute(name, currentLang === "tr" ? t(original) : original);
    });
  }

  function apply(root = document) {
    if (!root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) translateTextNode(node);
    if (root.querySelectorAll) root.querySelectorAll("[title],[aria-label],[placeholder]").forEach(translateAttrs);
    if (root.nodeType === Node.ELEMENT_NODE) translateAttrs(root);
    if (location.protocol === "chrome-extension:") document.documentElement.lang = currentLang;
  }

  function bindLanguageControls(root = document) {
    if (!root?.querySelectorAll) return;
    root.querySelectorAll("[data-ui-language-select]").forEach((select) => {
      if (select.dataset.uiBound === "1") return;
      select.dataset.uiBound = "1";
      select.value = currentLang;
      select.addEventListener("change", () => setLanguage(select.value));
    });
  }

  function setLanguage(lang) {
    currentLang = lang === "tr" ? "tr" : "en";
    chrome.storage.local.set({ uiLanguage: currentLang });
    if (location.protocol === "chrome-extension:") {
      apply(document);
      bindLanguageControls(document);
    }
    window.dispatchEvent(new CustomEvent("easy-apply-language-changed", { detail: { language: currentLang } }));
  }

  const ready = new Promise((resolve) => {
    chrome.storage.local.get("uiLanguage", ({ uiLanguage }) => {
      currentLang = uiLanguage === "tr" ? "tr" : "en";
      resolve(currentLang);
    });
  });

  window.uiI18n = { t, apply, bindLanguageControls, setLanguage, get language() { return currentLang; }, ready };
  window.uiT = t;
  window.uiI18nReady = ready;

  if (location.protocol === "chrome-extension:") {
    const boot = () => ready.then(() => { apply(document); bindLanguageControls(document); });
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
    else boot();
  }
})();
