# Automatic Easy Apply Jobs — Empty / Shareable Build

This is the **empty, shareable version** of the Chrome extension. It contains no preloaded applicant profile, learned answers, CV, or other personal application data.

## What v2.14.3 adds

- Adds a dedicated **Professional Summary** profile field for Summary / Profile Summary / About Me style fields.
- CV import can populate that field when a clearly labelled Summary/Profile section is available.
- Keeps v2.14.1 form-scoped learning: answers are learned only from detected application forms.
- On LinkedIn, search boxes, filters, navigation, messaging, and other non-Easy-Apply controls are ignored.
- Supports learned native/custom dropdowns, radio buttons, and checkbox groups.
- Sensitive credentials and identifiers remain excluded from learned-answer storage.

## Install locally

1. Unzip the package.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select the extension folder.
5. Open **Settings** and add your own profile/documents.

## Publishing note

The ZIP contains no preloaded personal profile, learned answers, or documents. Browser extension storage is separate from the ZIP: for a clean test, remove an older unpacked install (or clear its extension storage) before loading this build.

The extension does not automatically submit applications.
