const params = new URLSearchParams(location.search);
const key = ["cv", "coverLetter", "portfolio"].includes(params.get("key")) ? params.get("key") : "cv";
const targetTabId = Number(params.get("targetTab")) || null;
const profileImportMode = params.get("profileImport") === "1";
const META = {
  cv: { label: "CV / Resume", title: "Choose your CV from your PC" },
  coverLetter: { label: "Cover Letter", title: "Choose your Cover Letter from your PC" },
  portfolio: { label: "Portfolio", title: "Choose your Portfolio file from your PC" },
};

const filePicker = document.getElementById("filePicker");
const statusEl = document.getElementById("status");
const retryBtn = document.getElementById("retryUpload");
const importBtn = document.getElementById("importCv");
const importFieldsEl = document.getElementById("importFields");

document.getElementById("kindLabel").textContent = uiT(profileImportMode && key === "cv" ? "CV → Saved Profile" : META[key].label);
document.getElementById("title").textContent = uiT(profileImportMode && key === "cv" ? "Import your profile from a CV" : META[key].title);
if (key === "cv") importBtn.style.display = "inline-block";

function setStatus(text, kind = "") {
  statusEl.textContent = uiT(text);
  statusEl.className = `status${kind ? ` ${kind}` : ""}`;
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("Could not read file"));
    reader.readAsDataURL(file);
  });
}

function dataUrlToFile(dataUrl, name) {
  const [header, payload] = String(dataUrl || "").split(",");
  if (!header || !payload) throw new Error("Saved file data is incomplete.");
  const mime = header.match(/^data:([^;]+)/)?.[1] || "application/octet-stream";
  const binary = atob(payload);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new File([bytes], name || "document.pdf", { type: mime });
}

async function getStoredProfile() {
  return new Promise((resolve) => chrome.storage.local.get("profile", ({ profile }) => resolve(normalizeProfile(profile))));
}

async function saveStoredFile(file) {
  const dataUrl = await fileToDataUrl(file);
  const profile = await getStoredProfile();
  profile[`${key}FileName`] = file.name;
  profile[`${key}FileDataUrl`] = dataUrl;
  await chrome.storage.local.set({ profile });
  return profile;
}

async function attachNow() {
  if (!targetTabId) {
    setStatus("File saved locally. Open an application tab and use Fill this page to attach it.", "warn");
    return null;
  }
  try {
    let frames = [{ frameId: 0 }];
    try {
      const discovered = await chrome.webNavigation.getAllFrames({ tabId: targetTabId });
      if (discovered?.length) frames = discovered;
    } catch (_err) {}

    const results = await Promise.all(frames.map(async (frame) => {
      try {
        return await chrome.tabs.sendMessage(
          targetTabId,
          { type: "ATTACH_STORED_FILE", key },
          { frameId: frame.frameId }
        );
      } catch (_err) {
        return null;
      }
    }));
    const response = results.filter(Boolean).reduce((acc, item) => ({
      found: acc.found + Number(item.found || 0),
      attached: acc.attached + Number(item.attached || 0),
      dropped: acc.dropped + Number(item.dropped || 0),
    }), { found: 0, attached: 0, dropped: 0 });

    if (response.attached > 0) {
      setStatus(`✓ Uploaded to ${response.attached} matching ${META[key].label} field${response.attached === 1 ? "" : "s"}.`, "ok");
    } else if (response.dropped > 0) {
      setStatus(`✓ Sent ${META[key].label} to ${response.dropped} matching dropzone${response.dropped === 1 ? "" : "s"}. Check the application field for the filename.`, "ok");
    } else if (response.found > 0) {
      setStatus(`The application has ${response.found} upload field(s), but the site did not keep the synthetic attachment. Make the upload section visible and click “Upload saved file again”.`, "warn");
    } else {
      setStatus(`File saved. No matching ${META[key].label} upload field is rendered yet; the extension will retry when the form renders it.`, "warn");
    }
    return response;
  } catch (err) {
    setStatus("File saved locally, but the application page needs to be reloaded once after updating the extension. Reload it, then click “Upload saved file again”.", "warn");
    return null;
  }
}

filePicker.addEventListener("change", async () => {
  const file = filePicker.files?.[0];
  if (!file) return;
  if (!/\.(pdf|doc|docx)$/i.test(file.name)) {
    setStatus("Please choose a PDF, DOC, or DOCX file.", "warn");
    filePicker.value = "";
    return;
  }
  try {
    setStatus(`Saving ${file.name} locally and uploading it…`);
    const savedProfile = await saveStoredFile(file);
    retryBtn.disabled = false;
    let profileImportSucceeded = false;
    let profileImportError = "";
    if (key === "cv") {
      importBtn.disabled = false;
      if (profileImportMode || savedProfile.importProfileFromCvOnSelect) {
        try {
          const result = await extractProfileFromCvFile(file);
          const changed = applyCvProfilePatch(savedProfile, result.profilePatch);
          await chrome.storage.local.set({ profile: savedProfile });
          profileImportSucceeded = true;
          importFieldsEl.textContent = uiT(`Profile updated from CV: ${changed.length ? changed.join(", ") : "no new fields found"}.`);
        } catch (importErr) {
          profileImportError = importErr.message || String(importErr);
          importFieldsEl.textContent = `CV saved for upload, but profile details could not be extracted: ${profileImportError}`;
        }
      }
    }
    const attachResult = await attachNow();
    if (profileImportMode && key === "cv") {
      const attachmentNote = attachResult && (attachResult.attached > 0 || attachResult.dropped > 0)
        ? " The CV was also attached to the application."
        : " The CV is also stored for future application uploads.";
      if (profileImportSucceeded) {
        setStatus(`✓ CV profile import completed.${attachmentNote} Open Settings to review the saved fields.`, "ok");
      } else if (profileImportError) {
        setStatus(`The CV was saved, but profile import could not extract the fields: ${profileImportError}.${attachmentNote}`, "warn");
      }
    }
  } catch (err) {
    setStatus(`Could not save/upload the file: ${err.message}`, "warn");
  }
});

retryBtn.addEventListener("click", attachNow);

importBtn.addEventListener("click", async () => {
  try {
    const profile = await getStoredProfile();
    const dataUrl = profile.cvFileDataUrl;
    if (!dataUrl || !profile.cvFileName) throw new Error("Choose a CV first.");
    setStatus("Reading the saved CV locally and updating your profile…");
    const file = dataUrlToFile(dataUrl, profile.cvFileName);
    const result = await extractProfileFromCvFile(file);
    const changed = applyCvProfilePatch(profile, result.profilePatch);
    await chrome.storage.local.set({ profile });
    const fields = changed.length ? changed.join(", ") : "no new fields";
    importFieldsEl.textContent = uiT(`Imported/updated: ${fields}.`);
    setStatus(`✓ CV profile import finished (${result.format}). Review the saved profile before applying.${result.warning ? ` ${result.warning}` : ""}`, changed.length ? "ok" : "warn");
  } catch (err) {
    setStatus(`CV profile import could not finish: ${err.message}`, "warn");
  }
});

document.getElementById("openSettings").addEventListener("click", () => chrome.runtime.openOptionsPage());
document.getElementById("returnToApplication").addEventListener("click", async () => {
  if (targetTabId) {
    try { await chrome.tabs.update(targetTabId, { active: true }); } catch (_err) {}
  }
});

(async function init() {
  const profile = await getStoredProfile();
  const has = !!profile[`${key}FileDataUrl`];
  retryBtn.disabled = !has;
  if (key === "cv") importBtn.disabled = !has;
  if (has) setStatus(`Saved: ${profile[`${key}FileName`]}. Choose another file to replace it, or upload the saved file again.`);
})();
