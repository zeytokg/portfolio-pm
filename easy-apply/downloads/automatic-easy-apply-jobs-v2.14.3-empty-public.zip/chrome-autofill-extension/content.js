// Content script: runs on every page. Detects likely job-application forms,
// shows a small floating button, and fills fields on click (or on request
// from the popup). Never submits a form automatically.

const COLORS = { filled: "#2ecc71", estimate: "#3498db", review: "#e67e22", missing: "#dc2626" };
const IS_TOP_FRAME = window === window.top;

const ATS_HOST_RE =
  /greenhouse\.io|lever\.co|ashbyhq\.com|myworkday\.com|smartrecruiters\.com|breezy\.hr|bamboohr\.com|workable\.com|jobvite\.com|icims\.com|taleo\.net|successfactors|wellfound\.com|linkedin\.com\/jobs|indeed\.com|pencilcareers|apply\./i;

const FIELD_RULES = [
  { re: /right to work|legal right|work permit|visa sponsor|authorized to work|eligible to work|work eligibility|commit to.*(full-?time|engagement)|4-?month/i, key: "SKIP" },
  { re: /e-?mail/i, key: "email" },
  { re: /linkedin/i, key: "linkedin" },
  { re: /portfolio|personal website|your website|website url|website\b/i, key: "portfolio" },
  { re: /pronouns?|what pronouns/i, key: "pronouns" },
  { re: /date of birth|birth date|date of birthday|\bdob\b/i, key: "dateOfBirth" },
  { re: /birth day|day of birth/i, key: "birthDay" },
  { re: /birth month|month of birth/i, key: "birthMonth" },
  { re: /birth year|year of birth/i, key: "birthYear" },
  { re: /professional headline|profile headline|\bheadline\b/i, key: "headline" },
  { re: /professional summary|profile summary|career summary|personal summary|about me|short bio|^bio\s*\*?$|^summary\s*\*?(?:\s*\(required\))?$/i, key: "professionalSummary" },
  { re: /current job title|current title|current position/i, key: "currentJobTitle" },
  { re: /current company|current employer|where do you currently work/i, key: "currentCompany" },
  { re: /country\s*(calling)?\s*code|dial(ing)?\s*code|phone\s*country\s*code|(telefon\s*)?[uü]lke kodu|arama kodu/i, key: "phoneCountry" },
  { re: /^(?:phone\s*)?(?:extension|extention|ext\.?)(?:\s*(?:number|no\.?))?\s*\*?$/i, key: "phoneExtension" },
  { re: /phone|mobile|cell|cep telefonu|telefon numarası|telefon\b/i, key: "phone" },
  { re: /postal\s*code|post\s*code|postcode|zip\s*code|\bzip\b/i, key: "postalCode" },
  { re: /hourly\s*(?:rate|pay|compensation)|rate\s*per\s*hour|per[- ]hour\s*rate|hourly\s*expectation/i, key: "hourlyRate", estimate: true, salary: true },
  { re: /(?:hourly|rate).{0,50}currency|currency.{0,50}(?:hourly|rate)|currency.{0,30}without\s*vat/i, key: "hourlyRateCurrency" },
  { re: /day ?rate|daily rate|rate per day/i, key: "dayRate", estimate: true, salary: true },
  { re: /annual salary|yearly salary|salary.*year/i, key: "annualSalary", estimate: true, salary: true },
  { re: /monthly salary|salary.*month/i, key: "monthlySalary", estimate: true, salary: true },
  { re: /salary|compensation|pay/i, key: "salaryCurrency", subRe: /currency/i },
  { re: /gross|net|salary basis|compensation basis|pay basis/i, key: "salaryBasis" },
  { re: /salary period|compensation period|pay period|salary frequency|pay frequency/i, key: "salaryPeriod" },
  { re: /salary expectations?|salary requirements?|desired salary|expected salary|target salary|compensation expectations?|desired compensation|expected compensation|target compensation|pay expectations?/i, key: "salaryExpectation", estimate: true, salary: true },
  { re: /notice period|availability.*start|available\s+from|available to start|when.*available|when.*start|start date|starting date|earliest.*(start|available)|desired start/i, key: "availability" },
  { re: /years? of experience|how many years/i, key: "yearsOfExperience" },
  { re: /cover letter|motivation letter/i, key: "coverLetterFull" },
  { re: /\bmessage\b/i, key: "coverLetterFull" },
  { re: /additional information|additional comments|anything else you.?d like|is there anything else/i, key: "coverLetterFull" },
  { re: /why.*(role|join|interested)|tell us about yourself/i, key: "coverLetterSummary" },
  { re: /first name|given name|^first\s*\*?(?:\s*\(required\))?$/i, key: "firstName" },
  { re: /last name|surname|family name|^last\s*\*?(?:\s*\(required\))?$/i, key: "lastName" },
  { re: /full name|your name|applicant name|^name$/i, key: "fullName" },
  { re: /which city.*country|city\s*&\s*country/i, key: "cityCountry" },
  { re: /current location|set your location|where are you (currently )?(based|located)|what is your location|^location\s*\*?(?:\s*\(required\))?$/i, key: "currentLocation" },
  { re: /\bcity\b/i, key: "city" },
  { re: /\bprovince\b|\bregion\b|^(?:state|county)(?:\s*\*)?$/i, key: "region" },
  { re: /\bcountry\b/i, key: "country" },
  { re: /street\s*\/\s*house\s*(?:number|no\.?)|street\s+and\s+house\s*(?:number|no\.?)|street\s*(?:address)?|house\s*(?:number|no\.?)/i, key: "address" },
  { re: /address/i, key: "address" },
  { re: /cadastral|foglio|particella/i, key: "cadastral" },
  { re: /ethnicity/i, key: "ethnicity" },
  { re: /race\b/i, key: "race" },
  { re: /github/i, key: "github" },
];

// Files selected in the extension (popup or Settings) are stored locally as
// data URLs, reconstructed as File objects here, and assigned via DataTransfer.
// That lets ordinary HTML upload controls receive the file immediately without
// opening the site's native picker again.
const FILE_RULES = [
  { re: /cover[\s_-]*letter|motivation[\s_-]*letter/i, key: "coverLetter" },
  { re: /resume|résumé|\bcv\b|curriculum[\s_-]*vitae/i, key: "cv" },
  { re: /portfolio|work[\s_-]*sample|case[\s_-]*stud(?:y|ies)/i, key: "portfolio" },
];

const LEGAL_RE =
  /right to work|legal right|work permit|visa|sponsor|authorized to work|eligible to work|work authorization|commit to|full-?time.*engagement|4-?month/i;

// Optional explicit profile default for the common concept “authorized to work
// in the role country without employer sponsorship”. Questions phrased as
// “require sponsorship?” are the logical inverse of that setting.
const WORK_AUTH_DIRECT_RE =
  /(?:authorized|eligible|right) to work.{0,120}(?:without|no).{0,50}(?:employer )?sponsor|work authorization.{0,120}(?:without|no).{0,50}(?:employer )?sponsor/i;
const SPONSOR_REQUIRED_RE =
  /(?:require|need).{0,50}(?:visa |employer )?sponsor|sponsor(?:ship)?.{0,70}(?:require|need)|will you.{0,80}require.{0,40}sponsor/i;
const DEMOGRAPHIC_RE =
  /ethnic|race\b|hispanic|latino|latina|latinx|disab|veteran|military service|gender|lgbtq|lbgtq|lesbian|bisexual|queer|intersex|asexual|\bage\b|nationality|national origin/i;

const CONSENT_RE = /consent.{0,120}(?:self[- ]identification|data|processed|processing)|self[- ]identification data.{0,120}consent/i;
const NON_COMPETE_RE = /non[- ]?compete|noncompete/i;

// Security credentials, government identifiers, and financial secrets are
// deliberately outside the autofill/learning system. These values can be
// site-specific or exceptionally sensitive and must always be entered by the
// applicant at the point of use.
const SENSITIVE_NEVER_STORE_RE = /\b(?:password|passcode|passphrase|pin(?:\s*(?:code|number))?|one[-\s]?time(?:\s*(?:password|passcode|code))?|otp|verification\s*code|security\s*code|authentication\s*code|auth\s*code|2fa|mfa|recovery\s*code|backup\s*code|passport(?:\s*(?:number|no\.?|id))?|national\s*(?:id|identity)(?:\s*(?:number|no\.?))?|government\s*(?:id|identity)(?:\s*(?:number|no\.?))?|identity\s*(?:document|number|no\.?)|social\s*security(?:\s*(?:number|no\.?))?|ssn|tax(?:payer)?\s*(?:id|identification|number|no\.?)|fiscal\s*code|codice\s*fiscale|driver'?s?\s*licen[cs]e(?:\s*(?:number|no\.?))?|residence\s*permit(?:\s*(?:number|no\.?))?|bank\s*account(?:\s*(?:number|no\.?))?|iban|routing\s*(?:number|no\.?)|sort\s*code|swift|bic|credit\s*card|debit\s*card|card\s*(?:number|no\.?)|cvv|cvc|card\s*security\s*code|api\s*key|secret\s*key|access\s*token|security\s*(?:answer|question))\b/i;
const SENSITIVE_AUTOCOMPLETE_RE = /^(?:current-password|new-password|one-time-code|cc-number|cc-csc|cc-exp|cc-exp-month|cc-exp-year)$/i;

function sensitiveFieldText(el, label = "") {
  if (!el) return String(label || "");
  return [
    label,
    el.getAttribute?.("name"),
    el.getAttribute?.("id"),
    el.getAttribute?.("placeholder"),
    el.getAttribute?.("aria-label"),
    el.getAttribute?.("autocomplete"),
  ].filter(Boolean).join(" ");
}

function isSensitiveNeverStoreField(el, label = "") {
  if (el?.type === "password") return true;
  const ac = String(el?.getAttribute?.("autocomplete") || "").trim();
  if (SENSITIVE_AUTOCOMPLETE_RE.test(ac)) return true;
  return SENSITIVE_NEVER_STORE_RE.test(sensitiveFieldText(el, label));
}

function isSensitiveNeverStoreQuestion(text) {
  return SENSITIVE_NEVER_STORE_RE.test(String(text || ""));
}
const WORK_ELIGIBILITY_RE = /(?:legally )?(?:eligible|authorized|right) to work.{0,140}(?:country|location|where)|work eligibility/i;

// "Will you be able to work on-site at our office?" type questions can use
// the existing convenience auto-Yes behavior. Work-authorization/eligibility
// questions are intentionally NOT part of this rule; those go through the
// explicit/scoped authorization logic above.
const ONSITE_RE =
  /\bon-?site\b.{0,40}\boffice\b|\boffice\b.{0,40}\bon-?site\b|able to work on-?site|work from (the|our) office|willing to (work|relocate) (on-?site|to)|based (in|at) (the|our) office/i;

const AUTO_YES_RE = /(?!)^/; // Blank/shareable build: no preset answer for on-site/hybrid preference questions.

// Language proficiency selects/pill-groups, e.g. "Language Proficiency in English"
const LANGUAGE_RE = /language|proficien/i;
const LANGUAGE_NAME_RE =
  /\b(english|italian|german|french|spanish|portuguese|turkish|dutch|arabic|mandarin|chinese|russian|japanese|korean|polish|swedish|norwegian|danish|greek|hindi|urdu)\b/i;
const LANGUAGE_KEYS = {
  english: "languageEnglish",
  italian: "languageItalian",
  german: "languageGerman",
  french: "languageFrench",
  turkish: "languageTurkish",
};

function extractLanguageName(label) {
  const m = label.match(LANGUAGE_NAME_RE);
  return m ? m[1].toLowerCase() : null;
}

function getLanguageValue(profile, langName) {
  const key = LANGUAGE_KEYS[langName];
  if (key && profile[key]) return profile[key];
  return profile.languageOtherDefault || null;
}

// Different ATS platforms word their language-proficiency scale differently —
// e.g. our own 5-tier "No Relevant / Limited Working / Professional Working /
// Full Professional / Native or Bilingual" vs. a site's simpler 4-tier "None /
// Conversational / Professional / Native or bilingual". Score both our stored
// value and each on-page option onto a common 0-4 scale and pick the closest,
// instead of requiring the exact same wording.
const PROFICIENCY_LEVELS = [
  { score: 0, re: /\bnone\b|no relevant|no proficiency|not proficient|elementary|beginner|\ba1\b|\ba2\b/i },
  { score: 1, re: /conversational|limited working|basic|intermediate|\bb1\b/i },
  { score: 2, re: /professional working|advanced|\bb2\b/i },
  { score: 3, re: /full professional|fluent|\bc1\b|professional(?!\s*working)/i },
  { score: 4, re: /native|bilingual|mother tongue|\bc2\b/i },
];

function proficiencyScore(text) {
  const t = (text || "").trim();
  if (!t) return null;
  for (let i = PROFICIENCY_LEVELS.length - 1; i >= 0; i--) {
    if (PROFICIENCY_LEVELS[i].re.test(t)) return PROFICIENCY_LEVELS[i].score;
  }
  return null;
}

// Index into `texts` whose proficiency tier is closest to `desiredText`'s
// tier, or -1 if either can't be scored (caller should fall back to exact
// matching in that case).
function closestProficiencyIndex(texts, desiredText) {
  const desiredScore = proficiencyScore(desiredText);
  if (desiredScore === null) return -1;
  let bestIndex = -1;
  let bestDiff = Infinity;
  texts.forEach((text, i) => {
    const score = proficiencyScore(text);
    if (score === null) return;
    const diff = Math.abs(score - desiredScore);
    if (diff < bestDiff) {
      bestDiff = diff;
      bestIndex = i;
    }
  });
  return bestIndex;
}

// Some ATS phone widgets split "Phone country code" (a select) from the
// national number (a plain text input) instead of one full-international-
// number field. Look a few ancestor levels up for that sibling select.
function findPhoneCountryCodeSelect(el) {
  let node = el;
  for (let i = 0; i < 4 && node; i++) {
    node = node.parentElement;
    if (!node) break;
    const select = node.querySelector("select");
    if (select && select !== el) {
      const label = getLabelText(select);
      if (/country\s*(calling)?\s*code|dial(ing)?\s*code|(telefon\s*)?[uü]lke kodu|arama kodu/i.test(label)) return select;
    }
  }
  return null;
}

// A handful of localized ATS forms (e.g. LinkedIn's Turkish UI) spell the
// country name differently than the profile's English one — try known
// alternate spellings before falling back to the dial code.
const COUNTRY_NAME_ALIASES = {
  "united states": ["united states", "usa", "us"],
  "united kingdom": ["united kingdom", "uk", "great britain"],
  turkey: ["turkey", "türkiye", "turkiye"],
  türkiye: ["türkiye", "turkey", "turkiye"],
  turkiye: ["turkiye", "turkey", "türkiye"],
};

const PHONE_DIAL_CODES = {
  "united states": "+1", canada: "+1", "united kingdom": "+44",
  france: "+33", germany: "+49", italy: "+39", spain: "+34", portugal: "+351",
  netherlands: "+31", belgium: "+32", switzerland: "+41", austria: "+43",
  ireland: "+353", sweden: "+46", norway: "+47", denmark: "+45", finland: "+358",
  poland: "+48", czechia: "+420", romania: "+40", greece: "+30",
  turkey: "+90", türkiye: "+90", turkiye: "+90",
  india: "+91", china: "+86", japan: "+81", "south korea": "+82",
  australia: "+61", "new zealand": "+64", brazil: "+55", mexico: "+52",
  argentina: "+54", "united arab emirates": "+971", "saudi arabia": "+966",
  israel: "+972", "south africa": "+27"
};

function phoneDialCode(profile) {
  const country = normalizeChoiceText(profile?.phoneCountry || "");
  if (PHONE_DIAL_CODES[country]) return PHONE_DIAL_CODES[country];
  // Conservative fallback for profiles without a known country mapping.
  // Keep the common one/two/three digit code only when separators make it
  // unambiguous.
  const phone = String(profile?.phone || "").trim();
  const spaced = phone.match(/^\+(\d{1,3})(?:[\s().-]|$)/);
  return spaced ? `+${spaced[1]}` : "";
}

function phoneCountryAliases(profile) {
  const country = (profile.phoneCountry || "").trim();
  const aliases = COUNTRY_NAME_ALIASES[country.toLowerCase()] || [country].filter(Boolean);
  const dial = phoneDialCode(profile);
  return { aliases, dial };
}

function setPhoneCountrySelect(el, profile) {
  const { aliases, dial } = phoneCountryAliases(profile);

  let opt = null;
  for (const alias of aliases) {
    opt = Array.from(el.options).find((o) => normalizeChoiceText(o.text).includes(normalizeChoiceText(alias)));
    if (opt) break;
  }
  if (!opt && dial) {
    opt = Array.from(el.options).find((o) => String(o.text || "").includes(dial));
  }
  if (!opt) return false;
  el.value = opt.value;
  el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  return true;
}

function isVisibleChoice(el) {
  if (!el || !(el instanceof Element)) return false;
  const style = getComputedStyle(el);
  const rect = el.getBoundingClientRect();
  return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
}

function phoneCountryControlContext(el) {
  const parts = [
    getLabelText(el),
    el.getAttribute?.("aria-label"),
    el.getAttribute?.("placeholder"),
    el.getAttribute?.("name"),
    el.id,
    el.innerText,
    el.textContent,
  ].filter(Boolean);
  let node = el;
  for (let i = 0; i < 4 && node; i++, node = node.parentElement) {
    const text = String(node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
    if (text && text.length <= 500) parts.push(text);
  }
  return parts.join(" ").replace(/\s+/g, " ").trim();
}

function looksLikePhoneCountryControl(el) {
  if (!el || !isVisibleChoice(el)) return false;
  const text = phoneCountryControlContext(el);
  const own = String(el.innerText || el.textContent || el.value || "").trim();
  const direct = [getLabelText(el), el.getAttribute?.("name"), el.id, el.getAttribute?.("aria-label"), el.getAttribute?.("placeholder")].filter(Boolean).join(" ");
  if (/phone\s*country|country\s*(?:calling)?\s*code|dial(?:ing)?\s*code/i.test(direct)) return true;
  // Ashby commonly labels the picker simply “Country” beside a separate
  // “Phone” field. It may be a button showing +90 or an input/combobox whose
  // visible value is initially empty.
  const ownLabel = getLabelText(el);
  if (/^country\s*\*?$/i.test(ownLabel) && /\bphone\b/i.test(text) && (el.getAttribute?.("role") === "combobox" || el.hasAttribute?.("aria-haspopup"))) return true;
  if (/\bcountry\b/i.test(text) && /\bphone\b/i.test(text) && /^\+\d{1,4}$/.test(own.replace(/\s+/g, ""))) return true;
  if (/^\+\d{1,4}$/.test(own.replace(/\s+/g, "")) && /\bphone\b/i.test(text)) return true;
  return false;
}

function customChoiceText(el) {
  return String(el?.innerText || el?.textContent || el?.getAttribute?.("aria-label") || "").replace(/\s+/g, " ").trim();
}

function dispatchChoiceClick(el) {
  if (!el) return false;
  try { el.scrollIntoView?.({ block: "nearest", inline: "nearest" }); } catch (_err) {}
  try { el.focus?.({ preventScroll: true }); } catch (_err) { try { el.focus?.(); } catch (_err2) {} }
  const base = { bubbles: true, cancelable: true, composed: true, button: 0, buttons: 1, view: window };
  try {
    if (typeof PointerEvent !== "undefined") el.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mousedown", base));
    if (typeof PointerEvent !== "undefined") el.dispatchEvent(new PointerEvent("pointerup", { ...base, buttons: 0, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
    el.click();
    return true;
  } catch (_err) {
    try { el.click(); return true; } catch (_err2) { return false; }
  }
}

function phoneCountryHasValidationError(control) {
  let node = control;
  for (let i = 0; i < 5 && node; i++, node = node.parentElement) {
    const text = String(node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim();
    if (/select\s+(?:a\s+)?country|choose\s+(?:a\s+)?country|country\s+(?:is\s+)?required|please\s+select.{0,40}country/i.test(text)) return true;
  }
  return control.getAttribute?.("aria-invalid") === "true";
}

function phoneCountryHasCommittedValue(control, profile) {
  if (!control || phoneCountryHasValidationError(control)) return false;
  const { aliases, dial } = phoneCountryAliases(profile);
  const wanted = [...aliases, dial].map(normalizeChoiceText).filter(Boolean);
  const current = normalizeChoiceText(control.value || customChoiceText(control));
  if (!wanted.some((v) => current.includes(v))) return false;

  // Prefer evidence from a real value-bearing control when the component
  // exposes one. Do not trust display text alone: several ATS widgets can show
  // “+90” while their internal required country state is still empty.
  const wrapper = control.closest?.('fieldset, [role="group"], [data-field], [class*="field" i], [class*="phone" i]') || control.parentElement;
  if (wrapper) {
    const valueNodes = Array.from(wrapper.querySelectorAll?.('select, input[type="hidden"], input:not([type]), input[type="text"]') || [])
      .filter((el) => el !== control && /country|dial|calling|phone/i.test(`${el.name || ""} ${el.id || ""} ${el.getAttribute?.("data-testid") || ""} ${el.getAttribute?.("aria-label") || ""}`));
    if (valueNodes.some((el) => String(el.value || "").trim())) return true;
  }
  return control.getAttribute?.("aria-invalid") === "false";
}

function visiblePhoneCountryOptions() {
  return Array.from(document.querySelectorAll([
    '[role="option"]',
    '[role="menuitem"]',
    '[data-radix-collection-item]',
    '[data-headlessui-state]',
    '[cmdk-item]',
    '[role="listbox"] button',
    '[role="menu"] button',
    'li[tabindex]',
    'li button'
  ].join(','))).filter(isVisibleChoice);
}

function findPhoneCountryOption(options, aliases, dial) {
  const aliasNorms = aliases.map(normalizeChoiceText).filter(Boolean);
  // Country name is stronger evidence than the dial code. Prefer exact/name
  // matches first, then use +90 as a fallback.
  let match = options.find((o) => aliasNorms.includes(normalizeChoiceText(customChoiceText(o))));
  if (!match) {
    match = options.find((o) => {
      const text = normalizeChoiceText(customChoiceText(o));
      return aliasNorms.some((alias) => text.includes(alias));
    });
  }
  if (!match && dial) match = options.find((o) => customChoiceText(o).replace(/\s+/g, "").includes(dial.replace(/\s+/g, "")));
  return match || null;
}

function visibleCountrySearchInput() {
  return Array.from(document.querySelectorAll('input[role="combobox"], input[type="search"], input[placeholder*="country" i], input[aria-label*="country" i]'))
    .find((input) => isVisibleChoice(input) && !/phone|mobile|tel/i.test(`${input.name || ""} ${input.id || ""} ${input.getAttribute("aria-label") || ""}`));
}

async function setCustomPhoneCountryControl(control, profile) {
  if (!control || control.tagName === "SELECT") return false;
  const { aliases, dial } = phoneCountryAliases(profile);
  if (!aliases.length && !dial) return false;

  // Never accept a visible dial-code label as proof that the ATS committed the country selection. This
  // was the bug behind forms that looked filled but still showed “Select a
  // country”. We explicitly open the picker and click the real option.
  if (phoneCountryHasCommittedValue(control, profile)) return true;

  const clickTarget = control.matches?.('button, [role="combobox"], [role="button"], [aria-haspopup]')
    ? control
    : control.querySelector?.('button, [role="combobox"], [role="button"], [aria-haspopup]') || control;
  if (!dispatchChoiceClick(clickTarget)) return false;

  const deadline = Date.now() + 2200;
  let searched = false;
  while (Date.now() < deadline) {
    let options = visiblePhoneCountryOptions();
    let match = findPhoneCountryOption(options, aliases, dial);

    // Some country pickers render a searchable popover. Type the country name
    // into that search box once the picker is open, then wait for filtered
    // options instead of leaving a country name as uncommitted text.
    if (!match && !searched && aliases[0]) {
      const search = visibleCountrySearchInput();
      if (search && search !== control) {
        setNativeValue(search, aliases[0]);
        search.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        searched = true;
        await new Promise((resolve) => setTimeout(resolve, 100));
        options = visiblePhoneCountryOptions();
        match = findPhoneCountryOption(options, aliases, dial);
      }
    }

    if (match) {
      dispatchChoiceClick(match);
      await new Promise((resolve) => setTimeout(resolve, 140));
      try { control.dispatchEvent(new Event("input", { bubbles: true, composed: true })); } catch (_err) {}
      try { control.dispatchEvent(new Event("change", { bubbles: true, composed: true })); } catch (_err) {}
      try { control.blur?.(); } catch (_err) {}
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, 70));
  }

  // Keyboard fallback for ARIA comboboxes that expose no queryable option
  // nodes until navigation begins.
  try {
    clickTarget.focus?.();
    clickTarget.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", code: "ArrowDown", bubbles: true, composed: true }));
    clickTarget.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, composed: true }));
  } catch (_err) {}
  return phoneCountryHasCommittedValue(control, profile);
}

function findPhoneCountryWidget(el) {
  let node = el;
  for (let i = 0; i < 5 && node; i++, node = node.parentElement) {
    if (!node) break;
    const native = Array.from(node.querySelectorAll?.("select") || []).find((candidate) => {
      if (candidate === el) return false;
      const text = `${getLabelText(candidate)} ${candidate.name || ""} ${candidate.id || ""} ${candidate.getAttribute?.("aria-label") || ""}`;
      // Only treat a native Country select as part of the phone widget when its
      // own label explicitly mentions phone/dial/calling code, or the compact
      // surrounding group clearly contains both Country and Phone. This avoids
      // mistaking the applicant's address Country field for a phone-code picker.
      if (/phone\s*country|country\s*(?:calling)?\s*code|dial(?:ing)?\s*code/i.test(text)) return true;
      const ownLabel = getLabelText(candidate).trim();
      const group = candidate.closest?.('fieldset, [role="group"], [data-field], [class*="phone" i]');
      const groupText = String(group?.innerText || group?.textContent || "").replace(/\s+/g, " ").trim();
      return /^country\s*\*?$/i.test(ownLabel) && /\bphone\b/i.test(groupText) && groupText.length < 350;
    });
    if (native) return native;
    const custom = Array.from(node.querySelectorAll?.('[role="combobox"], button, [role="button"], [tabindex]') || [])
      .find((candidate) => candidate !== el && looksLikePhoneCountryControl(candidate));
    if (custom) return custom;
  }
  return null;
}

// Strips the profile's known dial code from the full international number for
// split phone widgets. If no code is known, leave all digits intact rather
// than accidentally chopping three digits from the subscriber number.
function localPhoneNumber(fullPhone, profile) {
  const digits = String(fullPhone || "").replace(/[^\d+]/g, "");
  const dial = phoneDialCode(profile);
  if (dial && digits.startsWith(dial)) return digits.slice(dial.length).replace(/\D/g, "");
  return digits.replace(/\D/g, "");
}

const EU_COUNTRIES = new Set([
  "austria", "belgium", "bulgaria", "croatia", "cyprus", "czechia", "czech republic", "denmark",
  "estonia", "finland", "france", "germany", "greece", "hungary", "ireland", "italy", "latvia",
  "lithuania", "luxembourg", "malta", "netherlands", "poland", "portugal", "romania", "slovakia",
  "slovenia", "spain", "sweden",
]);

// "What is your current location?" style selects sometimes offer city/country
// options, but often only broad region groupings (e.g. "European Union",
// "North America"). Try the most specific candidate first, falling back to
// the region if nothing more specific matches.
function locationCandidates(profile) {
  const candidates = [];
  if (profile.locationDisplay) candidates.push(profile.locationDisplay);
  if (profile.city) candidates.push(profile.city);
  if (profile.country) candidates.push(profile.country);
  if (profile.country && EU_COUNTRIES.has(profile.country.trim().toLowerCase())) {
    candidates.push("European Union", "EU", "Europe");
  }
  return candidates;
}

function setLocationSelectValue(el, profile) {
  for (const candidate of locationCandidates(profile)) {
    if (setSelectValue(el, candidate)) return true;
  }
  return false;
}

// "Current location" is often a Google Places-style autocomplete text field
// (common on Greenhouse-family ATS forms) rather than a plain input or a
// native select — typing a saved city can open a live "City, Region, Country"
// suggestion list, and only clicking a suggestion actually confirms the
// site's internal selection. Setting .value directly leaves that unconfirmed.
function isAutocompleteCombobox(el) {
  return (
    el.getAttribute("role") === "combobox" ||
    el.hasAttribute("aria-autocomplete") ||
    el.getAttribute("aria-expanded") !== null ||
    !!el.closest('[role="combobox"]')
  );
}

function isElementVisible(el) {
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function findAutocompleteSuggestions() {
  const selectors = [
    ".pac-container:not([style*='display: none']) .pac-item",
    '[role="listbox"] [role="option"]',
    '[role="option"]',
  ];
  for (const selector of selectors) {
    const found = Array.from(document.querySelectorAll(selector)).filter(isElementVisible);
    if (found.length) return found;
  }
  return [];
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Runs asynchronously (not awaited by fillForm) — types the city, waits for
// the suggestion list to render, then clicks the best "City, ..., Country"
// match. Falls back to leaving the typed city text in place if no dropdown
// ever appears (e.g. the site is slow, or this wasn't actually a combobox).
async function fillLocationAutocomplete(el, profile) {
  const query = profile.locationDisplay || profile.city || profile.country;
  if (!query) return false;
  el.focus();
  setNativeValue(el, query);
  await wait(800);
  const options = findAutocompleteSuggestions();
  if (!options.length) return false;

  const wantCity = (profile.city || "").toLowerCase();
  const wantCountry = (profile.country || "").toLowerCase();
  const textOf = (o) => (o.innerText || o.textContent || "").toLowerCase();

  const best =
    options.find((o) => (!wantCity || textOf(o).includes(wantCity)) && (!wantCountry || textOf(o).includes(wantCountry))) ||
    options.find((o) => wantCountry && textOf(o).includes(wantCountry)) ||
    options[0];

  best.click();
  return true;
}

function parsedDob(profile) {
  const raw = String(profile?.dateOfBirth || "").trim();
  const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return { year: iso[1], month: iso[2], day: iso[3] };
  const day = String(profile?.birthDay || "").padStart(2, "0");
  const year = String(profile?.birthYear || "");
  const monthName = normalizeChoiceText(profile?.birthMonth || "");
  const months = { january:"01", february:"02", march:"03", april:"04", may:"05", june:"06", july:"07", august:"08", september:"09", october:"10", november:"11", december:"12" };
  const month = months[monthName] || String(profile?.birthMonth || "").replace(/\D/g, "").padStart(2, "0");
  return /^\d{4}$/.test(year) && /^\d{2}$/.test(month) && /^\d{2}$/.test(day) ? { year, month, day } : null;
}

function dateOfBirthForField(el, profile) {
  const dob = parsedDob(profile);
  if (!dob) return String(profile?.dateOfBirth || "");
  if (el?.type === "date") return `${dob.year}-${dob.month}-${dob.day}`;
  const hint = normalizeChoiceText(`${getLabelText(el)} ${el?.getAttribute?.("placeholder") || ""} ${el?.getAttribute?.("aria-label") || ""}`);
  if (/dd[\s./-]*mm[\s./-]*(yyyy|yy)|day.*month.*year/.test(hint)) return `${dob.day}/${dob.month}/${dob.year}`;
  if (/mm[\s./-]*dd[\s./-]*(yyyy|yy)|month.*day.*year/.test(hint)) return `${dob.month}/${dob.day}/${dob.year}`;
  return `${dob.year}-${dob.month}-${dob.day}`;
}

function setBirthMonthValue(el, profile) {
  const dob = parsedDob(profile);
  const configured = String(profile?.birthMonth || "").trim();
  const monthNum = dob?.month || "";
  const monthIndex = Number.parseInt(monthNum, 10) - 1;
  const names = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const candidates = [configured, monthNum, String(Number.parseInt(monthNum, 10)), names[monthIndex]].filter(Boolean);
  if (el.tagName === "SELECT") return setSelectFromCandidates(el, candidates);
  if (looksLikeCustomCombobox(el)) {
    setCustomComboboxFromCandidates(el, candidates).then((ok) => { if (ok) highlight(el, "filled"); });
    return true;
  }
  if (candidates[0]) { setNativeValue(el, candidates[0]); return true; }
  return false;
}

function ageFromDateOfBirth(profile) {
  const dob = parsedDob(profile);
  if (!dob) return Number.parseInt(String(profile?.age || ""), 10) || null;
  const now = new Date();
  let age = now.getFullYear() - Number(dob.year);
  const m = (now.getMonth() + 1) - Number(dob.month);
  if (m < 0 || (m === 0 && now.getDate() < Number(dob.day))) age--;
  return age;
}

// Salary/day-rate selects often offer fixed numeric brackets that do not
// literally contain the saved free-text target. Parse numbers from both sides
// and pick the bracket closest to the low end of the applicant's saved range.
function parseNumbers(text) {
  return ((text || "").match(/[\d][\d,.]*/g) || [])
    .map((s) => parseFloat(s.replace(/,/g, "")))
    .filter((n) => !isNaN(n) && n > 0);
}

function salaryTargetNumbers(text) {
  const raw = String(text || "");
  // If a stored generic answer mentions both an annual target and a monthly
  // equivalent, prefer the figures attached to the first explicit period so
  // a numeric annual-salary field never receives the monthly figure.
  const period = raw.match(/\/\s*(year|month|day)|per\s+(year|month|day)|\b(annual|yearly|monthly|daily)\b/i);
  if (period && period.index > 0) {
    const before = parseNumbers(raw.slice(0, period.index));
    if (before.length) return before;
  }
  return parseNumbers(raw);
}

function setSalarySelectValue(el, desiredText) {
  const desiredNums = salaryTargetNumbers(desiredText);
  if (!desiredNums.length) return setSelectValue(el, desiredText);
  const desiredMin = Math.min(...desiredNums);

  const options = Array.from(el.options);
  let best = null;
  let bestDiff = Infinity;
  options.forEach((o) => {
    const nums = parseNumbers(o.text);
    if (!nums.length) return;
    const diff = Math.min(...nums.map((n) => Math.abs(n - desiredMin)));
    if (diff < bestDiff) {
      bestDiff = diff;
      best = o;
    }
  });
  if (!best) return setSelectValue(el, desiredText);
  el.value = best.value;
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function setSalaryInputValue(el, desiredText) {
  if (el.type === "number" || el.type === "range") {
    const nums = salaryTargetNumbers(desiredText);
    if (!nums.length) return false;
    setNativeValue(el, String(Math.min(...nums)));
    return true;
  }
  setNativeValue(el, desiredText);
  return true;
}

// Notice-period selects rarely spell out "immediately available / no notice
// period" verbatim — they offer their own short phrasing ("Available
// Immediately", "ASAP", ...). When our stored value signals immediate
// availability, match on that intent instead of the literal text.
const IMMEDIATE_AVAILABILITY_RE = /immediat|\basap\b|no notice|available now|right away|^now$|\b0\s*(days?|weeks?)\b/i;


function normalizeChoiceText(text) {
  return (text || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[–—−]/g, "-")
    .replace(/[’‘]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function demographicKind(label) {
  const t = normalizeChoiceText(label);
  if (!t) return null;
  // Keep these identity questions separate. In particular, do not infer a
  // person's sexual orientation or transgender identity from an LGBTQIA+
  // community answer; those fields only fill when explicitly configured.
  if (/transgender|trans gender/.test(t)) return "transgender";
  if (/sexual orientation/.test(t)) return "sexualOrientation";
  if (/which of the following communities|communities do you belong|community memberships?/.test(t)) return "communities";
  // Race is checked before Hispanic/Latino because US EEO race options often
  // contain the phrase "Not Hispanic or Latino" inside the White option text.
  if (/\brace\b/.test(t)) return "race";
  if (/hispanic|latino|latina|latinx/.test(t)) return "hispanicLatino";
  if (/ethnic/.test(t)) return "ethnicity";
  if (/veteran|military service/.test(t)) return "veteran";
  if (/disab/.test(t)) return "disability";
  if (/lgbtq|lbgtq|lesbian|bisexual|queer|intersex|asexual/.test(t)) return "lgbtqia";
  if (/\bgender\b|gender identity|\bsex\b/.test(t)) return "gender";
  if (/\bage\b/.test(t)) return "age";
  if (/\bnationality\b|national origin/.test(t)) return "nationality";
  return null;
}

function ageRangeFromAge(ageValue) {
  const age = Number.parseInt(String(ageValue || ""), 10);
  if (!Number.isFinite(age)) return "";
  if (age < 25) return "Under 25";
  if (age <= 34) return "25–34";
  if (age <= 44) return "35–44";
  if (age <= 54) return "45–54";
  if (age <= 64) return "55–64";
  return "65 or over";
}

function splitConfiguredChoices(value) {
  return String(value || "")
    .split(/[,;\n]+/)
    .map((v) => v.trim())
    .filter(Boolean);
}

function demographicCandidates(kind, profile) {
  const computedAge = ageFromDateOfBirth(profile);
  const ageRange = computedAge ? ageRangeFromAge(computedAge) : (profile.ageRange || ageRangeFromAge(profile.age));
  switch (kind) {
    case "gender":
      return profile.revealGender && profile.genderValue ? [profile.genderValue] : [];
    case "age":
      return [ageRange, String(computedAge || profile.age || "")].filter(Boolean);
    case "race":
      return [profile.race, profile.ethnicity].filter(Boolean);
    case "ethnicity":
      return [profile.nationality, profile.ethnicity, profile.race].filter(Boolean);
    case "hispanicLatino":
      return [profile.hispanicLatino].filter(Boolean);
    case "disability":
      return [profile.disabilityStatus].filter(Boolean);
    case "lgbtqia":
      return [profile.lgbtqiaStatus].filter(Boolean);
    case "transgender":
      return splitConfiguredChoices(profile.transgenderStatus);
    case "sexualOrientation":
      return splitConfiguredChoices(profile.sexualOrientation);
    case "communities":
      return splitConfiguredChoices(profile.communitySelections);
    case "veteran":
      return [profile.veteranStatus].filter(Boolean);
    case "nationality":
      return [profile.nationality].filter(Boolean);
    default:
      return [];
  }
}

function optionRangeContainsAge(optionText, ageValue) {
  const age = Number.parseInt(String(ageValue || ""), 10);
  if (!Number.isFinite(age)) return false;
  const t = normalizeChoiceText(optionText);
  const pair = t.match(/(\d{1,3})\s*(?:-|to)\s*(\d{1,3})/);
  if (pair) return age >= Number(pair[1]) && age <= Number(pair[2]);
  const under = t.match(/under\s*(\d{1,3})|younger than\s*(\d{1,3})/);
  if (under) return age < Number(under[1] || under[2]);
  const over = t.match(/(\d{1,3})\s*(?:or older|and over|\+)/);
  if (over) return age >= Number(over[1]);
  return false;
}

function demographicOptionScore(optionText, kind, profile) {
  const t = normalizeChoiceText(optionText);
  if (!t) return -1;
  const candidates = demographicCandidates(kind, profile).map(normalizeChoiceText).filter(Boolean);
  if (!candidates.length) return -1;

  if (kind === "age") {
    if (profile.age && optionRangeContainsAge(optionText, profile.age)) return 126;
  }

  // Common semantic aliases are used only when the applicant explicitly saved
  // the corresponding value. The blank build never infers identity answers.
  const configured = candidates.join(" | ");
  if (kind === "gender") {
    if (/\b(female|woman)\b/.test(configured) && /^(female|woman)(\b|\s|\()/.test(t)) return 125;
    if (/\b(male|man)\b/.test(configured) && /^(male|man)(\b|\s|\()/.test(t)) return 125;
  }
  if (kind === "race" && /\bwhite\b/.test(configured) && /^white\b/.test(t)) return 125;
  if ((kind === "nationality" || kind === "ethnicity") && /\bturk(?:ish|ey|iye)\b/.test(configured) && /^turk(?:ish|ey|iye)\b/.test(t)) return 125;
  if (kind === "hispanicLatino" && /^(no|not hispanic|not latino)/.test(configured)) {
    if (/^no\b/.test(t) || /^not\s+(?:hispanic|latino)/.test(t) || /not hispanic or latino/.test(t)) return 125;
  }
  if (kind === "disability" && /^no\b/.test(configured)) {
    if (t === "no" || (/^no\b/.test(t) && /disab|history|record/.test(t)) || /(?:do not|don't) have (?:a )?disab/.test(t)) return 125;
  }
  if (kind === "lgbtqia" && /^no\b/.test(configured)) {
    if (t === "no" || /^no\b/.test(t) || /do not identify.*lgbtq|not lgbtq/.test(t)) return 125;
  }
  if (kind === "transgender" && /^(no|not transgender)/.test(configured)) {
    if (t === "no" || /^no\b/.test(t) || /not transgender/.test(t)) return 125;
  }
  if (kind === "veteran" && /(?:not .*veteran|^no\b)/.test(configured)) {
    if (/not (?:a )?protected veteran/.test(t) || /not (?:a )?veteran/.test(t) || /^no\b.*military/.test(t) || t === "no") return 125;
  }

  let best = -1;
  candidates.forEach((candidate) => {
    if (t === candidate) best = Math.max(best, 110);
    else if (candidate.length >= 4 && (t.startsWith(candidate) || candidate.startsWith(t))) best = Math.max(best, 90);
    else if (candidate.length >= 5 && (t.includes(candidate) || candidate.includes(t))) best = Math.max(best, 70);
  });
  return best;
}

function bestDemographicControl(controls, getText, kind, profile) {
  let best = null;
  let bestScore = -1;
  controls.forEach((control) => {
    const score = demographicOptionScore(getText(control), kind, profile);
    if (score > bestScore) {
      bestScore = score;
      best = control;
    }
  });
  return bestScore >= 0 ? best : null;
}

function setDemographicSelectValue(el, kind, profile) {
  const options = Array.from(el.options).filter((o) => !o.disabled && o.value !== "");
  const match = bestDemographicControl(options, (o) => o.text, kind, profile);
  if (!match) return false;
  el.value = match.value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function demographicTextValue(kind, profile) {
  switch (kind) {
    case "gender": return profile.revealGender ? (profile.genderValue || "") : "";
    case "age": return String(ageFromDateOfBirth(profile) || profile.age || "");
    case "race": return profile.race || "";
    case "ethnicity": return profile.ethnicity || profile.nationality || "";
    case "hispanicLatino": return profile.hispanicLatino || "";
    case "disability": return profile.disabilityStatus || "";
    case "lgbtqia": return profile.lgbtqiaStatus || "";
    case "transgender": return profile.transgenderStatus || "";
    case "sexualOrientation": return profile.sexualOrientation || "";
    case "communities": return profile.communitySelections || "";
    case "veteran": return profile.veteranStatus || "";
    case "nationality": return profile.nationality || "";
    default: return "";
  }
}

function cleanQuestionCandidate(text, optionText = "") {
  const value = String(text || "").replace(/\s+/g, " ").trim();
  if (!value || value.length > 500) return "";
  const option = normalizeChoiceText(optionText);
  if (option && normalizeChoiceText(value) === option) return "";
  return value;
}

function getChoiceQuestionText(el) {
  const optionText = String(el?.innerText || el?.textContent || getLabelText(el) || "").trim();
  const fieldset = el.closest?.("fieldset");
  if (fieldset) {
    const legend = fieldset.querySelector("legend");
    const text = cleanQuestionCandidate(legend?.textContent, optionText);
    if (text) return text;
  }
  const group = el.closest?.('[role="radiogroup"], [role="group"], [role="listbox"]');
  if (group) {
    const aria = cleanQuestionCandidate(group.getAttribute("aria-label"), optionText);
    if (aria) return aria;
    const labelledBy = group.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = cleanQuestionCandidate(labelledBy.split(/\s+/).map((id) => document.getElementById(id)?.textContent || "").join(" "), optionText);
      if (text) return text;
    }
  }

  // Ashby and other React ATSs frequently render each checkbox in its own
  // wrapper, with the actual question in a sibling node above the whole list.
  // Walk upward and inspect preceding siblings, preferring question-looking
  // text over the current option label.
  let node = el.parentElement;
  for (let i = 0; i < 8 && node; i++, node = node.parentElement) {
    let prev = node.previousElementSibling;
    for (let j = 0; j < 4 && prev; j++, prev = prev.previousElementSibling) {
      const text = cleanQuestionCandidate(prev.textContent, optionText);
      if (!text) continue;
      if (/\?|\*|which |what |how |do you|are you|gender|age|ethnic|race|veteran|disab|sexual|transgender|communities/i.test(text)) return text;
    }

    const labelledBy = node.getAttribute?.("aria-labelledby");
    if (labelledBy) {
      const text = cleanQuestionCandidate(labelledBy.split(/\s+/).map((id) => document.getElementById(id)?.textContent || "").join(" "), optionText);
      if (text) return text;
    }
  }
  return "";
}

function localDateParts() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return {
    date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
    time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
  };
}

function setImmediateDateInput(el) {
  const { date, time } = localDateParts();
  let value = "";
  if (el.type === "date") value = date;
  else if (el.type === "datetime-local") value = `${date}T${time}`;
  else if (el.type === "month") value = date.slice(0, 7);
  if (!value) return false;
  setNativeValue(el, value);
  return true;
}

function setAvailabilitySelectValue(el, desiredText) {
  if (IMMEDIATE_AVAILABILITY_RE.test(desiredText || "")) {
    const opt = Array.from(el.options).find((o) => IMMEDIATE_AVAILABILITY_RE.test(o.text));
    if (opt) {
      el.value = opt.value;
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
  }
  return setSelectValue(el, desiredText);
}

function highlight(el, kind) {
  el.style.outline = `2px solid ${COLORS[kind]}`;
  el.style.outlineOffset = "1px";
  el.dataset.ztHighlightKind = kind;
}

let ztFieldIdCounter = 0;

function ensureFieldId(el) {
  if (!el.dataset.ztFieldId) {
    ztFieldIdCounter += 1;
    el.dataset.ztFieldId = `zt-field-${ztFieldIdCounter}`;
  }
  return el.dataset.ztFieldId;
}

function isVisibleField(el) {
  if (!el || !el.isConnected) return false;
  const style = getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") return false;
  const rect = el.getBoundingClientRect();
  if (rect.width > 0 && rect.height > 0) return true;
  const visibleLabel = el.closest("label") || (el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`) : null);
  if (visibleLabel) {
    const lr = visibleLabel.getBoundingClientRect();
    return lr.width > 0 && lr.height > 0;
  }
  return false;
}

function isApplicationFieldCandidate(el, label) {
  if (!label) return false;
  if (el.closest("header, nav, footer")) return false;
  if (["password", "range", "color", "reset"].includes(el.type)) return false;
  if (el.type === "search" && !/location|city|country|company|job|title/i.test(label)) return false;
  if (el.closest('form, [role="form"], [role="dialog"], [aria-modal="true"]')) return true;
  if (ATS_HOST_RE.test(location.hostname + location.pathname) && !el.closest("aside")) return true;
  return FIELD_RULES.some((r) => r.re.test(label)) || FILE_RULES.some((r) => r.re.test(label)) ||
    !!demographicKind(label) || LEGAL_RE.test(label) || LANGUAGE_RE.test(label) || NON_COMPETE_RE.test(label) || CONSENT_RE.test(label);
}

function selectIsBlank(el) {
  if (el.multiple) return Array.from(el.selectedOptions || []).filter((o) => String(o.value || "").trim()).length === 0;
  const opt = el.selectedOptions?.[0];
  if (!opt) return true;
  const value = String(el.value || "").trim();
  const text = String(opt.text || "").trim();
  return !value || /^(select|choose|please select|--|none selected)$/i.test(text);
}

function clearStaleMissingHighlights() {
  document.querySelectorAll('[data-zt-missing="1"]').forEach((el) => {
    if (el.dataset.ztHighlightKind === "missing") {
      el.style.outline = "";
      el.style.outlineOffset = "";
      delete el.dataset.ztHighlightKind;
    }
    delete el.dataset.ztMissing;
  });
}

function addMissingRecord(records, seen, el, label, type, reason = "Not filled") {
  const cleanLabel = String(label || "").replace(/\s+/g, " ").trim().slice(0, 240);
  if (!cleanLabel) return;
  const id = ensureFieldId(el);
  if (seen.has(id)) return;
  seen.add(id);
  el.dataset.ztMissing = "1";
  highlight(el, "missing");
  records.push({
    id,
    label: cleanLabel,
    type: type || el.type || el.tagName.toLowerCase(),
    required: !!el.required || el.getAttribute("aria-required") === "true" || /\*|\brequired\b/i.test(cleanLabel),
    reason,
  });
}

function collectUnansweredFields(mark = true) {
  clearStaleMissingHighlights();
  const records = [];
  const seen = new Set();

  document.querySelectorAll("input, textarea, select").forEach((el) => {
    if (el.disabled || ["hidden", "submit", "button", "reset", "image"].includes(el.type)) return;
    if (el.type === "radio" || el.type === "checkbox") return;
    const label = getLabelText(el);
    if (!isVisibleField(el) || !isApplicationFieldCandidate(el, label)) return;
    if (/^(?:phone\s*)?(?:extension|extention|ext\.?)(?:\s*(?:number|no\.?))?\s*\*?$/i.test(label)) return;

    let blank = false;
    if (el.type === "file") blank = !el.files || el.files.length === 0;
    else if (el.tagName === "SELECT") blank = selectIsBlank(el);
    else blank = !String(el.value || "").trim();
    if (!blank) return;

    const reason = isSensitiveNeverStoreField(el, label)
      ? "Sensitive — enter manually; never stored"
      : (CONSENT_RE.test(label) || LEGAL_RE.test(label) ? "Manual review needed" : "Not filled");
    if (mark) addMissingRecord(records, seen, el, label, el.type === "file" ? "file" : el.tagName.toLowerCase(), reason);
    else records.push({ id: ensureFieldId(el), label, type: el.type || el.tagName.toLowerCase(), reason });
  });

  // Native radio groups: one popup row per unanswered question, while every
  // option in the group gets a red outline on the page.
  const radioGroups = new Map();
  document.querySelectorAll('input[type="radio"]').forEach((radio) => {
    if (radio.disabled || !isVisibleField(radio)) return;
    const question = getChoiceQuestionText(radio) || getPrecedingLabelText(radio.parentElement || radio) || getLabelText(radio);
    if (!isApplicationFieldCandidate(radio, question)) return;
    const key = radio.name ? `name:${radio.name}` : `question:${normalizeLearnQuestion(question)}`;
    if (!radioGroups.has(key)) radioGroups.set(key, { question, radios: [] });
    radioGroups.get(key).radios.push(radio);
  });
  radioGroups.forEach(({ question, radios }) => {
    if (!radios.length || radios.some((r) => r.checked)) return;
    const first = radios[0];
    const reason = CONSENT_RE.test(question) || LEGAL_RE.test(question) ? "Manual review needed" : "No option selected";
    if (mark) {
      const id = ensureFieldId(first);
      radios.forEach((r) => { r.dataset.ztMissing = "1"; highlight(r, "missing"); });
      if (!seen.has(id)) {
        seen.add(id);
        records.push({ id, label: String(question || getLabelText(first)).replace(/\s+/g, " ").trim().slice(0, 240), type: "radio", required: radios.some((r) => r.required || r.getAttribute("aria-required") === "true") || /\*|\brequired\b/i.test(question || ""), reason });
      }
    }
  });

  // Checkbox questions are only treated as missing when the control is
  // explicitly required. Optional diversity multi-selects must not become red
  // merely because an applicant chose none.
  document.querySelectorAll('input[type="checkbox"][required], input[type="checkbox"][aria-required="true"]').forEach((cb) => {
    if (cb.disabled || cb.checked || !isVisibleField(cb)) return;
    const label = getChoiceQuestionText(cb) || getLabelText(cb);
    if (!isApplicationFieldCandidate(cb, label)) return;
    if (mark) addMissingRecord(records, seen, cb, label, "checkbox", CONSENT_RE.test(label) ? "Manual review needed" : "Required checkbox not selected");
  });

  // ARIA radio/option widgets used by many modern ATS pages.
  const ariaGroups = new Map();
  document.querySelectorAll('[role="radio"], [role="option"]').forEach((control) => {
    if (!isVisibleField(control)) return;
    const parent = control.parentElement;
    if (!parent) return;
    if (!ariaGroups.has(parent)) ariaGroups.set(parent, []);
    ariaGroups.get(parent).push(control);
  });
  ariaGroups.forEach((controls, parent) => {
    if (controls.length < 2) return;
    const question = getPrecedingLabelText(parent);
    if (!question || !isApplicationFieldCandidate(controls[0], question)) return;
    const selected = controls.some((c) => c.getAttribute("aria-checked") === "true" || c.getAttribute("aria-selected") === "true" || c.getAttribute("data-state") === "checked");
    if (selected) return;
    const first = controls[0];
    if (mark) {
      const id = ensureFieldId(first);
      controls.forEach((c) => { c.dataset.ztMissing = "1"; highlight(c, "missing"); });
      if (!seen.has(id)) {
        seen.add(id);
        records.push({ id, label: question.replace(/\s+/g, " ").trim().slice(0, 240), type: "choice", required: /\*|\brequired\b/i.test(question), reason: CONSENT_RE.test(question) || LEGAL_RE.test(question) ? "Manual review needed" : "No option selected" });
      }
    }
  });

  return records.slice(0, 80);
}

function focusUnansweredField(fieldId) {
  if (!fieldId) return false;
  const el = document.querySelector(`[data-zt-field-id="${CSS.escape(fieldId)}"]`);
  if (!el) return false;
  const target = el.closest("label") || el;
  target.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
  try { el.focus({ preventScroll: true }); } catch (_err) { try { el.focus(); } catch (_err2) {} }
  highlight(el, "missing");
  const oldShadow = el.style.boxShadow;
  el.style.boxShadow = "0 0 0 5px rgba(220,38,38,.20)";
  setTimeout(() => { if (el.isConnected) el.style.boxShadow = oldShadow; }, 1800);
  return true;
}

function setNativeValue(el, value) {
  const proto =
    el.tagName === "TEXTAREA"
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
  setter.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

function setSelectValue(el, text) {
  const opt = Array.from(el.options).find((o) =>
    o.text.toLowerCase().includes(text.toLowerCase())
  );
  if (!opt) return false;
  el.value = opt.value;
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function profileLocationCandidates(key, profile) {
  const out = [];
  const push = (...values) => values.flat().forEach((value) => {
    const text = String(value || "").trim();
    if (text && !out.some((existing) => normalizeChoiceText(existing) === normalizeChoiceText(text))) out.push(text);
  });

  if (key === "city") push(profile.city);
  else if (key === "region") push(profile.region);
  else if (key === "country") push(profile.country);
  return out;
}

function setSelectFromCandidates(el, candidates) {
  const options = Array.from(el.options || []).filter((o) => !o.disabled && String(o.value || "").trim());
  if (!options.length) return false;
  const normalized = candidates.map((c) => normalizeChoiceText(c)).filter(Boolean);
  let match = options.find((o) => normalized.includes(normalizeChoiceText(o.text)));
  if (!match) {
    match = options.find((o) => {
      const text = normalizeChoiceText(o.text);
      return normalized.some((candidate) => candidate.length >= 3 && (text.includes(candidate) || candidate.includes(text)));
    });
  }
  if (!match) return false;
  el.value = match.value;
  el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  return true;
}

function looksLikeCustomCombobox(el) {
  if (!el || el.tagName === "SELECT") return false;
  return el.getAttribute?.("role") === "combobox" ||
    el.getAttribute?.("aria-haspopup") === "listbox" ||
    el.getAttribute?.("aria-autocomplete") === "list" ||
    !!el.getAttribute?.("aria-controls");
}

async function setCustomComboboxFromCandidates(control, candidates) {
  if (!control || !candidates?.length) return false;
  const desired = candidates.map((c) => String(c || "").trim()).filter(Boolean);
  if (!desired.length) return false;
  const normalized = desired.map(normalizeChoiceText);
  const current = normalizeChoiceText(control.value || customChoiceText(control));
  if (normalized.some((candidate) => current === candidate || (candidate.length >= 3 && current.includes(candidate)))) return true;

  // Editable React/ARIA comboboxes usually need text typed first; button-based
  // comboboxes only need a click to reveal their listbox.
  try {
    if ((control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement) && !control.readOnly) {
      setNativeValue(control, desired[0]);
      control.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }
    control.click();
  } catch (_err) { return false; }

  const deadline = Date.now() + 1600;
  while (Date.now() < deadline) {
    const options = Array.from(document.querySelectorAll('[role="option"], [role="menuitem"], [data-radix-collection-item], [data-headlessui-state], [cmdk-item], li'))
      .filter((option) => isVisibleChoice(option));
    let match = options.find((option) => normalized.includes(normalizeChoiceText(customChoiceText(option))));
    if (!match) {
      match = options.find((option) => {
        const text = normalizeChoiceText(customChoiceText(option));
        return normalized.some((candidate) => candidate.length >= 3 && (text.includes(candidate) || candidate.includes(text)));
      });
    }
    if (match) {
      try { match.click(); } catch (_err) {}
      await new Promise((resolve) => setTimeout(resolve, 50));
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, 70));
  }
  return false;
}

function invertYesNo(answer) {
  if (/^yes$/i.test(answer || "")) return "No";
  if (/^no$/i.test(answer || "")) return "Yes";
  return "";
}

function workAuthorizationAnswerForQuestion(label, profile) {
  const configured = (profile.workAuthorizationWithoutSponsorship || "").trim();
  if (/^(yes|no)$/i.test(configured)) {
    if (WORK_AUTH_DIRECT_RE.test(label)) return /^yes$/i.test(configured) ? "Yes" : "No";
    if (SPONSOR_REQUIRED_RE.test(label)) return invertYesNo(configured);
  }
  const eligibility = (profile.workEligibility || "").trim();
  if (/^(yes|no)$/i.test(eligibility) && WORK_ELIGIBILITY_RE.test(label) && !SPONSOR_REQUIRED_RE.test(label)) {
    return /^yes$/i.test(eligibility) ? "Yes" : "No";
  }
  return "";
}

function setChoiceAnswer(el, answer) {
  if (!answer) return false;
  if (el.tagName === "SELECT") {
    const wanted = normalizeChoiceText(answer);
    const options = Array.from(el.options).filter((o) => !o.disabled && o.value !== "");
    const exact = options.find((o) => normalizeChoiceText(o.text) === wanted);
    const loose = exact || options.find((o) => {
      const t = normalizeChoiceText(o.text);
      return wanted.length >= 3 && (t.includes(wanted) || wanted.includes(t));
    });
    if (!loose) return false;
    el.value = loose.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  if (el.type === "checkbox" || el.type === "radio") return false;
  if (looksLikeCustomCombobox(el)) {
    // React/ARIA dropdowns must have an option clicked; typing a value alone
    // often leaves the ATS in an uncommitted/invalid state.
    setCustomComboboxFromCandidates(el, [answer]).then((ok) => {
      if (ok) highlight(el, "filled");
    });
    return true;
  }
  setNativeValue(el, answer);
  return true;
}

// Turns a "data:application/pdf;base64,...." string (saved from the Settings
// file picker) back into a real File object, entirely in memory — no disk path
// involved, so this works regardless of where the browser actually stored it.
function dataUrlToFile(dataUrl, fileName) {
  const [header, base64] = dataUrl.split(",");
  const mimeMatch = header.match(/data:(.*?);base64/);
  const mime = mimeMatch ? mimeMatch[1] : "application/pdf";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new File([bytes], fileName, { type: mime });
}

// Assigning a File via DataTransfer to input.files is allowed by browsers
// (unlike setting .value on a file input) — it's how test tools like
// Playwright/Cypress attach files too. The page sees a real change event,
// same as if the user had picked the file in the native dialog.
function makeFileTransfer(file) {
  const dt = new DataTransfer();
  dt.items.add(file);
  try { dt.effectAllowed = "all"; } catch (_err) {}
  try { dt.dropEffect = "copy"; } catch (_err) {}
  return dt;
}

function dispatchFileDrop(target, file) {
  if (!target || !file) return false;
  try {
    // Use the same DataTransfer through the whole drag lifecycle. Some React
    // uploaders remember state from dragenter/dragover and reject a drop that
    // arrives with a different transfer object.
    const dt = makeFileTransfer(file);
    ["dragenter", "dragover", "drop"].forEach((type) => {
      let event;
      try {
        event = new DragEvent(type, { bubbles: true, cancelable: true, composed: true, dataTransfer: dt });
      } catch (_err) {
        event = new Event(type, { bubbles: true, cancelable: true, composed: true });
        try { Object.defineProperty(event, "dataTransfer", { value: dt }); } catch (_err2) {}
      }
      target.dispatchEvent(event);
    });
    return true;
  } catch (_err) {
    return false;
  }
}

function setInputFiles(el, files) {
  try {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "files")?.set;
    if (setter) setter.call(el, files);
    else el.files = files;
    return true;
  } catch (_err) {
    try { el.files = files; return true; } catch (_err2) { return false; }
  }
}

function uploadDropTargetsNear(el) {
  const out = [];
  let node = el;
  for (let i = 0; i < 5 && node; i++, node = node.parentElement) {
    if (!node) break;
    if (node !== el && isLikelyUploadDropzone(node)) out.push(node);
    try {
      node.querySelectorAll?.('[data-testid*="upload" i], [data-test*="upload" i], [class*="drop" i], [class*="upload" i], [role="button"]')
        .forEach((candidate) => { if (candidate !== el && isLikelyUploadDropzone(candidate)) out.push(candidate); });
    } catch (_err) {}
  }
  return Array.from(new Set(out)).slice(0, 6);
}

// Directly place the reconstructed File into a normal HTML file input. We use
// the native `files` setter, then fire input/change, and finally send a real
// drag lifecycle to nearby dropzones. This is especially useful for Ashby's
// React uploader, including hidden inputs behind “Upload File” / “Replace”.
function attachFileToInput(el, dataUrl, fileName) {
  try {
    const file = dataUrlToFile(dataUrl, fileName);
    const dt = makeFileTransfer(file);
    if (!setInputFiles(el, dt.files)) return false;
    el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    uploadDropTargetsNear(el).forEach((target) => dispatchFileDrop(target, file));
    return !!el.files?.length && el.files[0]?.name === fileName;
  } catch (err) {
    console.warn("[Easy Apply] couldn't attach file input", err);
    return false;
  }
}

function deepQuerySelectorAll(selector, root = document) {
  const out = [];
  const visit = (node) => {
    try { out.push(...node.querySelectorAll(selector)); } catch (_err) {}
    let all = [];
    try { all = node.querySelectorAll("*"); } catch (_err) {}
    all.forEach((el) => { if (el.shadowRoot) visit(el.shadowRoot); });
  };
  visit(root);
  return Array.from(new Set(out));
}

function uploadContextPieces(el) {
  const direct = [
    getLabelText(el),
    el.getAttribute?.("name"),
    el.id,
    el.getAttribute?.("aria-label"),
    el.getAttribute?.("title"),
    el.getAttribute?.("data-testid"),
    el.getAttribute?.("data-test"),
    el.getAttribute?.("accept"),
    el instanceof HTMLButtonElement ? el.innerText : "",
  ].filter(Boolean).map((text) => ({ text: String(text), weight: 120 }));

  const parts = [...direct];
  let node = el;
  for (let i = 0; i < 6 && node; i++, node = node.parentElement) {
    if (!node) break;
    const ownText = String(node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
    if (ownText && ownText.length <= 900) parts.push({ text: ownText, weight: Math.max(20, 78 - i * 10) });

    let prev = node.previousElementSibling;
    for (let j = 0; j < 3 && prev; j++, prev = prev.previousElementSibling) {
      const prevText = String(prev.innerText || prev.textContent || "").replace(/\s+/g, " ").trim();
      if (prevText && prevText.length <= 450) parts.push({ text: prevText, weight: Math.max(30, 90 - i * 10 - j * 12) });
    }
  }
  return parts;
}

function uploadContextText(el) {
  return uploadContextPieces(el).map((p) => p.text).join(" ").replace(/\s+/g, " ").trim();
}

function fileRuleScore(el, rule) {
  let score = 0;
  uploadContextPieces(el).forEach(({ text, weight }) => {
    if (rule.re.test(text)) score = Math.max(score, weight);
  });
  return score;
}

function fileRuleForElement(el) {
  let best = null;
  let bestScore = 0;
  FILE_RULES.forEach((rule) => {
    const score = fileRuleScore(el, rule);
    if (score > bestScore) { bestScore = score; best = rule; }
  });
  return best;
}

function storedFileForKey(profile, key) {
  const name = profile?.[`${key}FileName`];
  const dataUrl = profile?.[`${key}FileDataUrl`];
  return name && dataUrl ? { name, dataUrl, file: dataUrlToFile(dataUrl, name) } : null;
}

function isLikelyUploadDropzone(el) {
  if (!el || el.matches?.('input[type="file"]')) return false;
  const context = uploadContextText(el);
  if (!/(upload|attach|drag.{0,20}drop|drop.{0,20}file|choose file|browse files|replace|resume|résumé|\bcv\b|cover[\s_-]*letter|motivation[\s_-]*letter|portfolio|work[\s_-]*sample)/i.test(context)) return false;
  const style = getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") return false;
  return true;
}

function uploadActionCandidatesForKey(key) {
  const rule = FILE_RULES.find((r) => r.key === key);
  return deepQuerySelectorAll('button, [role="button"], label')
    .filter((el) => isVisibleChoice(el))
    .filter((el) => /upload|replace|choose|browse|attach/i.test(customChoiceText(el)))
    .map((el) => ({ el, score: rule ? fileRuleScore(el, rule) : 0 }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((item) => item.el);
}

function matchingFileInputsForKey(key) {
  const inputs = deepQuerySelectorAll('input[type="file"]');
  const classified = inputs.filter((el) => fileRuleForElement(el)?.key === key);
  if (classified.length) return { all: inputs, targets: classified };
  // Only use the sole unclassified input as a fallback. On pages with multiple
  // uploads (resume + cover letter), guessing would put the document in the
  // wrong field.
  return { all: inputs, targets: inputs.length === 1 ? inputs : [] };
}

function interceptNextFilePicker(stored, key, ttl = 1200) {
  let attached = 0;
  const handler = (event) => {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [event.target];
    const input = path.find((node) => node?.matches?.('input[type="file"]'));
    if (!input) return;
    const classified = fileRuleForElement(input);
    if (classified && classified.key !== key) return;
    // Prevent the OS chooser opened by Ashby's hidden file input. The extension
    // already has an explicitly user-selected local file, so attach that file
    // to the exact picker the site just requested.
    event.preventDefault();
    event.stopPropagation();
    try { event.stopImmediatePropagation(); } catch (_err) {}
    if (attachFileToInput(input, stored.dataUrl, stored.name)) attached++;
  };
  document.addEventListener("click", handler, true);
  setTimeout(() => document.removeEventListener("click", handler, true), ttl);
  return () => attached;
}

function scheduleUploadActionRetry(profile, key, stored) {
  const actions = uploadActionCandidatesForKey(key);
  if (!actions.length) return;
  actions.slice(0, 2).forEach((action, index) => {
    setTimeout(() => {
      const getIntercepted = interceptNextFilePicker(stored, key);
      try { action.click(); } catch (_err) {}
      // React may mount the real <input type=file> only after the action click.
      // Scan a few times and attach directly without relying only on the click.
      [0, 80, 220, 500].forEach((delay) => setTimeout(() => {
        const { targets } = matchingFileInputsForKey(key);
        targets.forEach((input) => attachFileToInput(input, stored.dataUrl, stored.name));
        try { dispatchFileDrop(action, stored.file); } catch (_err) {}
      }, delay));
      setTimeout(() => { try { getIntercepted(); } catch (_err) {} }, 650);
    }, index * 120);
  });
}

function attachStoredFileByKey(profile, key) {
  const stored = storedFileForKey(profile, key);
  if (!stored) return { found: 0, attached: 0, dropped: 0 };
  const { all: inputs, targets } = matchingFileInputsForKey(key);
  let attached = 0;
  targets.forEach((el) => {
    if (attachFileToInput(el, stored.dataUrl, stored.name)) {
      highlight(el, "filled");
      attached++;
    }
  });

  const rule = FILE_RULES.find((r) => r.key === key);
  const dropCandidates = deepQuerySelectorAll('[data-testid*="upload" i], [data-test*="upload" i], [class*="dropzone" i], [class*="drop-zone" i], [class*="file-upload" i], [class*="upload" i], [role="button"], label')
    .filter(isLikelyUploadDropzone)
    .map((el) => ({ el, score: rule ? fileRuleScore(el, rule) : 0 }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .map((item) => item.el);

  let dropped = 0;
  dropCandidates.forEach((el) => { if (dispatchFileDrop(el, stored.file)) dropped++; });

  // Always schedule the Upload/Replace path too. This replaces an already
  // attached resume on Ashby when the visible UI has detached the old input
  // from the DOM and only exposes a “Replace” action.
  scheduleUploadActionRetry(profile, key, stored);
  return { found: targets.length || inputs.length || dropCandidates.length, attached, dropped };
}

function getLabelText(el) {
  let text = "";
  if (el.labels && el.labels.length) {
    text = Array.from(el.labels).map((l) => l.innerText || "").join(" ");
  }
  if (!text) text = el.getAttribute("aria-label") || "";
  if (!text && el.getAttribute("aria-labelledby")) {
    text = el
      .getAttribute("aria-labelledby")
      .split(" ")
      .map((id) => document.getElementById(id)?.innerText || "")
      .join(" ");
  }
  if (!text) text = el.getAttribute("placeholder") || "";
  if (!text) {
    // Some ATS forms (e.g. LinkedIn's split phone-number fieldset) render the
    // <label> as a nearby descendant rather than a true <label for="...">
    // match — fall back to the closest field-sized wrapper's own label.
    const wrap = el.closest("div, li");
    if (wrap) {
      const lbl = wrap.querySelector("label");
      if (lbl && lbl.innerText && lbl.innerText.trim().length < 200) text = lbl.innerText;
    }
  }
  if (!text) {
    let node = el;
    for (let i = 0; i < 4 && node; i++) {
      node = node.parentElement;
      if (!node) break;
      const prev = node.previousElementSibling;
      if (prev && prev.innerText && prev.innerText.trim().length < 200) {
        text = prev.innerText;
        break;
      }
    }
  }
  return text.trim();
}

// The visible question text for a group of choice controls (buttons, checkboxes)
// that share a parent — usually the text right before the group.
function getPrecedingLabelText(groupParent) {
  let text = "";
  const prev = groupParent.previousElementSibling;
  if (prev) text = prev.innerText || prev.textContent || "";
  if (!text && groupParent.parentElement) {
    text = Array.from(groupParent.parentElement.childNodes)
      .filter((n) => n.nodeType === Node.TEXT_NODE || (n.nodeType === 1 && n !== groupParent))
      .map((n) => n.textContent || "")
      .join(" ");
  }
  return text.trim();
}

// --- Learn manual answers -------------------------------------------------
// Unknown questions answered by the applicant can be remembered locally and
// reused later. Synthetic events fired by this extension have isTrusted=false,
// so only real manual interactions are learned. Legal/work-authorization
// answers are deliberately scoped to the same application site/company and
// require an exact normalized question match.
const LEARNED_ANSWERS_VERSION = 2;
const MAX_LEARNED_ANSWERS = 250;
const NEVER_LEARN_RE = /privacy policy|terms (?:and|&) conditions|terms of use|consent|attest|certif(?:y|ication)|electronic signature|e-sign|acknowledg(?:e|ement)|declaration/i;

// Learning is intentionally limited to real application-form UI. The content
// script runs on broad job sites too (LinkedIn Jobs, Indeed, etc.), where search
// boxes, filters, navigation dropdowns, and messaging controls must never become
// reusable application answers.
const NON_APPLICATION_LEARN_QUESTION_RE = /^(?:search|search jobs?|job search|search for jobs?|search by .+|keywords?|job keywords?|job title keywords?|title skill or company)$/i;
const DEDICATED_ATS_HOST_RE = /(?:^|\.)(?:greenhouse\.io|lever\.co|ashbyhq\.com|myworkday\.com|smartrecruiters\.com|breezy\.hr|bamboohr\.com|workable\.com|jobvite\.com|icims\.com|taleo\.net)$/i;
const APPLICATION_EVIDENCE_RE = /\b(?:application|apply for|easy apply|submit application|review your application|additional questions?|resume|résumé|curriculum vitae|\bcv\b|cover letter|work authorization|visa sponsorship|years? of experience|salary expectations?|current company|current employer|linkedin|portfolio|contact info(?:rmation)?|personal information)\b/i;

function isClearlyNonApplicationQuestion(text) {
  const q = normalizeLearnQuestion(text || "");
  return !!q && NON_APPLICATION_LEARN_QUESTION_RE.test(q);
}

function isNonApplicationPageControl(el) {
  if (!(el instanceof Element)) return true;
  if (el.matches?.('input[type="search"], [role="searchbox"]')) return true;
  return !!el.closest?.([
    'header',
    'nav',
    '[role="navigation"]',
    '[role="search"]',
    '.global-nav',
    '.search-global-typeahead',
    '.jobs-search-box',
    '.jobs-search-results-list',
    '.msg-overlay-container',
    '.messaging-overlay'
  ].join(','));
}

function localApplicationEvidence(container) {
  if (!(container instanceof Element)) return false;
  const controls = Array.from(container.querySelectorAll('input:not([type="hidden"]):not([type="search"]), textarea, select, [role="combobox"], [role="radiogroup"], [role="checkbox"]'));
  if (!controls.length) return false;

  let hits = 0;
  for (const control of controls.slice(0, 30)) {
    const label = getLabelText(control);
    if (!label) continue;
    if (FIELD_RULES.some((r) => r.re.test(label)) || LEGAL_RE.test(label) || demographicKind(label) || APPLICATION_EVIDENCE_RE.test(label)) hits++;
  }
  if (hits >= 1) return true;

  const text = String(container.innerText || container.textContent || "").slice(0, 6000);
  return APPLICATION_EVIDENCE_RE.test(text);
}

function isApplicationLearningTarget(el) {
  if (!(el instanceof Element) || isNonApplicationPageControl(el)) return false;

  const host = location.hostname.toLowerCase();

  // LinkedIn Jobs contains search, filters, saved-job controls, messaging, and
  // Easy Apply on the same page. Be strict here: learning is allowed only from
  // the Easy Apply application dialog itself.
  if (/(?:^|\.)linkedin\.com$/.test(host)) {
    const easyApply = el.closest?.('.jobs-easy-apply-modal, .jobs-easy-apply-content, [data-test-modal-id*="easy-apply" i], [data-testid*="easy-apply" i]');
    if (easyApply) return true;

    const dialog = el.closest?.('[role="dialog"], .artdeco-modal');
    if (!dialog) return false;
    const text = String(dialog.innerText || dialog.textContent || "").slice(0, 5000);
    return /\b(?:easy apply|submit application|review your application|additional questions?|contact info(?:rmation)?|resume|résumé|work authorization)\b/i.test(text);
  }

  // Ordinary HTML forms are the safest boundary on external ATS/career pages.
  const form = el.closest?.('form, [role="form"]');
  if (form) {
    if (isNonApplicationPageControl(form)) return false;
    if (localApplicationEvidence(form)) return true;

    // Dedicated ATS hosts often render individual application steps with very
    // little surrounding copy. Permit those forms, but never obvious auth/search
    // forms and require at least two non-search controls.
    if (DEDICATED_ATS_HOST_RE.test(host)) {
      const text = String(form.innerText || form.textContent || "").slice(0, 3000);
      if (/\b(?:sign in|log in|login|forgot password|search jobs?)\b/i.test(text) && !APPLICATION_EVIDENCE_RE.test(text)) return false;
      const count = form.querySelectorAll('input:not([type="hidden"]):not([type="search"]), textarea, select, [role="combobox"], [role="radiogroup"], [role="checkbox"]').length;
      if (count >= 2) return true;
    }
    return false;
  }

  // Some React ATSs don't use a <form>. Walk only a few ancestors and require
  // both multiple controls and local application-specific evidence.
  let node = el;
  for (let depth = 0; depth < 6 && node; depth++, node = node.parentElement) {
    if (isNonApplicationPageControl(node)) return false;
    const count = node.querySelectorAll?.('input:not([type="hidden"]):not([type="search"]), textarea, select, [role="combobox"], [role="radiogroup"], [role="checkbox"]')?.length || 0;
    if (count >= 2 && localApplicationEvidence(node)) return true;
  }
  return false;
}
let isExtensionApplyingAnswers = false;

function normalizeLearnQuestion(text) {
  return normalizeChoiceText(text)
    .replace(/[*:?.!]+/g, " ")
    .replace(/\b(required|optional)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 500);
}

function applicationScope() {
  const host = location.hostname.toLowerCase();
  const first = location.pathname.split("/").filter(Boolean)[0] || "";
  if (/jobs\.lever\.co|jobs\.ashbyhq\.com|boards\.greenhouse\.io|job-boards\.greenhouse\.io|jobs\.smartrecruiters\.com|apply\.workable\.com/.test(host)) {
    return `${host}/${first}`;
  }
  return host;
}

function learnedRecordKey(questionNorm, legal) {
  return `${legal ? `scoped:${applicationScope()}` : "global"}::${questionNorm}`;
}

function isKnownAutofillQuestion(question) {
  if (!question) return true;
  if (isSensitiveNeverStoreQuestion(question)) return true;
  if (LEGAL_RE.test(question)) return false; // legal answers may be learned conservatively
  // Voluntary demographic answers may be learned from a real manual click.
  // This is especially important for multi-select checkbox surveys whose
  // exact options vary across ATSs. Synthetic extension clicks are ignored by
  // the trusted-event guard, so only the applicant's own interaction is saved.
  if (LANGUAGE_RE.test(question) || AUTO_YES_RE.test(question) || NON_COMPETE_RE.test(question) || CONSENT_RE.test(question)) return true;
  return FIELD_RULES.some((r) => r.key !== "SKIP" && r.re.test(question));
}

function questionTokens(text) {
  const stop = new Set(["a", "an", "the", "this", "that", "for", "of", "to", "in", "on", "at", "is", "are", "do", "does", "you", "your", "our", "we", "what", "which", "please"]);
  return normalizeLearnQuestion(text).split(/[^a-z0-9]+/).filter((t) => t.length > 1 && !stop.has(t));
}

function questionSimilarity(a, b) {
  const aa = new Set(questionTokens(a));
  const bb = new Set(questionTokens(b));
  if (aa.size < 4 || bb.size < 4) return 0;
  let intersection = 0;
  aa.forEach((t) => { if (bb.has(t)) intersection++; });
  const union = new Set([...aa, ...bb]).size;
  return union ? intersection / union : 0;
}

function findLearnedAnswer(question, learnedAnswers) {
  if (isSensitiveNeverStoreQuestion(question)) return null;
  const q = normalizeLearnQuestion(question);
  if (!q) return null;
  const records = learnedAnswers?.records || {};
  const legal = LEGAL_RE.test(question);
  const exact = records[learnedRecordKey(q, legal)];
  if (exact?.answer) return exact;
  if (legal) return null; // never fuzzy-match legal/work authorization questions

  let best = null;
  let bestScore = 0;
  Object.values(records).forEach((record) => {
    if (!record || record.legal || !record.answer || !record.questionNorm) return;
    if (isSensitiveNeverStoreQuestion(record.question || record.questionNorm)) return;
    const score = questionSimilarity(q, record.questionNorm);
    if (score >= 0.9 && score > bestScore) {
      bestScore = score;
      best = record;
    }
  });
  return best;
}

function learningQuestionForElement(el) {
  if (el.type === "radio" || el.type === "checkbox") {
    return getChoiceQuestionText(el) || getPrecedingLabelText(el.parentElement || el) || getLabelText(el);
  }
  return getLabelText(el);
}

function manualAnswerForElement(el) {
  if (el.tagName === "SELECT") {
    return el.selectedOptions?.[0]?.text?.trim() || "";
  }
  if (el.type === "radio") return el.checked ? getLabelText(el).trim() : "";
  if (el.type === "checkbox") return el.checked ? getLabelText(el).trim() : "";
  return String(el.value || "").trim();
}

function saveLearnedAnswer(question, answer, options = {}) {
  question = String(question || "").trim();
  answer = String(answer || "").trim();
  const questionNorm = normalizeLearnQuestion(question);
  if (!questionNorm || questionNorm.length < 4 || !answer || answer.length > 2000) return;
  if (NEVER_LEARN_RE.test(`${question} ${answer}`)) return;
  if (isClearlyNonApplicationQuestion(question)) return;
  if (isSensitiveNeverStoreQuestion(question)) return;
  // Text fields that are already covered by the saved profile are not learned,
  // but an explicit manual choice (select/radio/checkbox/custom dropdown) is.
  // This lets the extension remember the user's real click even when the
  // question happens to overlap a built-in rule.
  if (isKnownAutofillQuestion(question) && options.force !== true) return;

  const legal = LEGAL_RE.test(question);
  const key = learnedRecordKey(questionNorm, legal);
  chrome.storage.local.get(["profile", "learnedAnswers"], ({ profile, learnedAnswers }) => {
    const data = normalizeProfile(profile);
    if (data.learnNewAnswers === false) return;

    const sanitized = sanitizeLearnedAnswersStore(learnedAnswers).store;
    const store = { version: LEARNED_ANSWERS_VERSION, records: { ...(sanitized.records || {}) } };

    const previous = store.records[key];
    let storedAnswer = answer;
    if (options.multi) {
      const choices = splitConfiguredChoices(previous?.answer || "");
      const wanted = normalizeChoiceText(answer);
      const next = choices.filter((choice) => normalizeChoiceText(choice) !== wanted);
      if (options.selected !== false) next.push(answer);
      storedAnswer = Array.from(new Map(next.map((choice) => [normalizeChoiceText(choice), choice])).values()).join(", ");
      if (!storedAnswer) {
        if (previous) { delete store.records[key]; chrome.storage.local.set({ learnedAnswers: store }); }
        return;
      }
    }

    if (previous?.answer === storedAnswer) return;
    store.records[key] = {
      question: question.slice(0, 500),
      questionNorm,
      answer: storedAnswer,
      multi: !!options.multi,
      controlType: options.controlType || previous?.controlType || "",
      legal,
      scope: legal ? applicationScope() : "global",
      updatedAt: Date.now(),
    };

    const entries = Object.entries(store.records);
    if (entries.length > MAX_LEARNED_ANSWERS) {
      entries.sort((a, b) => (b[1]?.updatedAt || 0) - (a[1]?.updatedAt || 0));
      store.records = Object.fromEntries(entries.slice(0, MAX_LEARNED_ANSWERS));
    }
    chrome.storage.local.set({ learnedAnswers: store });
  });
}

function sanitizeLearnedAnswersStore(learnedAnswers) {
  const records = learnedAnswers?.records || {};
  let changed = learnedAnswers?.version !== LEARNED_ANSWERS_VERSION;
  const safeRecords = {};
  Object.entries(records).forEach(([key, record]) => {
    const text = `${record?.question || ""} ${record?.questionNorm || ""}`;
    if (isSensitiveNeverStoreQuestion(text) || isClearlyNonApplicationQuestion(record?.question || record?.questionNorm || "")) {
      changed = true;
      return;
    }
    safeRecords[key] = record;
  });
  return { changed, store: { version: LEARNED_ANSWERS_VERSION, records: safeRecords } };
}

// Purge any sensitive answers that an older build may have learned. Normal
// learned application answers are preserved.
chrome.storage.local.get("learnedAnswers", ({ learnedAnswers }) => {
  if (!learnedAnswers) return;
  const { changed, store } = sanitizeLearnedAnswersStore(learnedAnswers);
  if (changed) chrome.storage.local.set({ learnedAnswers: store });
});

function isControlSelected(control) {
  if (!control) return false;
  if ("checked" in control && typeof control.checked === "boolean") return control.checked;
  return control.getAttribute?.("aria-checked") === "true" ||
    control.getAttribute?.("aria-selected") === "true" ||
    control.getAttribute?.("aria-pressed") === "true" ||
    /^(checked|on|selected)$/i.test(control.getAttribute?.("data-state") || "");
}

function clickChoiceIfNeeded(control) {
  if (!control) return false;
  if (isControlSelected(control)) return true;
  try { control.click(); return true; } catch (_err) { return false; }
}

function matchingChoiceControl(controls, getText, answer) {
  const wanted = normalizeChoiceText(answer);
  if (!wanted) return null;
  const exact = controls.find((c) => normalizeChoiceText(getText(c)) === wanted);
  if (exact) return exact;
  return controls.find((c) => {
    const t = normalizeChoiceText(getText(c));
    return wanted.length >= 3 && (t.includes(wanted) || wanted.includes(t));
  }) || null;
}

// Track the dropdown the applicant actually opened. Many React component
// libraries portal their option list to <body>, so once an option is clicked it
// no longer has the question label as a DOM ancestor/sibling. Remembering the
// last manually opened combobox lets us associate that option with the right
// question and save it reliably.
let lastManualCombobox = null;
let lastManualComboboxAt = 0;

function rememberManualComboboxFromEvent(event) {
  if (isExtensionApplyingAnswers || !event.isTrusted) return;
  const target = event.target instanceof Element ? event.target : null;
  if (!target) return;
  const control = target.closest?.('[role="combobox"], select, button[aria-haspopup="listbox"], [role="button"][aria-haspopup="listbox"], [aria-haspopup="listbox"]');
  if (!control || !isApplicationLearningTarget(control)) return;
  lastManualCombobox = control;
  lastManualComboboxAt = Date.now();
}

document.addEventListener("pointerdown", rememberManualComboboxFromEvent, true);
document.addEventListener("mousedown", rememberManualComboboxFromEvent, true);

function recentManualCombobox() {
  if (!lastManualCombobox || !lastManualCombobox.isConnected) return null;
  if (Date.now() - lastManualComboboxAt > 15000) return null;
  return lastManualCombobox;
}

function questionForCustomOption(option) {
  const direct = getChoiceQuestionText(option);
  if (direct) return direct;

  const listbox = option.closest?.('[role="listbox"], [role="menu"]');
  if (listbox) {
    const aria = String(listbox.getAttribute("aria-label") || "").trim();
    if (aria) return aria;
    const labelledBy = String(listbox.getAttribute("aria-labelledby") || "").trim();
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id) => document.getElementById(id)?.textContent || "").join(" ").trim();
      if (text) return text;
    }
  }

  const combo = recentManualCombobox();
  if (combo) return getLabelText(combo) || getPrecedingLabelText(combo.parentElement || combo);
  return "";
}

document.addEventListener("change", (event) => {
  if (isExtensionApplyingAnswers || !event.isTrusted) return;
  const el = event.target;
  if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement)) return;
  if (["file", "hidden", "password", "submit", "button", "reset", "search"].includes(el.type)) return;
  if (!isApplicationLearningTarget(el)) return;
  const question = learningQuestionForElement(el);
  if (isSensitiveNeverStoreField(el, question)) return;

  if (el.tagName === "SELECT") {
    const answer = manualAnswerForElement(el);
    if (question && answer) saveLearnedAnswer(question, answer, { force: true, controlType: "select" });
    return;
  }
  if (el.type === "radio") {
    const answer = manualAnswerForElement(el);
    if (question && answer) saveLearnedAnswer(question, answer, { force: true, controlType: "radio" });
    return;
  }
  if (el.type === "checkbox") {
    const option = getLabelText(el).trim();
    if (question && option) saveLearnedAnswer(question, option, { multi: true, selected: el.checked, force: true, controlType: "checkbox" });
    return;
  }

  // Keep the old conservative behavior for manually typed text: only unknown
  // questions are learned, so a typo in a core profile field never becomes a
  // new default.
  const answer = manualAnswerForElement(el);
  if (question && answer) saveLearnedAnswer(question, answer);
}, true);

document.addEventListener("click", (event) => {
  if (isExtensionApplyingAnswers || !event.isTrusted) return;
  const target = event.target instanceof Element ? event.target : null;
  if (!target) return;

  const btn = target.closest?.('[role="radio"], [role="checkbox"], [role="option"], [role="menuitem"], [data-radix-collection-item], [data-headlessui-state], [cmdk-item], button');
  if (!btn) return;
  const answer = customChoiceText(btn) || (btn.innerText || btn.textContent || "").trim();
  if (!answer || /^(next|previous|back|continue|submit|apply|save|cancel|close|upload|choose file)$/i.test(answer)) return;

  const role = String(btn.getAttribute?.("role") || "").toLowerCase();
  const isDropdownOption = role === "option" || role === "menuitem" || btn.hasAttribute?.("data-radix-collection-item") || btn.hasAttribute?.("cmdk-item");
  if (isDropdownOption) {
    // Portalled options may live under <body>; bind them only to a combobox that
    // the applicant manually opened inside an application form.
    const combo = recentManualCombobox();
    if (!combo || !isApplicationLearningTarget(combo)) return;
    const question = questionForCustomOption(btn);
    if (question) saveLearnedAnswer(question, answer, { force: true, controlType: "custom-select" });
    return;
  }

  if (!isApplicationLearningTarget(btn)) return;

  if (role === "checkbox") {
    const question = getChoiceQuestionText(btn) || getPrecedingLabelText(btn.parentElement || btn);
    if (!question) return;
    // Capture runs before many component libraries update aria-checked.
    setTimeout(() => saveLearnedAnswer(question, answer, { multi: true, selected: isControlSelected(btn), force: true, controlType: "custom-checkbox" }), 0);
    return;
  }

  const parent = btn.parentElement;
  const siblings = parent ? Array.from(parent.querySelectorAll('[role="radio"], [role="option"], button')) : [];
  const question = getChoiceQuestionText(btn) || getPrecedingLabelText(parent);
  if (!question) return;
  if (role === "radio" || siblings.length >= 2) saveLearnedAnswer(question, answer, { force: true, controlType: "custom-radio" });
}, true);

function currentWorkContext(el) {
  let node = el;
  for (let i = 0; i < 5 && node; i++, node = node.parentElement) {
    const text = (node.innerText || node.textContent || "").slice(0, 1200);
    if (/where do you currently work|current employer|current company|your company will never see|current role|current position/i.test(text)) return true;
  }
  return false;
}

function looksLikeApplicationForm() {
  if (ATS_HOST_RE.test(location.hostname + location.pathname)) return true;

  // A company career page may host the actual ATS in a cross-origin iframe.
  // The top frame cannot inspect that iframe's fields, so recognize the frame
  // itself as enough evidence to keep the on-page assistant available.
  const embeddedApplication = Array.from(document.querySelectorAll("iframe[src]"))
    .some((frame) => {
      const src = String(frame.getAttribute("src") || "");
      return ATS_HOST_RE.test(src) || /(?:jobs?|careers?|apply|application|candidate)/i.test(src);
    });
  if (embeddedApplication) return true;

  const fields = document.querySelectorAll("input, textarea, select, [role=combobox], [role=radiogroup]");
  let hits = 0;
  fields.forEach((el) => {
    const label = getLabelText(el);
    if (!label) return;
    if (FIELD_RULES.some((r) => r.re.test(label)) || demographicKind(label) || LEGAL_RE.test(label)) hits++;
  });
  return hits >= 2;
}

function fillForm(profile, learnedAnswers = {}) {
  isExtensionApplyingAnswers = true;
  profile = normalizeProfile(profile);
  profile.fullName = `${profile.firstName || ""} ${profile.lastName || ""}`.trim();
  profile.cityCountry = `${profile.city || ""}, ${profile.country || ""}`.replace(/^, |, $/, "");

  let filled = 0;
  let flagged = 0;
  let fileHelpers = 0;

  document.querySelectorAll("input, textarea, select").forEach((el) => {
    try {
      if (el.type === "hidden" || el.type === "submit" || el.type === "button" || el.type === "file" || el.disabled) return;
      const label = getLabelText(el);
      if (!label) return;

      // Passwords, OTP/security codes, passport/government IDs and financial
      // secrets are never read from learned answers and never auto-filled.
      if (isSensitiveNeverStoreField(el, label)) {
        highlight(el, "review");
        flagged++;
        return;
      }

      // Consent/attestation is intentionally never accepted automatically.
      if (CONSENT_RE.test(label)) {
        highlight(el, "review");
        flagged++;
        return;
      }

      // Some ATSs label a split-phone dial-code control only “Country”. Handle
      // that before the generic residence-country rule so it selects the saved phone country /
      // +90 instead of incorrectly filling the applicant's residence country.
      if (looksLikePhoneCountryControl(el)) {
        if (el.tagName === "SELECT") {
          if (setPhoneCountrySelect(el, profile)) { highlight(el, "filled"); filled++; }
        } else {
          setCustomPhoneCountryControl(el, profile).then((ok) => { if (ok) highlight(el, "filled"); });
        }
        return;
      }

      // Some profile screens show only bare “Company” / “Job title” labels
      // under a preceding “Where do you currently work?” heading. Fill those
      // only when nearby context clearly says this is the current role.
      if (currentWorkContext(el)) {
        if (/^company(?: name)?$/i.test(label.trim()) && profile.currentCompany && el.type !== "checkbox" && el.type !== "radio") {
          if (el.tagName === "SELECT") setSelectValue(el, profile.currentCompany);
          else setNativeValue(el, profile.currentCompany);
          highlight(el, "filled"); filled++; return;
        }
        if (/^(?:job )?title$|^position$/i.test(label.trim()) && profile.currentJobTitle && el.type !== "checkbox" && el.type !== "radio") {
          if (el.tagName === "SELECT") setSelectValue(el, profile.currentJobTitle);
          else setNativeValue(el, profile.currentJobTitle);
          highlight(el, "filled"); filled++; return;
        }
      }

      if (NON_COMPETE_RE.test(label) && profile.nonCompete && el.type !== "checkbox" && el.type !== "radio") {
        if (setChoiceAnswer(el, profile.nonCompete)) { highlight(el, "filled"); filled++; }
        return;
      }

      // Learned answers are only for genuinely unknown questions. Core profile
      // fields (especially Phone/Email/Name/Location) must always use the saved
      // profile, otherwise an old learned value can overwrite the real contact
      // data — e.g. a stale numeric answer ending up in the Phone field.
      const isKnownProfileField = FIELD_RULES.some((rule) => rule.key !== "SKIP" && rule.re.test(label));
      if (el.type !== "checkbox" && el.type !== "radio") {
        if (!isKnownProfileField) {
          const learned = findLearnedAnswer(label, learnedAnswers);
          if (learned && setChoiceAnswer(el, learned.answer)) {
            highlight(el, "filled");
            filled++;
            return;
          }
        }

        const workAuthAnswer = workAuthorizationAnswerForQuestion(label, profile);
        if (workAuthAnswer && setChoiceAnswer(el, workAuthAnswer)) {
          highlight(el, "filled");
          filled++;
          return;
        }
      }

      const demoKind = demographicKind(label);
      if (demoKind && !LEGAL_RE.test(label)) {
        if (el.tagName === "SELECT") {
          if (setDemographicSelectValue(el, demoKind, profile)) {
            highlight(el, "filled");
            filled++;
          }
          return;
        }
        if (el.type !== "checkbox" && el.type !== "radio") {
          const demoValue = demographicTextValue(demoKind, profile);
          if (demoValue) {
            if (looksLikeCustomCombobox(el)) {
              // Nationality and other demographic dropdowns are frequently
              // custom React listboxes rather than native <select>s. Open the
              // list and choose the saved answer instead of merely typing text.
              const candidates = demographicCandidates(demoKind, profile);
              setCustomComboboxFromCandidates(el, candidates).then((ok) => {
                if (ok) highlight(el, "filled");
                else highlight(el, "estimate");
              });
              highlight(el, "estimate");
              filled++;
            } else {
              setNativeValue(el, demoValue);
              highlight(el, "filled");
              filled++;
            }
          }
          return;
        }
      }

      if (el.tagName === "SELECT") {
        if (LANGUAGE_RE.test(label)) {
          const langName = extractLanguageName(label);
          if (langName) {
            const desired = getLanguageValue(profile, langName);
            if (desired) {
              const options = Array.from(el.options);
              const idx = closestProficiencyIndex(options.map((o) => o.text), desired);
              if (idx !== -1) {
                el.value = options[idx].value;
                el.dispatchEvent(new Event("change", { bubbles: true }));
                highlight(el, "filled");
                filled++;
              } else if (setSelectValue(el, desired)) {
                highlight(el, "filled");
                filled++;
              }
            }
            return;
          }
        }
        if (!LEGAL_RE.test(label) && AUTO_YES_RE.test(label)) {
          if (setSelectValue(el, "Yes")) {
            highlight(el, "filled");
            filled++;
          }
          return;
        }
      }

      for (const rule of FIELD_RULES) {
        if (!rule.re.test(label)) continue;
        if (rule.subRe && !rule.subRe.test(label)) continue;

        if (rule.key === "SKIP") {
          highlight(el, "review");
          flagged++;
          return;
        }

        // Fill an explicitly configured phone extension/prefix. If none is saved,
        // keep the old safe behavior and clear a stray browser/site default.
        if (rule.key === "phoneExtension") {
          const extension = String(profile.phoneExtension || "").trim();
          if (extension) {
            if (el.tagName === "SELECT") {
              const candidates = [extension, extension.replace(/^\+/, "")].filter(Boolean);
              if (setSelectFromCandidates(el, candidates)) { highlight(el, "filled"); filled++; }
            } else if (el.type !== "checkbox" && el.type !== "radio") {
              setNativeValue(el, extension);
              highlight(el, "filled");
              filled++;
            }
          } else if (el.tagName === "SELECT") {
            const empty = Array.from(el.options).find((o) => !String(o.value || "").trim() || /^(none|n\/?a|not applicable|no extension|--|select)$/i.test((o.text || "").trim()));
            if (empty) {
              el.value = empty.value;
              el.dispatchEvent(new Event("change", { bubbles: true }));
              highlight(el, "filled");
              filled++;
            }
          } else if (el.type !== "checkbox" && el.type !== "radio") {
            setNativeValue(el, "");
            highlight(el, "filled");
            filled++;
          }
          return;
        }

        // "Phone country code" select, paired with a separate national-number
        // field — match by country name (falling back to the dial code).
        if (rule.key === "phoneCountry") {
          if (el.tagName === "SELECT" && setPhoneCountrySelect(el, profile)) {
            highlight(el, "filled");
            filled++;
          }
          return;
        }

        // Phone rule: if the site has a genuine split country-code picker, select the saved phone country and put only national digits in Phone. Otherwise use the full saved international number.
        if (rule.key === "phone" && el.tagName !== "SELECT") {
          const countryControl = findPhoneCountryCodeSelect(el) || findPhoneCountryWidget(el);
          if (countryControl) {
            if (countryControl.tagName === "SELECT") {
              if (setPhoneCountrySelect(countryControl, profile)) highlight(countryControl, "filled");
            } else {
              setCustomPhoneCountryControl(countryControl, profile).then((ok) => {
                if (ok) highlight(countryControl, "filled");
              });
            }
            const local = localPhoneNumber(profile.phone, profile);
            if (local) {
              setNativeValue(el, local);
              highlight(el, "filled");
              filled++;
            }
            return;
          }

          const fullPhone = String(profile.phone || "").replace(/\s+/g, "").trim();
          if (fullPhone) {
            setNativeValue(el, fullPhone);
            highlight(el, "filled");
            filled++;
          }
          return;
        }

        // "What is your current location?" — a plain text field gets the
        // country name; a select may only offer broad region groupings (e.g.
        // "European Union"); a Google Places-style combobox needs the city
        // typed in and the matching "City, Region, Country" suggestion clicked.
        if (rule.key === "currentLocation") {
          if (el.tagName === "SELECT") {
            if (setLocationSelectValue(el, profile)) {
              highlight(el, "filled");
              filled++;
            }
          } else if (el.type !== "checkbox" && el.type !== "radio") {
            if (isAutocompleteCombobox(el)) {
              fillLocationAutocomplete(el, profile).then((ok) => {
                if (ok) highlight(el, "filled");
              });
              highlight(el, "estimate");
              filled++;
            } else {
              const value = profile.locationDisplay || profile.city || profile.country;
              if (value) {
                setNativeValue(el, value);
                highlight(el, "filled");
                filled++;
              }
            }
          }
          return;
        }

        if (rule.key === "dateOfBirth") {
          const dobValue = dateOfBirthForField(el, profile);
          if (!dobValue) return;
          if (el.tagName === "SELECT") {
            if (setSelectValue(el, dobValue)) { highlight(el, "filled"); filled++; }
          } else if (el.type !== "checkbox" && el.type !== "radio") {
            setNativeValue(el, dobValue);
            highlight(el, "filled"); filled++;
          }
          return;
        }
        if (rule.key === "birthMonth") {
          if (setBirthMonthValue(el, profile)) { highlight(el, "filled"); filled++; }
          return;
        }

        const value = profile[rule.key];
        if (!value) return;

        // Address dropdowns vary wildly across ATSs. For City / Province /
        // Country/region fields use the applicant's saved location values and operate
        // real custom listboxes instead of leaving typed-but-unselected text.
        if (["city", "region", "country"].includes(rule.key)) {
          const candidates = profileLocationCandidates(rule.key, profile);
          if (el.tagName === "SELECT") {
            if (setSelectFromCandidates(el, candidates)) {
              highlight(el, "filled");
              filled++;
            }
          } else if (looksLikeCustomCombobox(el)) {
            setCustomComboboxFromCandidates(el, candidates).then((ok) => {
              if (ok) highlight(el, "filled");
              else highlight(el, "estimate");
            });
            highlight(el, "estimate");
            filled++;
          } else if (el.type !== "checkbox" && el.type !== "radio") {
            setNativeValue(el, value);
            highlight(el, "filled");
            filled++;
          }
          return;
        }

        if (rule.key === "availability" && setImmediateDateInput(el)) {
          highlight(el, "filled");
          filled++;
          return;
        }

        if (el.tagName === "SELECT") {
          const matched = rule.salary
            ? setSalarySelectValue(el, value)
            : rule.key === "availability"
            ? setAvailabilitySelectValue(el, value)
            : setSelectValue(el, value);
          if (matched) {
            highlight(el, rule.estimate ? "estimate" : "filled");
            filled++;
          }
        } else if (el.type !== "checkbox" && el.type !== "radio") {
          const matched = rule.salary ? setSalaryInputValue(el, value) : (setNativeValue(el, value), true);
          if (matched) {
            highlight(el, rule.estimate ? "estimate" : "filled");
            filled++;
          }
        }
        return;
      }
    } catch (err) {
      console.error("[Easy Apply] failed to process field", el, err);
    }
  });

  // Closed custom dropdowns can be buttons/divs, so they never enter the
  // input/select loop above. Handle the profile fields users most often see
  // as searchable listboxes: nationality, city, province/region and country.
  Array.from(document.querySelectorAll('[role="combobox"], button[aria-haspopup="listbox"], [role="button"][aria-haspopup="listbox"]'))
    .filter((control) => !(control instanceof HTMLInputElement) && control.tagName !== "SELECT" && isVisibleChoice(control))
    .forEach((control) => {
      try {
        const label = getLabelText(control) || getPrecedingLabelText(control.parentElement || control);
        if (!label || looksLikePhoneCountryControl(control) || isSensitiveNeverStoreField(control, label)) return;
        const kind = demographicKind(label);
        if (kind === "nationality") {
          setCustomComboboxFromCandidates(control, demographicCandidates(kind, profile)).then((ok) => {
            if (ok) highlight(control, "filled");
          });
          return;
        }
        const rule = FIELD_RULES.find((candidate) => ["city", "region", "country"].includes(candidate.key) && candidate.re.test(label));
        if (!rule) return;
        setCustomComboboxFromCandidates(control, profileLocationCandidates(rule.key, profile)).then((ok) => {
          if (ok) highlight(control, "filled");
        });
      } catch (err) {
        console.warn("[Easy Apply] custom location/nationality dropdown failed", err);
      }
    });

  // Generic learned custom dropdowns. This covers ATS components whose closed
  // control is a button/div (or an editable ARIA combobox) and whose option list
  // is rendered in a portal. Previously learned answers could be stored but
  // were only replayed for native <select>s / text inputs.
  Array.from(document.querySelectorAll('[role="combobox"], button[aria-haspopup="listbox"], [role="button"][aria-haspopup="listbox"]'))
    .filter((control) => control.tagName !== "SELECT" && isVisibleChoice(control))
    .forEach((control) => {
      try {
        const label = getLabelText(control) || getPrecedingLabelText(control.parentElement || control);
        if (!label || CONSENT_RE.test(label) || isSensitiveNeverStoreField(control, label)) return;
        const learned = findLearnedAnswer(label, learnedAnswers);
        if (!learned?.answer) return;
        setCustomComboboxFromCandidates(control, [learned.answer]).then((ok) => {
          if (ok) highlight(control, "filled");
        });
      } catch (err) {
        console.warn("[Easy Apply] learned custom dropdown failed", err);
      }
    });

  // Native checkbox answers for voluntary demographic questions. Unlike the
  // old catch-all behavior, this never checks "Decline" when the user's actual
  // answer is available.
  document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
    try {
      const optionText = getLabelText(cb).trim();
      const questionText = getChoiceQuestionText(cb);

      const learnedQuestion = questionText || optionText;
      const learned = findLearnedAnswer(learnedQuestion, learnedAnswers);
      const learnedChoices = learned ? splitConfiguredChoices(learned.answer).map(normalizeChoiceText) : [];
      if (learnedChoices.includes(normalizeChoiceText(optionText))) {
        if (!cb.checked) {
          cb.click();
          highlight(cb, "filled");
          filled++;
        }
        return;
      }

      const kind = demographicKind(questionText) || demographicKind(optionText);
      if (!kind || LEGAL_RE.test(questionText)) return;
      const score = demographicOptionScore(optionText, kind, profile);
      if (score < 0 || cb.checked) return;
      cb.click();
      highlight(cb, "filled");
      filled++;
    } catch (err) {
      console.error("[Easy Apply] failed to process checkbox", cb, err);
    }
  });

  // ARIA checkbox/radio widgets (Ashby and other React ATSs). These controls
  // are often not native <input>s and each option may live in a separate
  // wrapper, so process them by their recovered question text rather than by
  // immediate parent. This also avoids toggling an already-selected checkbox.
  const ariaChoices = Array.from(document.querySelectorAll('[role="checkbox"], [role="radio"]'))
    .filter((el) => !(el instanceof HTMLInputElement));
  ariaChoices.forEach((choice) => {
    try {
      const optionText = customChoiceText(choice);
      const questionText = getChoiceQuestionText(choice);
      if (!optionText || !questionText) return;
      const selected = choice.getAttribute("aria-checked") === "true" || choice.getAttribute("aria-selected") === "true" || choice.getAttribute("data-state") === "checked";

      if (CONSENT_RE.test(questionText)) { highlight(choice, "review"); return; }

      const learned = findLearnedAnswer(questionText, learnedAnswers);
      const learnedChoices = learned ? splitConfiguredChoices(learned.answer).map(normalizeChoiceText) : [];
      if (learnedChoices.includes(normalizeChoiceText(optionText))) {
        if (!selected) { choice.click(); highlight(choice, "filled"); filled++; }
        return;
      }

      if (LEGAL_RE.test(questionText)) {
        const authAnswer = workAuthorizationAnswerForQuestion(questionText, profile);
        if (authAnswer && normalizeChoiceText(authAnswer) === normalizeChoiceText(optionText)) {
          if (!selected) { choice.click(); highlight(choice, "filled"); filled++; }
        } else if (!authAnswer) {
          highlight(choice, "review");
        }
        return;
      }

      const kind = demographicKind(questionText);
      if (!kind) return;
      const score = demographicOptionScore(optionText, kind, profile);
      if (score < 0) return;
      if (!selected) { choice.click(); highlight(choice, "filled"); filled++; }
    } catch (err) {
      console.error("[Easy Apply] failed to process ARIA choice", choice, err);
    }
  });

  function profileChoiceAnswer(question) {
    const text = String(question || "");
    if (/pronouns?|what pronouns/i.test(text)) return profile.pronouns || "";
    if (/gross|net|salary basis|compensation basis|pay basis/i.test(text)) return profile.salaryBasis || "";
    if (/salary period|compensation period|pay period|salary frequency|pay frequency/i.test(text)) return profile.salaryPeriod || "";
    if (/(salary|compensation|pay).{0,50}currency|currency.{0,50}(salary|compensation|pay)/i.test(text)) return profile.salaryCurrency || "";
    return "";
  }

  // Native radio groups: voluntary demographics first, then the existing
  // safe auto-Yes rules for on-site/location questions.
  const radioGroups = new Map();
  document.querySelectorAll('input[type="radio"]').forEach((r) => {
    const key = r.name || r.closest("fieldset") || r.parentElement;
    if (!key) return;
    if (!radioGroups.has(key)) radioGroups.set(key, []);
    radioGroups.get(key).push(r);
  });
  radioGroups.forEach((radios) => {
    try {
      let groupLabel = getChoiceQuestionText(radios[0]);
      if (!groupLabel) groupLabel = getPrecedingLabelText(radios[0].parentElement || radios[0]);
      groupLabel = (groupLabel || "").trim();
      if (!groupLabel) return;

      if (CONSENT_RE.test(groupLabel)) { radios.forEach((r) => highlight(r, "review")); flagged++; return; }

      const profileChoice = profileChoiceAnswer(groupLabel);
      if (profileChoice) {
        const match = matchingChoiceControl(radios, (r) => getLabelText(r).trim(), profileChoice);
        if (match && !match.checked) { match.click(); highlight(match, "filled"); filled++; }
        if (match) return;
      }

      if (NON_COMPETE_RE.test(groupLabel) && profile.nonCompete) {
        const match = matchingChoiceControl(radios, (r) => getLabelText(r).trim(), profile.nonCompete);
        if (match && !match.checked) { match.click(); highlight(match, "filled"); filled++; }
        if (match) return;
      }

      const learned = findLearnedAnswer(groupLabel, learnedAnswers);
      if (learned) {
        const match = matchingChoiceControl(radios, (r) => getLabelText(r).trim(), learned.answer);
        if (match && !match.checked) {
          match.click();
          highlight(match, "filled");
          filled++;
        }
        if (match) return;
      }

      if (LEGAL_RE.test(groupLabel)) {
        const authAnswer = workAuthorizationAnswerForQuestion(groupLabel, profile);
        if (authAnswer) {
          const match = matchingChoiceControl(radios, (r) => getLabelText(r).trim(), authAnswer);
          if (match && !match.checked) {
            match.click();
            highlight(match, "filled");
            filled++;
          }
          if (match) return;
        }
        radios.forEach((r) => highlight(r, "review"));
        flagged++;
        return;
      }

      const kind = demographicKind(groupLabel);
      if (kind) {
        const match = bestDemographicControl(radios, (r) => getLabelText(r).trim(), kind, profile);
        if (match && !match.checked) {
          match.click();
          highlight(match, "filled");
          filled++;
        }
        return;
      }

      if (!AUTO_YES_RE.test(groupLabel)) return;
      const yesRadio = radios.find((r) => /^yes$/i.test(getLabelText(r).trim()));
      if (yesRadio && !yesRadio.checked) {
        yesRadio.click();
        highlight(yesRadio, "filled");
        filled++;
      }
    } catch (err) {
      console.error("[Easy Apply] failed to process radio group", radios, err);
    }
  });

  // Checkbox groups for language proficiency / onsite questions — some ATS forms
  // render these as a list of checkboxes ("No experience", "Native", ...) instead
  // of a select or pill buttons.
  const checkboxGroups = new Map();
  document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
    const parent = cb.parentElement;
    if (!parent) return;
    if (!checkboxGroups.has(parent)) checkboxGroups.set(parent, []);
    checkboxGroups.get(parent).push(cb);
  });
  checkboxGroups.forEach((checkboxes, parent) => {
    try {
      if (checkboxes.length < 2) return;
      const labelText = getPrecedingLabelText(parent);
      if (!labelText) return;

      if (CONSENT_RE.test(labelText)) { checkboxes.forEach((c) => highlight(c, "review")); flagged++; return; }

      if (NON_COMPETE_RE.test(labelText) && profile.nonCompete) {
        const match = matchingChoiceControl(checkboxes, (c) => getLabelText(c).trim(), profile.nonCompete);
        if (match && !match.checked) { match.click(); highlight(match, "filled"); filled++; }
        if (match) return;
      }

      const learned = findLearnedAnswer(labelText, learnedAnswers);
      if (learned) {
        const answers = splitConfiguredChoices(learned.answer);
        let matchedAny = false;
        answers.forEach((answer) => {
          const match = matchingChoiceControl(checkboxes, (c) => getLabelText(c).trim(), answer);
          if (!match) return;
          matchedAny = true;
          if (!match.checked) { match.click(); highlight(match, "filled"); filled++; }
        });
        if (matchedAny) return;
      }

      if (LEGAL_RE.test(labelText) || demographicKind(labelText)) return;

      if (AUTO_YES_RE.test(labelText)) {
        const yes = checkboxes.find((c) => /^yes$/i.test(getLabelText(c).trim()));
        if (yes && !yes.checked) {
          yes.click();
          highlight(yes, "filled");
          filled++;
        }
        return;
      }

      if (LANGUAGE_RE.test(labelText)) {
        const langName = extractLanguageName(labelText);
        const desired = langName && getLanguageValue(profile, langName);
        if (desired) {
          const texts = checkboxes.map((c) => getLabelText(c).trim());
          const idx = closestProficiencyIndex(texts, desired);
          const match =
            idx !== -1
              ? checkboxes[idx]
              : checkboxes.find((c) => getLabelText(c).trim().toLowerCase() === desired.toLowerCase());
          if (match && !match.checked) {
            match.click();
            highlight(match, "filled");
            filled++;
          }
        }
      }
    } catch (err) {
      console.error("[Easy Apply] failed to process checkbox group", parent, err);
    }
  });

  // Custom pill/button choice groups (common on Greenhouse/Ashby/Lever).
  const clickable = Array.from(document.querySelectorAll('button, [role="radio"], [role="checkbox"], [role="option"], [role="button"]'));
  const groups = new Map();
  clickable.forEach((btn) => {
    const parent = btn.parentElement;
    if (!parent) return;
    if (!groups.has(parent)) groups.set(parent, []);
    groups.get(parent).push(btn);
  });

  groups.forEach((buttons, parent) => {
    try {
      if (buttons.length < 2) return;
      const labelText = getPrecedingLabelText(parent);
      if (!labelText) return;

      if (CONSENT_RE.test(labelText)) { buttons.forEach((b) => highlight(b, "review")); flagged++; return; }

      const profileChoice = profileChoiceAnswer(labelText);
      if (profileChoice) {
        const match = matchingChoiceControl(buttons, (b) => (b.innerText || b.textContent || "").trim(), profileChoice);
        if (match) {
          const wasSelected = isControlSelected(match);
          if (clickChoiceIfNeeded(match) && !wasSelected) { highlight(match, "filled"); filled++; }
          return;
        }
      }

      if (NON_COMPETE_RE.test(labelText) && profile.nonCompete) {
        const match = matchingChoiceControl(buttons, (b) => (b.innerText || b.textContent || "").trim(), profile.nonCompete);
        if (match) { match.click(); highlight(match, "filled"); filled++; return; }
      }

      const learned = findLearnedAnswer(labelText, learnedAnswers);
      if (learned) {
        const isMultiWidget = buttons.some((b) => b.getAttribute?.("role") === "checkbox");
        const answers = isMultiWidget ? splitConfiguredChoices(learned.answer) : [learned.answer];
        let matchedAny = false;
        answers.forEach((answer) => {
          const match = matchingChoiceControl(buttons, (b) => (b.innerText || b.textContent || "").trim(), answer);
          if (!match) return;
          matchedAny = true;
          const wasSelected = isControlSelected(match);
          if (clickChoiceIfNeeded(match) && !wasSelected) { highlight(match, "filled"); filled++; }
        });
        if (matchedAny) return;
      }

      if (LEGAL_RE.test(labelText)) {
        const authAnswer = workAuthorizationAnswerForQuestion(labelText, profile);
        if (authAnswer) {
          const match = matchingChoiceControl(buttons, (b) => (b.innerText || b.textContent || "").trim(), authAnswer);
          if (match) {
            match.click();
            highlight(match, "filled");
            filled++;
            return;
          }
        }
        buttons.forEach((b) => highlight(b, "review"));
        flagged++;
        return;
      }

      const kind = demographicKind(labelText);
      if (kind) {
        const isMultiWidget = buttons.some((b) => b.getAttribute?.("role") === "checkbox");
        if (isMultiWidget) {
          buttons.forEach((button) => {
            const score = demographicOptionScore((button.innerText || button.textContent || "").trim(), kind, profile);
            if (score < 0) return;
            const wasSelected = isControlSelected(button);
            if (clickChoiceIfNeeded(button) && !wasSelected) { highlight(button, "filled"); filled++; }
          });
        } else {
          const match = bestDemographicControl(
            buttons,
            (b) => (b.innerText || b.textContent || "").trim(),
            kind,
            profile
          );
          if (match) {
            const wasSelected = isControlSelected(match);
            if (clickChoiceIfNeeded(match) && !wasSelected) { highlight(match, "filled"); filled++; }
          }
        }
        return;
      }

      if (AUTO_YES_RE.test(labelText)) {
        const yes = buttons.find((b) => /^yes$/i.test((b.innerText || b.textContent || "").trim()));
        if (yes) {
          yes.click();
          highlight(yes, "filled");
          filled++;
        }
        return;
      }

      if (LANGUAGE_RE.test(labelText)) {
        const langName = extractLanguageName(labelText);
        const desired = langName && getLanguageValue(profile, langName);
        if (desired) {
          const texts = buttons.map((b) => (b.innerText || b.textContent || "").trim());
          const idx = closestProficiencyIndex(texts, desired);
          const match =
            idx !== -1
              ? buttons[idx]
              : buttons.find((b) => (b.innerText || b.textContent || "").trim().toLowerCase() === desired.toLowerCase());
          if (match) {
            match.click();
            highlight(match, "filled");
            filled++;
          }
        }
      }
    } catch (err) {
      console.error("[Easy Apply] failed to process choice group", parent, err);
    }
  });

  // File upload fields (Resume/CV, Cover Letter, Portfolio, or an ambiguous
  // "other files" field). A stored matching document is attached immediately.
  // Ambiguous upload areas get a small explicit picker chip for each candidate.
  deepQuerySelectorAll('input[type="file"]').forEach((el) => {
    try {
      const label = uploadContextText(el);
      const matched = fileRuleForElement(el);
      const candidates = matched ? [matched] : FILE_RULES; // ambiguous field -> offer all three

      // Always re-check stored files before honoring the helper marker. This
      // matters when the user picks a CV from the extension popup after this
      // page already rendered a helper chip.
      if (matched) {
        const fileName = profile[`${matched.key}FileName`];
        const dataUrl = profile[`${matched.key}FileDataUrl`];
        if (fileName && dataUrl) {
          if (attachFileToInput(el, dataUrl, fileName)) {
            const oldHelper = el.nextElementSibling;
            if (oldHelper?.classList?.contains("zt-file-helper-wrap")) oldHelper.remove();
            el.dataset.ztHelperAdded = "1";
            highlight(el, "filled");
            filled++;
            return;
          }
        }
      }

      if (el.dataset.ztHelperAdded) return;
      const wrap = document.createElement("div");
      wrap.className = "zt-file-helper-wrap";
      wrap.style.cssText = "margin-top:4px; display:flex; gap:6px; flex-wrap:wrap;";

      candidates.forEach((rule) => {
        const fileName = profile[`${rule.key}FileName`];
        const dataUrl = profile[`${rule.key}FileDataUrl`];
        const filePath = profile[`${rule.key}FilePath`];
        if (!fileName || (!dataUrl && !filePath)) return;
        const chip = document.createElement("span");
        chip.textContent = `📎 ${fileName}`;
        Object.assign(chip.style, {
          display: "inline-block",
          background: "#eef7ff",
          border: "1px solid #3498db",
          color: "#2166a3",
          borderRadius: "4px",
          padding: "3px 8px",
          fontSize: "12px",
          cursor: "pointer",
        });

        if (dataUrl) {
          chip.title = `Click to attach ${fileName} directly`;
          chip.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            const ok = attachFileToInput(el, dataUrl, fileName);
            if (ok) highlight(el, "filled");
            const original = chip.textContent;
            chip.textContent = ok ? "✓ Attached" : "Could not attach — retry";
            setTimeout(() => (chip.textContent = original), 2500);
          });
        } else {
          chip.title = `Click to copy the file path and open the picker:\n${filePath}`;
          chip.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            navigator.clipboard.writeText(filePath).catch(() => {});
            const original = chip.textContent;
            chip.textContent = "Path copied — opening picker…";
            el.click();
            setTimeout(() => (chip.textContent = original), 2500);
          });
        }

        wrap.appendChild(chip);
      });

      if (wrap.childNodes.length) {
        el.insertAdjacentElement("afterend", wrap);
        el.dataset.ztHelperAdded = "1";
        highlight(el, "estimate");
        fileHelpers++;
      }
    } catch (err) {
      console.error("[Easy Apply] failed to process file field", el, err);
    }
  });

  isExtensionApplyingAnswers = false;
  const unanswered = collectUnansweredFields(true);
  return { filled, flagged, fileHelpers, unanswered };
}

function runFill(showBadgeResult) {
  chrome.storage.local.get(["profile", "learnedAnswers"], ({ profile, learnedAnswers }) => {
    if (!profile) {
      if (showBadgeResult) showBadgeResult("Set up your profile first (extension options).");
      return;
    }
    try {
      const data = normalizeProfile(profile);
      const result = fillForm(data, learnedAnswers);
      const uploads = ["cv", "coverLetter", "portfolio"]
        .map((key) => attachStoredFileByKey(data, key))
        .reduce((acc, item) => ({ attached: acc.attached + Number(item.attached || 0), dropped: acc.dropped + Number(item.dropped || 0) }), { attached: 0, dropped: 0 });
      if (showBadgeResult) {
        showBadgeResult(
          `${result.filled} filled, ${result.unanswered?.length || 0} unanswered (red), ${uploads.attached || uploads.dropped ? `${uploads.attached} file input(s) attached / ${uploads.dropped} drop event(s)` : `${result.fileHelpers} upload helper(s) shown`}`
        );
      }
    } catch (err) {
      console.error("[Easy Apply] fillForm crashed", err);
      if (showBadgeResult) showBadgeResult("Something went wrong — check the console for details.");
    }
  });
}

// --- Shadow DOM host: isolates our injected FAB/panel from the page's own
// CSS. Without this, a site's global rules (e.g. "input[type=checkbox] {
// display: none }" — extremely common once a site builds its own custom
// checkboxes elsewhere) can silently break or hide our controls, since a
// plain injected <div> shares the same style-resolution tree as the page. ---
let shadowHost = null;
let shadowRoot = null;

function ensureShadowRoot() {
  const parent = document.body || document.documentElement;
  if (shadowRoot && shadowHost) {
    // SPAs sometimes replace <body> wholesale. The old shadow host then stays
    // alive but detached, making the assistant appear to have vanished. Reuse
    // the same host/root and simply mount it back into the new document body.
    if (!shadowHost.isConnected && parent) parent.appendChild(shadowHost);
    return shadowRoot;
  }
  if (!parent) return null;
  shadowHost = document.createElement("div");
  shadowHost.id = "zt-shadow-host";
  // Inline !important keeps aggressive site-wide CSS from hiding the host.
  shadowHost.style.setProperty("all", "initial", "important");
  shadowHost.style.setProperty("display", "contents", "important");
  shadowHost.style.setProperty("visibility", "visible", "important");
  shadowHost.style.setProperty("opacity", "1", "important");
  parent.appendChild(shadowHost);
  shadowRoot = shadowHost.attachShadow({ mode: "open" });
  return shadowRoot;
}

// --- Floating badge: a single fixed-size circular FAB pinned to the
// top-left corner. Click opens the panel; a brief pulse ring signals when an
// automatic fill just happened, and the result text is a native tooltip
// (title) rather than an expanding pill, since that fought with some sites'
// own layout/animations. ---
let badgeEl = null;
let badgeIconEl = null;
let badgeState = { paused: false, noProfile: false, hasForm: false };
const BADGE_DEFAULT_TITLE = "Application form detected — click to open, drag to move";
const BADGE_NO_FORM_TITLE = "No application form detected yet — drag to move";
const BADGE_NO_PROFILE_TITLE = "Profile setup needed — click to open Settings, drag to move";
const BADGE_PAUSED_TITLE = "Auto-fill paused — click to open, drag to move";
let badgeBaseTitle = BADGE_DEFAULT_TITLE;

const BADGE_SVG = {
  paused: `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="5" width="3.5" height="14" rx="1.75" fill="currentColor"/><rect x="13.5" y="5" width="3.5" height="14" rx="1.75" fill="currentColor"/></svg>`,
  idle: `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="5.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M14.8 14.8 20 20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>`,
  warning: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.8 21 19.5H3L12 3.8Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 9v4.6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="16.9" r="1" fill="currentColor"/></svg>`,
};

// Reflects the current state on the FAB itself, so it's visible at a glance
// even when there is no application form on the page:
//   - red + warning: no profile saved yet.
//   - gray + pause: auto-fill-on-detect is off.
//   - slate + search: extension is active, but no form is currently detected.
//   - green + avatar: a likely application form is present and ready.
// Kept in sync via storage.onChanged below, since state can also change from
// the panel, the popup, or the Settings page.
function updateBadgeVisualState(nextState = {}) {
  badgeState = { ...badgeState, ...nextState };
  if (!badgeEl || !badgeIconEl) return;

  const { paused, noProfile, hasForm } = badgeState;
  badgeEl.classList.toggle("zt-paused", !!paused);
  badgeEl.classList.toggle("zt-noprofile", !!noProfile);
  badgeEl.classList.toggle("zt-noform", !hasForm && !paused && !noProfile);

  if (noProfile) {
    badgeIconEl.innerHTML = BADGE_SVG.warning;
    badgeBaseTitle = BADGE_NO_PROFILE_TITLE;
  } else if (paused) {
    badgeIconEl.innerHTML = BADGE_SVG.paused;
    badgeBaseTitle = BADGE_PAUSED_TITLE;
  } else if (!hasForm) {
    badgeIconEl.innerHTML = BADGE_SVG.idle;
    badgeBaseTitle = BADGE_NO_FORM_TITLE;
  } else {
    badgeIconEl.innerHTML = `<img src="${chrome.runtime.getURL("icons/avatar.png")}" alt="" />`;
    badgeBaseTitle = BADGE_DEFAULT_TITLE;
  }

  badgeEl.title = uiT(badgeBaseTitle);

  if (typeof panelModeEl !== "undefined" && panelModeEl) {
    let text = "Ready — form detected";
    let mode = "ready";
    if (noProfile) { text = "Profile setup needed"; mode = "warning"; }
    else if (paused) { text = "Auto-fill paused"; mode = "paused"; }
    else if (!hasForm) { text = "Waiting for a form"; mode = "idle"; }
    panelModeEl.textContent = uiT(text);
    panelModeEl.dataset.mode = mode;
  }
}

function refreshBadgeVisualState() {
  chrome.storage.local.get("profile", ({ profile }) => {
    updateBadgeVisualState({
      paused: !!profile && profile.autoFillOnDetect === false,
      noProfile: !profile,
    });
  });
}

function ensureBadgeStyle() {
  const root = ensureShadowRoot();
  if (!root) return;
  if (root.getElementById("zt-fab-style")) return;
  const style = document.createElement("style");
  style.id = "zt-fab-style";
  style.textContent = `
    .zt-fab {
      position: fixed;
      top: 20px;
      left: 20px;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
      width: 54px;
      height: 54px;
      border-radius: 17px;
      border: 1px solid rgba(255, 255, 255, 0.78);
      background: linear-gradient(145deg, #34d399 0%, #16a34a 100%);
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      cursor: pointer;
      overflow: visible;
      box-shadow:
        0 12px 28px rgba(15, 23, 42, 0.20),
        0 3px 8px rgba(15, 23, 42, 0.12),
        inset 0 1px 0 rgba(255, 255, 255, 0.30);
      transition: transform 160ms ease, box-shadow 200ms ease, background 200ms ease, border-color 200ms ease;
      -webkit-font-smoothing: antialiased;
    }
    .zt-fab::after {
      content: "";
      position: absolute;
      right: -3px;
      bottom: -3px;
      width: 13px;
      height: 13px;
      border-radius: 50%;
      box-sizing: border-box;
      border: 3px solid #fff;
      background: #22c55e;
      box-shadow: 0 2px 6px rgba(15, 23, 42, 0.18);
      transition: background 180ms ease;
    }
    .zt-fab:hover {
      transform: translateY(-2px);
      box-shadow:
        0 16px 34px rgba(15, 23, 42, 0.24),
        0 4px 10px rgba(15, 23, 42, 0.12),
        inset 0 1px 0 rgba(255, 255, 255, 0.35);
    }
    .zt-fab:active { transform: translateY(0) scale(0.95); }
    .zt-fab.zt-dragging, .zt-fab.zt-dragging:hover, .zt-fab.zt-dragging:active {
      transform: none;
      cursor: grabbing;
      transition: box-shadow 100ms ease, background 200ms ease, border-color 200ms ease;
      user-select: none;
      touch-action: none;
    }

    .zt-fab.zt-noform {
      color: #475569;
      background: linear-gradient(145deg, #f8fafc 0%, #e2e8f0 100%);
      border-color: rgba(148, 163, 184, 0.35);
    }
    .zt-fab.zt-noform::after { background: #94a3b8; }

    .zt-fab.zt-paused {
      color: #fff;
      background: linear-gradient(145deg, #64748b 0%, #334155 100%);
      border-color: rgba(255, 255, 255, 0.40);
    }
    .zt-fab.zt-paused::after { background: #f59e0b; }

    /* Nothing saved in Settings yet — most urgent state, wins over paused/active. */
    .zt-fab.zt-noprofile {
      color: #fff;
      background: linear-gradient(145deg, #fb7185 0%, #dc2626 100%);
      border-color: rgba(255, 255, 255, 0.55);
    }
    .zt-fab.zt-noprofile::after { background: #ef4444; }

    .zt-fab.zt-pulse { animation: zt-fab-pulse 850ms ease-out; }
    @keyframes zt-fab-pulse {
      0% { box-shadow: 0 12px 28px rgba(15, 23, 42, 0.20), 0 0 0 0 rgba(34, 197, 94, 0.35); }
      50% { box-shadow: 0 12px 28px rgba(15, 23, 42, 0.20), 0 0 0 10px rgba(34, 197, 94, 0.14); }
      100% { box-shadow: 0 12px 28px rgba(15, 23, 42, 0.20), 0 0 0 0 rgba(34, 197, 94, 0); }
    }

    .zt-fab-icon {
      width: 46px;
      height: 46px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      pointer-events: none;
    }
    .zt-fab-icon img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 14px;
      display: block;
    }
    .zt-fab-icon svg { width: 23px; height: 23px; display: block; }

    .zt-fab-close {
      position: absolute;
      top: -6px;
      right: -6px;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: #fff;
      color: #64748b;
      border: 1px solid rgba(15, 23, 42, 0.12);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      line-height: 1;
      padding: 0;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(15, 23, 42, 0.2);
      opacity: 0;
      transform: scale(0.8);
      transition: opacity 150ms ease, transform 150ms ease, background 150ms ease, color 150ms ease;
      z-index: 1;
      font-family: inherit;
    }
    .zt-fab:hover .zt-fab-close { opacity: 1; transform: scale(1); }
    .zt-fab-close:hover { background: #ef4444; color: #fff; border-color: transparent; }
  `;
  shadowRoot.appendChild(style);
}

// The in-page assistant is one movable unit: the FAB is the anchor and the
// panel follows it. Position is saved locally so the assistant reappears in
// the same place on the next application page. The panel header can also be
// used as a drag handle; dragging either element moves both together.
const FLOATING_POSITION_KEY = "floatingAssistantPosition";
const FLOATING_EDGE_GAP = 10;
const FAB_SIZE = 54;
const PANEL_GAP = 12;
let floatingPosition = { x: 20, y: 20 };
let floatingPositionLoaded = false;
let dragSession = null;
let suppressBadgeClickUntil = 0;
let positionSaveTimer = null;

function clampNumber(value, min, max) {
  return Math.min(Math.max(value, min), Math.max(min, max));
}

function clampFloatingPosition(position) {
  return {
    x: clampNumber(Number(position?.x) || 20, FLOATING_EDGE_GAP, window.innerWidth - FAB_SIZE - FLOATING_EDGE_GAP),
    y: clampNumber(Number(position?.y) || 20, FLOATING_EDGE_GAP, window.innerHeight - FAB_SIZE - FLOATING_EDGE_GAP),
  };
}

function syncPanelToBadge() {
  if (!panelEl || !badgeEl) return;
  const panelWidth = Math.min(324, Math.max(220, window.innerWidth - FLOATING_EDGE_GAP * 2));
  const actualPanelHeight = panelEl.classList.contains("zt-panel-open") ? panelEl.getBoundingClientRect().height : 0;
  const estimatedHeight = actualPanelHeight || Math.min(520, Math.max(260, window.innerHeight - 40));

  let left = clampNumber(floatingPosition.x, FLOATING_EDGE_GAP, window.innerWidth - panelWidth - FLOATING_EDGE_GAP);
  let top = floatingPosition.y + FAB_SIZE + PANEL_GAP;
  if (top + estimatedHeight > window.innerHeight - FLOATING_EDGE_GAP) {
    top = floatingPosition.y - estimatedHeight - PANEL_GAP;
  }
  top = clampNumber(top, FLOATING_EDGE_GAP, window.innerHeight - Math.min(estimatedHeight, window.innerHeight - FLOATING_EDGE_GAP * 2) - FLOATING_EDGE_GAP);

  panelEl.style.left = `${Math.round(left)}px`;
  panelEl.style.top = `${Math.round(top)}px`;
}

function applyFloatingPosition(position, { save = false } = {}) {
  floatingPosition = clampFloatingPosition(position);
  if (badgeEl) {
    badgeEl.style.left = `${Math.round(floatingPosition.x)}px`;
    badgeEl.style.top = `${Math.round(floatingPosition.y)}px`;
  }
  syncPanelToBadge();

  if (save) {
    clearTimeout(positionSaveTimer);
    positionSaveTimer = setTimeout(() => {
      chrome.storage.local.set({ [FLOATING_POSITION_KEY]: floatingPosition });
    }, 120);
  }
}

function loadFloatingPosition() {
  if (floatingPositionLoaded) {
    applyFloatingPosition(floatingPosition);
    return;
  }
  floatingPositionLoaded = true;
  chrome.storage.local.get(FLOATING_POSITION_KEY, (result) => {
    const saved = result?.[FLOATING_POSITION_KEY];
    applyFloatingPosition(saved && typeof saved === "object" ? saved : floatingPosition);
  });
}

function beginAssistantDrag(e, source) {
  if (e.button !== undefined && e.button !== 0) return;
  if (source === "fab" && e.target?.closest?.(".zt-fab-close")) return;
  if (source === "panel" && e.target?.closest?.("button, input, select, textarea, label, a, .zt-panel-mode")) return;

  dragSession = {
    pointerId: e.pointerId,
    startX: e.clientX,
    startY: e.clientY,
    originX: floatingPosition.x,
    originY: floatingPosition.y,
    moved: false,
    source,
  };
  if (source === "fab") badgeEl?.classList.add("zt-dragging");
  if (source === "panel") panelEl?.classList.add("zt-panel-dragging");
  try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_err) {}
  e.preventDefault();
}

function continueAssistantDrag(e) {
  if (!dragSession || e.pointerId !== dragSession.pointerId) return;
  const dx = e.clientX - dragSession.startX;
  const dy = e.clientY - dragSession.startY;
  if (!dragSession.moved && Math.hypot(dx, dy) >= 4) dragSession.moved = true;
  if (!dragSession.moved) return;
  applyFloatingPosition({ x: dragSession.originX + dx, y: dragSession.originY + dy });
  e.preventDefault();
}

function endAssistantDrag(e) {
  if (!dragSession || (e.pointerId !== undefined && e.pointerId !== dragSession.pointerId)) return;
  const moved = dragSession.moved;
  dragSession = null;
  badgeEl?.classList.remove("zt-dragging");
  panelEl?.classList.remove("zt-panel-dragging");
  if (moved) {
    suppressBadgeClickUntil = Date.now() + 350;
    applyFloatingPosition(floatingPosition, { save: true });
  }
}

function makeAssistantDraggable(handle, source) {
  if (!handle || handle.dataset.ztDragReady === "1") return;
  handle.dataset.ztDragReady = "1";
  handle.addEventListener("pointerdown", (e) => beginAssistantDrag(e, source));
  handle.addEventListener("pointermove", continueAssistantDrag);
  handle.addEventListener("pointerup", endAssistantDrag);
  handle.addEventListener("pointercancel", endAssistantDrag);
}

function openSettingsTab() {
  window.open(chrome.runtime.getURL("options.html"), "_blank");
}

function openSavedAnswersTab() {
  window.open(chrome.runtime.getURL("options.html#saved-answers"), "_blank");
}

window.addEventListener("resize", () => applyFloatingPosition(floatingPosition));

// Hides the FAB entirely (no gray/idle icon left sitting on the page) —
// used when there's nothing to do here: no form detected, or auto-fill is
// paused. Leaves an already-open panel alone rather than yanking it away
// mid-interaction (e.g. the user just flipped the toggle inside it).
function hideBadge() {
  if (panelEl && panelEl.classList.contains("zt-panel-open")) return;
  if (badgeEl) badgeEl.style.display = "none";
}

function showBadge() {
  const root = ensureShadowRoot();
  if (!root) return;
  if (badgeEl) {
    badgeEl.style.display = "";
    return;
  }
  ensureBadgeStyle();

  badgeEl = document.createElement("div");
  badgeEl.className = "zt-fab";
  badgeEl.title = BADGE_DEFAULT_TITLE;

  badgeIconEl = document.createElement("span");
  badgeIconEl.className = "zt-fab-icon";
  updateBadgeVisualState({ paused: false, noProfile: false });

  // Small "x" revealed on hover — one click pauses automatic filling. The
  // assistant itself stays reachable so auto-fill can be resumed from the page.
  const closeBtn = document.createElement("button");
  closeBtn.type = "button";
  closeBtn.className = "zt-fab-close";
  closeBtn.title = "Pause auto-fill";
  closeBtn.textContent = "✕";
  closeBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    chrome.storage.local.get("profile", ({ profile }) => {
      chrome.storage.local.set({ profile: { ...(profile || {}), autoFillOnDetect: false } });
    });
  });

  badgeEl.appendChild(badgeIconEl);
  badgeEl.appendChild(closeBtn);
  badgeEl.addEventListener("click", () => {
    if (Date.now() < suppressBadgeClickUntil) return;
    if (badgeState.noProfile) {
      openSettingsTab();
      return;
    }
    togglePanel();
  });
  shadowRoot.appendChild(badgeEl);
  makeAssistantDraggable(badgeEl, "fab");
  loadFloatingPosition();

  refreshBadgeVisualState();
}

function showBadgeMessage(msg) {
  if (!badgeEl) return;
  badgeEl.title = msg;
  badgeEl.classList.remove("zt-pulse");
  // Force a reflow so re-adding the class restarts the animation even if a
  // previous pulse (e.g. from a fast-mutating page) hasn't finished yet.
  void badgeEl.offsetWidth;
  badgeEl.classList.add("zt-pulse");
  setTimeout(() => {
    if (!badgeEl) return;
    badgeEl.title = uiT(badgeBaseTitle);
  }, 4000);
}

// --- In-page panel: clicking the 📋 FAB opens this instead of filling
// directly — a small clone of the popup (Fill button, auto-fill toggle,
// color legend) anchored on the page itself. Automatic fills (via
// checkAndFill) still just show their result on the FAB pill above. ---
let panelEl = null;
let panelStatusEl = null;
let panelToggleEl = null;
let panelLearnToggleEl = null;
let panelLearnDescEl = null;
let panelModeEl = null;
let panelMissingListEl = null;
let panelMissingCountEl = null;

function ensurePanelStyle() {
  const root = ensureShadowRoot();
  if (!root) return;
  if (root.getElementById("zt-panel-style")) return;
  const style = document.createElement("style");
  style.id = "zt-panel-style";
  style.textContent = `
    .zt-panel {
      position: fixed;
      top: 86px;
      left: 20px;
      z-index: 2147483647;
      width: 324px;
      max-width: calc(100vw - 40px);
      background: rgba(255, 255, 255, 0.98);
      border: 1px solid rgba(226, 232, 240, 0.95);
      border-radius: 22px;
      box-shadow: 0 26px 70px rgba(15, 23, 42, 0.23), 0 8px 24px rgba(15, 23, 42, 0.10);
      overflow: hidden;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      color: #0f172a;
      display: none;
      -webkit-font-smoothing: antialiased;
    }
    .zt-panel.zt-panel-open {
      display: block;
      transform-origin: 24px 0;
      animation: zt-panel-in 210ms cubic-bezier(0.2, 0.9, 0.25, 1.08);
    }
    @keyframes zt-panel-in {
      from { opacity: 0; transform: translateY(-8px) scale(0.965); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }

    .zt-panel-hero {
      position: relative;
      padding: 18px 18px 16px;
      cursor: grab;
      touch-action: none;
      user-select: none;
      color: #fff;
      background:
        radial-gradient(circle at 92% 4%, rgba(167, 243, 208, 0.38), transparent 31%),
        radial-gradient(circle at 8% 108%, rgba(52, 211, 153, 0.28), transparent 38%),
        linear-gradient(140deg, #064e3b 0%, #047857 46%, #16a34a 100%);
      overflow: hidden;
    }
    .zt-panel.zt-panel-dragging .zt-panel-hero { cursor: grabbing; }
    .zt-panel.zt-panel-dragging { animation: none !important; }
    .zt-panel-hero button, .zt-panel-hero .zt-panel-mode { user-select: auto; }

    .zt-panel-hero::after {
      content: "";
      position: absolute;
      width: 150px;
      height: 150px;
      border-radius: 50%;
      right: -92px;
      bottom: -108px;
      border: 1px solid rgba(255, 255, 255, 0.14);
      box-shadow: 0 0 0 22px rgba(255, 255, 255, 0.035), 0 0 0 46px rgba(255, 255, 255, 0.025);
      pointer-events: none;
    }
    .zt-panel-hero-top {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 12px;
      position: relative;
      z-index: 1;
    }
    .zt-panel-brand { display: flex; align-items: center; gap: 11px; min-width: 0; }
    .zt-panel-logo {
      flex-shrink: 0;
      width: 39px;
      height: 39px;
      border-radius: 13px;
      overflow: hidden;
      box-sizing: border-box;
      background: rgba(255, 255, 255, 0.14);
      border: 1px solid rgba(255, 255, 255, 0.52);
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 5px 14px rgba(6, 78, 59, 0.25);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .zt-panel-logo img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .zt-panel-title { font-size: 14px; font-weight: 760; letter-spacing: -0.15px; color: #fff; line-height: 1.25; margin: 0; }
    .zt-panel-subtitle { font-size: 10.5px; color: rgba(236, 253, 245, 0.76); margin-top: 3px; line-height: 1.35; }
    .zt-panel-gear {
      flex-shrink: 0;
      width: 32px;
      height: 32px;
      border-radius: 10px;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.22);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      color: #fff;
      padding: 0;
      transition: transform 180ms ease, background 180ms ease, border-color 180ms ease;
    }
    .zt-panel-gear:hover { background: rgba(255, 255, 255, 0.18); border-color: rgba(255, 255, 255, 0.34); transform: rotate(35deg); }
    .zt-panel-gear:active { transform: rotate(35deg) scale(0.94); }
    .zt-panel-gear svg { width: 15px; height: 15px; display: block; }
    .zt-panel-head-actions { display:flex; align-items:center; gap:6px; position:relative; z-index:2; }
    .zt-panel-lang { height:32px; min-width:53px; border-radius:9px; border:1px solid rgba(255,255,255,.24); background:rgba(255,255,255,.10); color:#fff; font-size:10.5px; font-weight:750; padding:0 5px; outline:none; }
    .zt-panel-lang option { color:#0f172a; background:#fff; }

    .zt-panel-mode {
      position: relative;
      z-index: 1;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-top: 14px;
      padding: 5px 8px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.16);
      color: rgba(255, 255, 255, 0.92);
      font-size: 10px;
      font-weight: 650;
      letter-spacing: 0.01em;
    }
    .zt-panel-mode::before {
      content: "";
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #86efac;
      box-shadow: 0 0 0 3px rgba(134, 239, 172, 0.12);
    }
    .zt-panel-mode[data-mode="idle"]::before { background: #cbd5e1; box-shadow: 0 0 0 3px rgba(203, 213, 225, 0.12); }
    .zt-panel-mode[data-mode="paused"]::before { background: #fbbf24; box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.12); }
    .zt-panel-mode[data-mode="warning"]::before { background: #fb7185; box-shadow: 0 0 0 3px rgba(251, 113, 133, 0.12); }
    .zt-panel-mode[data-mode="warning"] { cursor: pointer; background: rgba(254, 226, 226, 0.17); border-color: rgba(254, 202, 202, 0.32); }
    .zt-panel-mode[data-mode="warning"]:hover { background: rgba(254, 226, 226, 0.25); }

    .zt-panel-body {
      padding: 16px;
      background: linear-gradient(#fff, #fbfdff);
      max-height: min(650px, calc(100vh - 170px));
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 transparent;
    }
    .zt-panel-fillbtn {
      width: 100%;
      padding: 12px 14px;
      font-size: 13.5px;
      font-weight: 720;
      cursor: pointer;
      border-radius: 13px;
      border: 1px solid rgba(22, 163, 74, 0.18);
      color: #fff;
      background: linear-gradient(135deg, #22c55e 0%, #15803d 100%);
      box-shadow: 0 9px 20px rgba(22, 163, 74, 0.24), inset 0 1px 0 rgba(255, 255, 255, 0.22);
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-family: inherit;
      transition: filter 140ms ease, transform 140ms ease, box-shadow 160ms ease;
    }
    .zt-panel-fillbtn:hover { filter: brightness(1.035); transform: translateY(-1px); box-shadow: 0 11px 24px rgba(22, 163, 74, 0.30); }
    .zt-panel-fillbtn:active { transform: translateY(0) scale(0.985); }

    .zt-panel-secondarybtn {
      width: 100%;
      margin-top: 9px;
      padding: 10px 12px;
      font-size: 11.8px;
      font-weight: 700;
      cursor: pointer;
      border-radius: 11px;
      border: 1px solid #bfdbfe;
      color: #1d4ed8;
      background: #eff6ff;
      font-family: inherit;
      transition: background 140ms ease, transform 140ms ease;
    }
    .zt-panel-secondarybtn:hover { background: #dbeafe; }
    .zt-panel-secondarybtn:active { transform: scale(0.985); }

    .zt-panel-docs {
      margin-top: 12px;
      padding: 11px;
      border: 1px solid #e2e8f0;
      border-radius: 13px;
      background: #f8fafc;
    }
    .zt-panel-doc-title { font-size: 11.5px; font-weight: 720; color: #1e293b; }
    .zt-panel-doc-sub { margin-top: 3px; font-size: 9.5px; line-height: 1.35; color: #64748b; }
    .zt-panel-doc-row { display: grid; grid-template-columns: 82px 1fr; gap: 6px 8px; align-items: center; margin-top: 9px; }
    .zt-panel-doc-label { font-size: 10.2px; font-weight: 650; color: #334155; }
    .zt-panel-doc-pick {
      border: 1px solid #cbd5e1; border-radius: 8px; background: #fff; color: #334155;
      padding: 6px 8px; font-size: 10px; font-weight: 620; cursor: pointer; font-family: inherit; text-align: left;
    }
    .zt-panel-doc-pick:hover { border-color: #93c5fd; background: #eff6ff; }
    .zt-panel-doc-status { grid-column: 2; min-width: 0; font-size: 9px; color: #16a34a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .zt-panel-doc-status.zt-empty { color: #94a3b8; }

    .zt-panel-missing { margin-top: 12px; border: 1px solid #fecaca; border-radius: 13px; overflow: hidden; background: #fff; }
    .zt-panel-missing-head { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:9px 10px; background:#fff7f7; border-bottom:1px solid #fee2e2; }
    .zt-panel-missing-title { font-size:10.5px; font-weight:720; color:#991b1b; }
    .zt-panel-missing-count { min-width:22px; text-align:center; font-size:9px; font-weight:760; color:#fff; background:#ef4444; border-radius:999px; padding:2px 6px; }
    .zt-panel-missing-list { max-height:140px; overflow-y:auto; }
    .zt-panel-missing-item { width:100%; border:0; border-bottom:1px solid #fee2e2; background:#fff; padding:8px 9px; text-align:left; cursor:pointer; display:block; font-family:inherit; }
    .zt-panel-missing-item:last-child { border-bottom:0; }
    .zt-panel-missing-item:hover { background:#fff1f2; }
    .zt-panel-missing-label { display:block; font-size:9.8px; font-weight:650; color:#7f1d1d; line-height:1.3; }
    .zt-panel-missing-meta { display:block; margin-top:2px; font-size:8.7px; color:#b45309; }
    .zt-panel-missing-empty { padding:9px 10px; font-size:9.8px; color:#15803d; background:#f0fdf4; }

    .zt-panel-toggle-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-top: 12px;
      padding: 11px 12px;
      background: #f8fafc;
      border: 1px solid #e8edf3;
      border-radius: 13px;
    }
    .zt-panel-toggle-title { font-size: 12px; font-weight: 680; color: #0f172a; }
    .zt-panel-toggle-desc { font-size: 9.8px; color: #64748b; margin-top: 2px; line-height: 1.35; }
    .zt-panel-switch { position: relative; display: inline-block; width: 38px; height: 22px; flex-shrink: 0; }
    .zt-panel-switch input { opacity: 0; width: 0; height: 0; }
    .zt-panel-slider { position: absolute; inset: 0; cursor: pointer; background: #cbd5e1; border-radius: 999px; transition: background 160ms ease, box-shadow 160ms ease; }
    .zt-panel-slider::before {
      content: "";
      position: absolute;
      height: 16px;
      width: 16px;
      left: 3px;
      top: 3px;
      background: #fff;
      border-radius: 50%;
      transition: transform 160ms ease;
      box-shadow: 0 2px 5px rgba(15, 23, 42, 0.22);
    }
    .zt-panel-switch input:checked + .zt-panel-slider { background: #22c55e; box-shadow: inset 0 0 0 1px rgba(21, 128, 61, 0.10); }
    .zt-panel-switch input:checked + .zt-panel-slider::before { transform: translateX(16px); }

    .zt-panel-status {
      margin-top: 10px;
      font-size: 11.2px;
      color: #334155;
      line-height: 1.45;
      display: none;
      background: #eff6ff;
      border: 1px solid #dbeafe;
      border-radius: 11px;
      padding: 9px 10px;
    }
    .zt-panel-status.zt-show { display: block; animation: zt-status-in 160ms ease-out; }
    @keyframes zt-status-in { from { opacity: 0; transform: translateY(-3px); } to { opacity: 1; transform: translateY(0); } }

    .zt-panel-legend {
      margin-top: 13px;
      background: #fbfdff;
      border: 1px solid #e8edf3;
      border-radius: 13px;
      padding: 2px 11px;
    }
    .zt-panel-legend-item { display: flex; align-items: center; gap: 9px; padding: 7px 0; font-size: 10.5px; color: #475569; }
    .zt-panel-legend-item + .zt-panel-legend-item { border-top: 1px solid #edf1f5; }
    .zt-panel-dot { flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; box-shadow: 0 0 0 3px rgba(148, 163, 184, 0.08); }
    .zt-panel-legend-item b { color: #172033; font-weight: 650; }

    .zt-panel-hint { font-size: 9.8px; color: #94a3b8; margin-top: 9px; line-height: 1.4; text-align: center; }
    .zt-panel-hint-pause { margin-top: 7px; }

    .zt-panel-seeall {
      width: 100%;
      margin-top: 13px;
      padding: 10px 8px 3px;
      background: none;
      border: none;
      border-top: 1px solid #edf1f5;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 700;
      color: #15803d;
      cursor: pointer;
      font-family: inherit;
      transition: color 150ms ease;
    }
    .zt-panel-seeall:hover { color: #166534; }
    .zt-panel-chevron { display: inline-block; transition: transform 180ms ease; font-size: 9px; }
    .zt-panel-seeall.zt-open .zt-panel-chevron { transform: rotate(180deg); }

    .zt-panel-fields {
      display: none;
      max-height: 330px;
      overflow-y: auto;
      margin-top: 8px;
      padding: 2px 4px 0 2px;
      scrollbar-width: thin;
      scrollbar-color: #cbd5e1 transparent;
    }
    .zt-panel-fields.zt-open { display: block; }
    .zt-panel-field { margin-top: 9px; }
    .zt-panel-field label { display: block; font-size: 10.2px; font-weight: 650; color: #334155; margin-bottom: 4px; }
    .zt-panel-field input[type="text"],
    .zt-panel-field textarea,
    .zt-panel-field select {
      width: 100%;
      box-sizing: border-box;
      padding: 7px 9px;
      font-size: 11.3px;
      border: 1px solid #dbe2ea;
      border-radius: 8px;
      outline: none;
      font-family: inherit;
      color: #0f172a;
      background: #fff;
      transition: border-color 150ms ease, box-shadow 150ms ease;
    }
    .zt-panel-field input[type="text"]:focus,
    .zt-panel-field textarea:focus,
    .zt-panel-field select:focus { border-color: #86efac; box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.10); }
    .zt-panel-field textarea { min-height: 60px; resize: vertical; }
    .zt-panel-field-checkbox { display: flex; align-items: center; gap: 7px; margin-top: 10px; }
    .zt-panel-field-checkbox input { margin: 0; accent-color: #22c55e; }
    .zt-panel-field-checkbox label { margin: 0; font-size: 10.8px; font-weight: 600; color: #334155; }

    .zt-panel-savebtn {
      width: 100%;
      margin-top: 12px;
      padding: 10px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      border-radius: 10px;
      border: 1px solid #dcfce7;
      color: #166534;
      background: #f0fdf4;
      font-family: inherit;
      transition: background 150ms ease, transform 140ms ease;
    }
    .zt-panel-savebtn:hover { background: #dcfce7; }
    .zt-panel-savebtn:active { transform: scale(0.985); }
    .zt-panel-saved { text-align: center; font-size: 10.5px; font-weight: 650; color: #16a34a; margin-top: 6px; min-height: 14px; }
  `;
  shadowRoot.appendChild(style);
}

function setPanelStatus(text) {
  if (!panelStatusEl) return;
  panelStatusEl.textContent = uiT(text);
  panelStatusEl.classList.toggle("zt-show", !!text);
}

// Renders every field from PROFILE_FORM_FIELDS (profile-schema.js, shared
// with options.html) as an editable input inside the panel's "See all
// fields" section, plus a Save button that writes them all back at once —
// the whole profile is editable right here, no need to open Settings.
function buildPanelFieldsForm(container) {
  PROFILE_FORM_FIELDS.forEach((field) => {
    const fieldId = `zt-f-${field.id}`;
    const wrap = document.createElement("div");

    if (field.type === "checkbox") {
      wrap.className = "zt-panel-field-checkbox";
      wrap.innerHTML = `<input type="checkbox" id="${fieldId}"><label for="${fieldId}">${uiT(field.label)}</label>`;
    } else if (field.type === "textarea") {
      wrap.className = "zt-panel-field";
      wrap.innerHTML = `<label for="${fieldId}">${uiT(field.label)}</label><textarea id="${fieldId}"></textarea>`;
    } else if (field.type === "select") {
      const opts = field.options.map((o) => `<option value="${o}">${uiT(o || "Not set")}</option>`).join("");
      wrap.className = "zt-panel-field";
      wrap.innerHTML = `<label for="${fieldId}">${uiT(field.label)}</label><select id="${fieldId}">${opts}</select>`;
    } else {
      wrap.className = "zt-panel-field";
      wrap.innerHTML = `<label for="${fieldId}">${uiT(field.label)}</label><input type="text" id="${fieldId}">`;
    }
    container.appendChild(wrap);
  });

  const saveBtn = document.createElement("button");
  saveBtn.type = "button";
  saveBtn.className = "zt-panel-savebtn";
  saveBtn.textContent = uiT("Save");
  const savedMsg = document.createElement("div");
  savedMsg.className = "zt-panel-saved";
  container.appendChild(saveBtn);
  container.appendChild(savedMsg);

  saveBtn.addEventListener("click", () => savePanelFields(container, savedMsg));
}

function loadPanelFields(container) {
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    PROFILE_FORM_FIELDS.forEach((field) => {
      const el = container.querySelector(`#zt-f-${field.id}`);
      if (!el) return;
      if (field.type === "checkbox") el.checked = !!data[field.id];
      else el.value = data[field.id] ?? "";
    });
  });
}

function savePanelFields(container, savedMsg) {
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    PROFILE_FORM_FIELDS.forEach((field) => {
      const el = container.querySelector(`#zt-f-${field.id}`);
      if (!el) return;
      data[field.id] = field.type === "checkbox" ? el.checked : el.value;
    });
    chrome.storage.local.set({ profile: data }, () => {
      savedMsg.textContent = uiT("Saved ✓");
      setTimeout(() => (savedMsg.textContent = ""), 2000);
    });
  });
}

function openDocumentManagerFromPanel(key, { profileImport = false } = {}) {
  chrome.runtime.sendMessage({ type: "OPEN_DOCUMENT_MANAGER", key, profileImport }, (response) => {
    if (chrome.runtime.lastError) {
      setPanelStatus(`Could not open the document picker: ${chrome.runtime.lastError.message}`);
      return;
    }
    if (!response?.ok) setPanelStatus(`Could not open the document picker${response?.error ? `: ${response.error}` : "."}`);
  });
}

function refreshPanelDocuments() {
  if (!panelEl) return;
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    ["cv", "coverLetter", "portfolio"].forEach((key) => {
      const el = panelEl.querySelector(`[data-status-key="${key}"]`);
      if (!el) return;
      const name = data[`${key}FileDataUrl`] ? data[`${key}FileName`] : "";
      el.textContent = name ? `✓ ${name}` : uiT("Not selected");
      el.classList.toggle("zt-empty", !name);
    });
  });
}

function refreshPanelLearnedCount() {
  if (!panelLearnDescEl) return;
  chrome.storage.local.get("learnedAnswers", ({ learnedAnswers }) => {
    const count = Object.keys(learnedAnswers?.records || {}).length;
    panelLearnDescEl.textContent = uiT(`Save safe manual answers locally — credentials and ID numbers are never stored · ${count} learned`);
  });
}

function renderPanelUnanswered(items = []) {
  if (!panelMissingListEl || !panelMissingCountEl) return;
  panelMissingCountEl.textContent = String(items.length);
  panelMissingListEl.textContent = "";
  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "zt-panel-missing-empty";
    empty.textContent = uiT("✓ No visible unanswered fields found.");
    panelMissingListEl.appendChild(empty);
    return;
  }
  items.forEach((item) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "zt-panel-missing-item";
    const label = document.createElement("span");
    label.className = "zt-panel-missing-label";
    label.textContent = item.label || uiT("Unanswered field");
    const meta = document.createElement("span");
    meta.className = "zt-panel-missing-meta";
    meta.textContent = `${item.required ? uiT("Required · ") : ""}${item.reason || uiT("Not filled")}${uiT(" · click to focus")}`;
    btn.append(label, meta);
    btn.addEventListener("click", () => focusUnansweredField(item.id));
    panelMissingListEl.appendChild(btn);
  });
}

function refreshPanelUnanswered() {
  if (!panelEl || !panelEl.classList.contains("zt-panel-open")) return;
  try { renderPanelUnanswered(collectUnansweredFields(true)); }
  catch (_err) {}
}

function ensurePanel() {
  if (panelEl) return;
  ensurePanelStyle();

  panelEl = document.createElement("div");
  panelEl.className = "zt-panel";

  panelEl.innerHTML = `
    <div class="zt-panel-hero">
      <div class="zt-panel-hero-top">
        <div class="zt-panel-brand">
          <div class="zt-panel-logo"><img src="${chrome.runtime.getURL("icons/avatar.png")}" alt="" /></div>
          <div>
            <p class="zt-panel-title">Automatic Easy Apply Jobs</p>
            <div class="zt-panel-subtitle">Fill this application in one click</div>
          </div>
        </div>
        <div class="zt-panel-head-actions">
          <select class="zt-panel-lang" aria-label="Interface language"><option value="en">EN</option><option value="tr">TR</option></select>
        <button type="button" class="zt-panel-gear" title="Edit Profile" aria-label="Edit Profile">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
        </button>
        </div>
      </div>
      <div class="zt-panel-mode" data-mode="idle">Waiting for a form</div>
    </div>
    <div class="zt-panel-body">
      <button type="button" class="zt-panel-fillbtn">✨ Fill this page</button>
      <button type="button" class="zt-panel-secondarybtn zt-panel-import-cv">📄 Import profile from CV</button>

      <div class="zt-panel-toggle-row">
        <div>
          <div class="zt-panel-toggle-title">Auto-fill on detect</div>
          <div class="zt-panel-toggle-desc">Fill forms as soon as they're found — no click needed</div>
        </div>
        <label class="zt-panel-switch">
          <input type="checkbox" class="zt-panel-autofill-toggle" />
          <span class="zt-panel-slider"></span>
        </label>
      </div>
      <div class="zt-panel-hint zt-panel-hint-pause">⏸️ Pause auto-fill any time using the toggle above.</div>

      <div class="zt-panel-toggle-row zt-panel-learn-row">
        <div>
          <div class="zt-panel-toggle-title">Remember new answers</div>
          <div class="zt-panel-toggle-desc zt-panel-learn-desc">Save safe manual answers locally — credentials and ID numbers are never stored</div>
        </div>
        <label class="zt-panel-switch">
          <input type="checkbox" class="zt-panel-learn-toggle" />
          <span class="zt-panel-slider"></span>
        </label>
      </div>
      <button type="button" class="zt-panel-secondarybtn zt-panel-manage-learned" style="margin-top:7px">View / delete saved answers</button>

      <div class="zt-panel-docs">
        <div class="zt-panel-doc-title">📎 Documents from your PC</div>
        <div class="zt-panel-doc-sub">Choose or replace a saved file here; it will be attached to matching application fields automatically.</div>
        <div class="zt-panel-doc-row">
          <div class="zt-panel-doc-label">CV / Resume</div>
          <button type="button" class="zt-panel-doc-pick" data-key="cv">Choose from PC</button>
          <div class="zt-panel-doc-status zt-empty" data-status-key="cv">Not selected</div>
        </div>
        <div class="zt-panel-doc-row">
          <div class="zt-panel-doc-label">Cover Letter</div>
          <button type="button" class="zt-panel-doc-pick" data-key="coverLetter">Choose from PC</button>
          <div class="zt-panel-doc-status zt-empty" data-status-key="coverLetter">Not selected</div>
        </div>
        <div class="zt-panel-doc-row">
          <div class="zt-panel-doc-label">Portfolio</div>
          <button type="button" class="zt-panel-doc-pick" data-key="portfolio">Choose from PC</button>
          <div class="zt-panel-doc-status zt-empty" data-status-key="portfolio">Not selected</div>
        </div>
      </div>

      <div class="zt-panel-status"></div>

      <div class="zt-panel-missing">
        <div class="zt-panel-missing-head">
          <div class="zt-panel-missing-title">🔴 Unanswered fields</div>
          <div class="zt-panel-missing-count">0</div>
        </div>
        <div class="zt-panel-missing-list"><div class="zt-panel-missing-empty">Scanning this application…</div></div>
      </div>

      <div class="zt-panel-legend">
        <div class="zt-panel-legend-item"><span class="zt-panel-dot" style="background:#22c55e"></span><span><b>Green</b> — filled</span></div>
        <div class="zt-panel-legend-item"><span class="zt-panel-dot" style="background:#3b82f6"></span><span><b>Blue</b> — estimated value, double-check</span></div>
        <div class="zt-panel-legend-item"><span class="zt-panel-dot" style="background:#f59e0b"></span><span><b>Orange</b> — manual/legal review</span></div>
        <div class="zt-panel-legend-item"><span class="zt-panel-dot" style="background:#ef4444"></span><span><b>Red</b> — still unanswered</span></div>
      </div>

      <button type="button" class="zt-panel-seeall"><span class="zt-panel-seeall-label">See all profile fields</span><span class="zt-panel-chevron">▾</span></button>
      <div class="zt-panel-fields"></div>
    </div>
  `;

  panelStatusEl = panelEl.querySelector(".zt-panel-status");
  panelToggleEl = panelEl.querySelector(".zt-panel-autofill-toggle");
  panelLearnToggleEl = panelEl.querySelector(".zt-panel-learn-toggle");
  panelLearnDescEl = panelEl.querySelector(".zt-panel-learn-desc");
  panelModeEl = panelEl.querySelector(".zt-panel-mode");
  panelMissingListEl = panelEl.querySelector(".zt-panel-missing-list");
  panelMissingCountEl = panelEl.querySelector(".zt-panel-missing-count");

  const panelLangSelect = panelEl.querySelector(".zt-panel-lang");
  uiI18nReady.then(() => {
    if (panelLangSelect) panelLangSelect.value = uiI18n.language;
    uiI18n.apply(panelEl);
    updateBadgeVisualState({});
  });
  panelLangSelect?.addEventListener("change", () => {
    uiI18n.setLanguage(panelLangSelect.value);
    uiI18n.apply(panelEl);
    updateBadgeVisualState({});
    refreshPanelDocuments();
    refreshPanelLearnedCount();
    refreshPanelUnanswered();
  });

  panelEl.querySelector(".zt-panel-gear").addEventListener("click", openSettingsTab);

  panelModeEl.addEventListener("click", () => {
    if (badgeState.noProfile || panelModeEl.dataset.mode === "warning") openSettingsTab();
  });

  buildPanelFieldsForm(panelEl.querySelector(".zt-panel-fields"));

  const seeAllBtn = panelEl.querySelector(".zt-panel-seeall");
  const fieldsContainer = panelEl.querySelector(".zt-panel-fields");
  seeAllBtn.addEventListener("click", () => {
    const isOpen = fieldsContainer.classList.toggle("zt-open");
    seeAllBtn.classList.toggle("zt-open", isOpen);
    seeAllBtn.querySelector(".zt-panel-seeall-label").textContent = uiT(isOpen ? "Hide profile fields" : "See all profile fields");
    if (isOpen) loadPanelFields(fieldsContainer);
  });

  panelEl.querySelector(".zt-panel-fillbtn").addEventListener("click", () => {
    setPanelStatus("Filling...");
    runFill((text) => {
      setPanelStatus(text);
      setTimeout(refreshPanelUnanswered, 80);
    });
  });

  panelEl.querySelector(".zt-panel-import-cv").addEventListener("click", () => {
    openDocumentManagerFromPanel("cv", { profileImport: true });
  });

  panelEl.querySelector(".zt-panel-manage-learned")?.addEventListener("click", openSavedAnswersTab);

  panelEl.querySelectorAll(".zt-panel-doc-pick[data-key]").forEach((button) => {
    button.addEventListener("click", () => openDocumentManagerFromPanel(button.dataset.key));
  });

  panelLearnToggleEl.addEventListener("change", () => {
    chrome.storage.local.get("profile", ({ profile }) => {
      const updated = normalizeProfile(profile);
      updated.learnNewAnswers = panelLearnToggleEl.checked;
      chrome.storage.local.set({ profile: updated });
    });
  });

  panelToggleEl.addEventListener("change", () => {
    chrome.storage.local.get("profile", ({ profile }) => {
      const updated = { ...(profile || {}), autoFillOnDetect: panelToggleEl.checked };
      chrome.storage.local.set({ profile: updated }, () => {
        updateBadgeVisualState({ paused: !panelToggleEl.checked, noProfile: false });
      });
    });
  });

  shadowRoot.appendChild(panelEl);
  makeAssistantDraggable(panelEl.querySelector(".zt-panel-hero"), "panel");
  applyFloatingPosition(floatingPosition);

  // Everything we inject lives inside one shadow tree, so any click that
  // originated in there gets retargeted to `shadowHost` for listeners out
  // here — a plain identity check is enough to tell "inside" from "outside".
  document.addEventListener("click", (e) => {
    if (panelEl.classList.contains("zt-panel-open") && e.target !== shadowHost) {
      closePanel();
    }
  });
}

function openPanel() {
  ensurePanel();
  // Explicitly opening from the toolbar should work even if the ordinary FAB
  // is currently hidden because auto-fill is paused or no form was detected.
  showBadge();
  chrome.storage.local.get("profile", ({ profile }) => {
    const data = normalizeProfile(profile);
    const paused = !!profile && data.autoFillOnDetect === false;
    panelToggleEl.checked = !paused;
    if (panelLearnToggleEl) panelLearnToggleEl.checked = data.learnNewAnswers !== false;
    updateBadgeVisualState({ paused, noProfile: !profile, hasForm: looksLikeApplicationForm() });
  });
  setPanelStatus("");
  panelEl.classList.add("zt-panel-open");
  refreshPanelDocuments();
  refreshPanelLearnedCount();
  refreshPanelUnanswered();
  requestAnimationFrame(() => syncPanelToBadge());
}

function closePanel() {
  if (panelEl) panelEl.classList.remove("zt-panel-open");
}

function togglePanel() {
  ensurePanel();
  if (panelEl.classList.contains("zt-panel-open")) {
    closePanel();
  } else {
    openPanel();
  }
}

// A rough fingerprint of "how many fillable fields are on the page right now,
// for this URL". Used to avoid re-running fillForm() over and over on pages
// that mutate constantly for unrelated reasons (ads, chat widgets, etc.), while
// still catching genuinely new fields — e.g. LinkedIn's "Easy Apply" modal,
// which mounts long after page load, or a later step of a multi-step wizard.
let lastFieldSignature = "";
function fieldSignature() {
  // Include field labels/types, not only the count. Multi-step ATS wizards can
  // replace one set of 5 fields with a different set of 5 fields on the same
  // URL; count-only signatures would incorrectly skip the new step.
  const parts = Array.from(document.querySelectorAll("input, textarea, select"))
    .filter((el) => el.type !== "hidden")
    .map((el) => `${el.tagName}:${el.type || ""}:${normalizeLearnQuestion(getLabelText(el)).slice(0, 100)}`)
    .sort();
  let hash = 2166136261;
  const raw = `${location.href}|${parts.join("|")}`;
  for (let i = 0; i < raw.length; i++) {
    hash ^= raw.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `${location.href}:${(hash >>> 0).toString(16)}`;
}

let isAutoFilling = false;

function checkAndFill() {
  if (isAutoFilling) return;

  // Never auto-submits. Legal/judgment questions stay orange unless an explicit
  // profile default or a conservatively scoped learned answer is available.
  chrome.storage.local.get(["profile", "learnedAnswers"], ({ profile, learnedAnswers }) => {
    const paused = !!profile && profile.autoFillOnDetect === false;
    const hasForm = looksLikeApplicationForm();

    // Keep the assistant reachable on every ordinary web page where the
    // content script is allowed to run. If no application form is detected it
    // simply shows the neutral “Waiting for a form” state. This avoids the
    // frustrating case where an ATS renders late/in an iframe and the user has
    // no icon to open manually.
    if (IS_TOP_FRAME) {
      showBadge();
      updateBadgeVisualState({ paused, noProfile: !profile, hasForm });
    }

    if (paused || !hasForm || !profile) return;
    const sig = fieldSignature();
    if (sig === lastFieldSignature) return;
    lastFieldSignature = sig;

    isAutoFilling = true;
    try {
      const result = fillForm(profile, learnedAnswers);
      if (IS_TOP_FRAME) {
        showBadgeMessage(
          `${result.filled} filled, ${result.unanswered?.length || 0} unanswered (red), ${result.fileHelpers} upload helper(s) shown`
        );
      }
    } catch (err) {
      console.error("[Easy Apply] fillForm crashed", err);
    } finally {
      setTimeout(() => {
        isAutoFilling = false;
      }, 300);
    }
  });
}

// Forms often render asynchronously (SPAs), or open later inside a modal —
// e.g. LinkedIn's "Easy Apply" button, which mounts its form well after page
// load, then swaps in new fields at every step of its wizard. So besides
// checking a few times after load, keep watching the DOM for the rest of the
// page's life and re-check (debounced) whenever it changes.
if (IS_TOP_FRAME) setTimeout(() => { try { showBadge(); } catch (_err) {} }, 0);
[0, 1500, 4000].forEach((delay) => setTimeout(checkAndFill, delay));

let mutationDebounce = null;
new MutationObserver(() => {
  if (isAutoFilling) return;
  clearTimeout(mutationDebounce);
  mutationDebounce = setTimeout(checkAndFill, 400);
}).observe(document.documentElement, { childList: true, subtree: true });

// Keep the red unanswered list in the on-page panel live while the user edits
// the application manually. This only runs visible work while the panel is open.
setInterval(refreshPanelUnanswered, 1200);

// Message from the popup ("Fill this page" button)
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "PING") {
    sendResponse({ ok: true, topFrame: IS_TOP_FRAME });
    return;
  }

  if (msg?.type === "OPEN_PANEL") {
    if (!IS_TOP_FRAME) { sendResponse({ ok: false, error: "not-top-frame" }); return; }
    try {
      openPanel();
      sendResponse({ ok: true });
    } catch (err) {
      sendResponse({ ok: false, error: err.message });
    }
    return;
  }

  if (msg?.type === "FILL_NOW") {
    chrome.storage.local.get(["profile", "learnedAnswers"], ({ profile, learnedAnswers }) => {
      if (!profile) {
        sendResponse({ error: "no-profile" });
        return;
      }
      try {
        const data = normalizeProfile(profile);
        const result = fillForm(data, learnedAnswers);
        const uploads = {};
        ["cv", "coverLetter", "portfolio"].forEach((key) => {
          uploads[key] = attachStoredFileByKey(data, key);
        });
        sendResponse({ result, uploads });
      } catch (err) {
        console.error("[Easy Apply] fillForm crashed", err);
        sendResponse({ error: "crashed", message: err.message });
      }
    });
    return true; // async response
  }

  if (msg?.type === "ATTACH_STORED_FILE") {
    chrome.storage.local.get("profile", ({ profile }) => {
      if (!profile) { sendResponse({ error: "no-profile", found: 0, attached: 0, dropped: 0 }); return; }
      try {
        const data = normalizeProfile(profile);
        const result = attachStoredFileByKey(data, msg.key);
        // Run the ordinary fill pass too, because some ATSs only render their
        // real file input after the first dropzone interaction.
        setTimeout(() => {
          try { fillForm(data, {}); } catch (_err) {}
        }, 120);
        sendResponse(result);
      } catch (err) {
        console.error("[Easy Apply] direct document attach failed", err);
        sendResponse({ error: "attach-failed", message: err.message, found: 0, attached: 0, dropped: 0 });
      }
    });
    return true;
  }

  if (msg?.type === "GET_UNANSWERED") {
    try {
      sendResponse({ unanswered: collectUnansweredFields(true) });
    } catch (err) {
      console.error("[Easy Apply] couldn't scan unanswered fields", err);
      sendResponse({ error: "scan-failed", message: err.message });
    }
    return;
  }

  if (msg?.type === "FOCUS_FIELD") {
    sendResponse({ ok: focusUnansweredField(msg.fieldId) });
    return;
  }
});

// Keep the on-page FAB in sync even when the profile is changed from the
// toolbar popup or Settings rather than this page's own panel — re-running
// the same show/hide + color logic checkAndFill already does, so un-pausing
// elsewhere immediately reveals the FAB again on a page with a form (and
// pausing elsewhere hides it here too), not just on the next DOM mutation.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.uiLanguage) {
    uiI18n.ready.then(() => {
      // ui-i18n.js updates its language through setLanguage on extension pages;
      // content scripts receive storage changes from other extension views.
      const next = changes.uiLanguage.newValue === "tr" ? "tr" : "en";
      if (uiI18n.language !== next) {
        // Keep the shared translator in sync without touching the host page.
        uiI18n.setLanguage(next);
      }
      if (panelEl) {
        const select = panelEl.querySelector(".zt-panel-lang");
        if (select) select.value = next;
        uiI18n.apply(panelEl);
      }
      updateBadgeVisualState({});
      refreshPanelDocuments();
      refreshPanelLearnedCount();
      refreshPanelUnanswered();
    });
  }
  if (changes.learnedAnswers) refreshPanelLearnedCount();
  if (!changes.profile) return;
  const oldProfile = normalizeProfile(changes.profile.oldValue);
  const newProfile = normalizeProfile(changes.profile.newValue);
  if (IS_TOP_FRAME && panelLearnToggleEl) panelLearnToggleEl.checked = newProfile.learnNewAnswers !== false;
  if (IS_TOP_FRAME) refreshPanelDocuments();

  // Document selection is an explicit user action, so attachment should still
  // happen even when general auto-fill is paused. Every frame gets this storage
  // event; that lets embedded/cross-frame ATS upload inputs receive the file too.
  ["cv", "coverLetter", "portfolio"].forEach((key) => {
    const dataKey = `${key}FileDataUrl`;
    const nameKey = `${key}FileName`;
    if (newProfile[dataKey] && (newProfile[dataKey] !== oldProfile[dataKey] || newProfile[nameKey] !== oldProfile[nameKey])) {
      try { attachStoredFileByKey(newProfile, key); } catch (err) { console.warn("[Easy Apply] storage-triggered document attach failed", err); }
    }
  });

  // A newly selected CV/cover-letter does not change the form structure, so
  // force a new pass instead of letting the field-signature cache skip it.
  lastFieldSignature = "";
  if (IS_TOP_FRAME && panelToggleEl) panelToggleEl.checked = newProfile.autoFillOnDetect !== false;
  checkAndFill();
});
